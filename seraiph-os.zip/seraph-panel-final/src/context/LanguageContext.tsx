import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'tr' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  tr: {
    dashboard: 'Panel',
    projects: 'Projeler',
    aiAssistant: 'Yapay Zeka Asistanı',
    cyberLogs: 'Siber Günlükler',
    legislation: 'Mevzuat',
    activeProjects: 'Aktif Projeler',
    securityStatus: 'Güvenlik Durumu',
    uptime: 'Çalışma Süresi',
    dbConnections: 'VT Bağlantıları',
    protected: 'Korumalı',
    activeDeployments: 'Aktif Dağıtımlar',
    viewAll: 'Tümünü Gör',
    addProject: 'Proje Ekle',
    systemConfig: 'Sistem Yapılandırması',
    settings: 'Ayarlar',
    live: 'Canlı',
  },
  en: {
    dashboard: 'Dashboard',
    projects: 'Projects',
    aiAssistant: 'AI Assistant',
    cyberLogs: 'Cyber Logs',
    legislation: 'Legislation',
    activeProjects: 'Active Projects',
    securityStatus: 'Security Status',
    uptime: 'Uptime',
    dbConnections: 'DB Connections',
    protected: 'Protected',
    activeDeployments: 'Active Deployments',
    viewAll: 'View All',
    addProject: 'Add Project',
    systemConfig: 'System Config',
    settings: 'Settings',
    live: 'Live',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('tr');

  const t = (key: string) => {
    return (translations[language] as any)[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
