import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Layout/Sidebar';
import { Header } from './components/Layout/Header';
import { ChatInterface } from './components/AI/ChatInterface';
import { CyberMonitor } from './components/Security/CyberMonitor';
import { ProjectCard } from './components/Projects/ProjectCard';
import { ProjectDetail } from './components/Projects/ProjectDetail';
import { EmailManagement } from './components/Projects/EmailManagement';
import { EmailAccounts } from './components/Projects/EmailAccounts';
import { CreateEmailAccount } from './components/Projects/CreateEmailAccount';
import { Webmail } from './components/Projects/Webmail';
import { SeraiphMailApp } from './components/AI/SeraiphMailApp';
import { ManageEmailAccount } from './components/Projects/ManageEmailAccount';
import { ConnectDevices } from './components/Projects/ConnectDevices';
import { AddProject } from './components/Projects/AddProject';
import { SetupManagement } from './components/Projects/SetupManagement';
import { DatabaseManagement } from './components/Projects/DatabaseManagement';
import { FileManager } from './components/Projects/FileManager';
import { DomainManagement } from './components/Projects/DomainManagement';
import { SecurityManagement } from './components/Projects/SecurityManagement';
import { SoftwareManagement } from './components/Projects/SoftwareManagement';
import { CertificateManagement } from './components/Projects/CertificateManagement';
import { RedeployManagement } from './components/Projects/RedeployManagement';
import { ConfigManagement } from './components/Projects/ConfigManagement';
import { TerminalView } from './components/OS/TerminalView';
import { Settings } from './components/Settings/Settings';
import { LoginPage } from './components/Auth/LoginPage';
import { SeraphDashboard } from './components/Seraph/SeraphDashboard';
import { ServerStats, LogEntry, Project } from './types';
import { useLanguage } from './context/LanguageContext';
import { Box, Shield, Zap, Database, Globe, Plus, Terminal } from 'lucide-react';

export default function App() {
  const { t } = useLanguage();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [currentSubView, setCurrentSubView] = useState<string | null>(null);
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null);
  const [isAttackDetected, setIsAttackDetected] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  useEffect(() => {
    setCurrentSubView(null);
    setSelectedProject(null);
  }, [activeTab]);
  
  const [stats] = useState<ServerStats>({
    cpu: 42,
    ram: 40,
    dbConnected: true,
    health: 'healthy'
  });

  const [projects, setProjects] = useState<Project[]>([
    { id: '1', name: 'FirmamYayında', status: 'online', url: 'https://firmamyayinda.com', dockerId: 'fy-prod-01' },
    { id: '2', name: 'AgriPortal', status: 'online', url: 'https://agriportal.tr', dockerId: 'ap-prod-02' },
    { id: '3', name: 'FirmaTube', status: 'deploying', url: 'https://firmatube.com', dockerId: 'ft-prod-03' },
  ]);

  // Simulated log generation
  useEffect(() => {
    const interval = setInterval(() => {
      const types: ('info' | 'warning' | 'attack')[] = ['info', 'info', 'info', 'warning', 'attack'];
      const type = types[Math.floor(Math.random() * types.length)];
      
      const newLog: LogEntry = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        type,
        message: type === 'attack' ? 'Brute-force attempt detected on SSH' : 
                 type === 'warning' ? 'High memory usage on ft-prod-03' : 
                 'GET /api/v1/health - 200 OK',
        sourceIp: type === 'attack' ? '192.168.1.45' : undefined
      };

      setLogs(prev => [newLog, ...prev].slice(0, 50));

      if (type === 'attack') {
        setIsAttackDetected(true);
        setTimeout(() => setIsAttackDetected(false), 3000);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  if (!isAuthenticated) {
    return <LoginPage onLogin={(user) => {
      setCurrentUser(user);
      setIsAuthenticated(true);
    }} />;
  }

  return (
    <div className="flex h-screen bg-[#0f172a] overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <Header 
          stats={stats} 
          currentUser={currentUser} 
          onLogout={() => setIsAuthenticated(false)}
          onProfileClick={() => setActiveTab('admin-profile')}
        />
        
        <main className="flex-1 overflow-y-auto p-8 space-y-8">
          {activeTab === 'dashboard' && (
            <div className="space-y-8 animate-in fade-in duration-500">
              {/* Stats Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: t('activeProjects'), value: '3', icon: Box, color: 'text-indigo-400' },
                  { label: t('securityStatus'), value: t('protected'), icon: Shield, color: 'text-emerald-400' },
                  { label: t('uptime'), value: '99.9%', icon: Zap, color: 'text-amber-400' },
                  { label: t('dbConnections'), value: '12', icon: Database, color: 'text-blue-400' },
                ].map((stat, i) => (
                  <div key={i} className="bg-[#1e293b] p-6 rounded-2xl border border-white/5 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3 rounded-xl bg-[#0f172a] border border-white/5 ${stat.color}`}>
                        <stat.icon className="w-6 h-6" />
                      </div>
                      <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{t('live')}</span>
                    </div>
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                    <p className="text-xs text-slate-500 mt-1 font-medium">{stat.label}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Projects Grid */}
                <div className="lg:col-span-2 space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                      <Globe className="w-5 h-5 text-indigo-400" />
                      {t('activeDeployments')}
                    </h2>
                    <button 
                      onClick={() => setActiveTab('projects')}
                      className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors uppercase tracking-widest"
                    >
                      {t('viewAll')}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {projects.map(project => (
                      <ProjectCard 
                        key={project.id} 
                        project={project} 
                        onClick={() => {
                          setActiveTab('projects');
                          setSelectedProject(project);
                        }}
                      />
                    ))}
                  </div>
                </div>

                {/* Security Monitor */}
                <div className="space-y-6">
                  <div className="h-[600px]">
                    <CyberMonitor logs={logs} isAttackDetected={isAttackDetected} />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'terminal' && (
            <div className="h-[calc(100vh-140px)] animate-in fade-in duration-500">
              <TerminalView 
                onClose={() => setActiveTab('dashboard')} 
                onMinimize={() => setActiveTab('dashboard')}
              />
            </div>
          )}

          {activeTab === 'ai-chat' && (
            <div className="h-full max-w-5xl mx-auto animate-in fade-in duration-500">
              <ChatInterface />
            </div>
          )}

          {activeTab === 'security' && (
            <div className="h-full animate-in fade-in duration-500">
              <CyberMonitor logs={logs} isAttackDetected={isAttackDetected} />
            </div>
          )}

          {activeTab === 'seraph' && (
            <div className="animate-in fade-in duration-500">
              <SeraphDashboard onBack={() => setActiveTab('dashboard')} />
            </div>
          )}

          {activeTab === 'projects' && (
            <div className="animate-in fade-in duration-500 h-full">
              {currentSubView === 'add-project' ? (
                <AddProject 
                  onBack={() => setCurrentSubView(null)}
                  onAdd={(newProject) => {
                    const project: Project = {
                      ...newProject,
                      id: (projects.length + 1).toString(),
                    } as Project;
                    setProjects([...projects, project]);
                    setCurrentSubView(null);
                  }}
                />
              ) : currentSubView === 'setup' && selectedProject ? (
                <SetupManagement 
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'database' && selectedProject ? (
                <DatabaseManagement
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'files' && selectedProject ? (
                <FileManager
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'domain' && selectedProject ? (
                <DomainManagement
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'security' && selectedProject ? (
                <SecurityManagement
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'software' && selectedProject ? (
                <SoftwareManagement
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                  onGlobalTabChange={setActiveTab}
                />
              ) : currentSubView === 'certificates' && selectedProject ? (
                <CertificateManagement
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'redeploy' && selectedProject ? (
                <RedeployManagement
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'config' && selectedProject ? (
                <ConfigManagement
                  project={selectedProject}
                  onBack={() => setCurrentSubView(null)}
                />
              ) : currentSubView === 'manage-email' && selectedProject && selectedEmail ? (
                <ManageEmailAccount 
                  email={selectedEmail}
                  project={selectedProject}
                  onBack={() => setCurrentSubView('email-accounts')}
                  onCheckEmail={() => setCurrentSubView('webmail')}
                  onConnectDevices={() => setCurrentSubView('connect-devices')}
                />
              ) : currentSubView === 'connect-devices' && selectedProject && selectedEmail ? (
                <ConnectDevices 
                  email={selectedEmail}
                  project={selectedProject}
                  onBack={() => setCurrentSubView('manage-email')}
                />
              ) : currentSubView === 'seraiph-mail' || currentSubView === 'email-read' ? (
                <SeraiphMailApp onBack={() => setCurrentSubView(currentSubView === 'email-read' ? 'email' : 'webmail')} />
              ) : currentSubView === 'webmail' && selectedProject && selectedEmail ? (
                <Webmail 
                  email={selectedEmail}
                  project={selectedProject} 
                  onBack={() => setCurrentSubView('email-accounts')} 
                  onOpenMail={() => setCurrentSubView('seraiph-mail')}
                  onConnectDevices={() => setCurrentSubView('connect-devices')}
                />
              ) : currentSubView === 'create-email-account' && selectedProject ? (
                <CreateEmailAccount 
                  project={selectedProject} 
                  onBack={() => setCurrentSubView('email-accounts')} 
                />
              ) : currentSubView === 'email-accounts' && selectedProject ? (
                <EmailAccounts 
                  project={selectedProject} 
                  onBack={() => setCurrentSubView('email')} 
                  onCreateClick={() => setCurrentSubView('create-email-account')}
                  onCheckEmail={(email) => {
                    setSelectedEmail(email);
                    setCurrentSubView('webmail');
                  }}
                  onManageEmail={(email) => {
                    setSelectedEmail(email);
                    setCurrentSubView('manage-email');
                  }}
                />
              ) : currentSubView === 'email' && selectedProject ? (
                <EmailManagement 
                  project={selectedProject} 
                  onBack={() => setCurrentSubView(null)} 
                  onToolClick={(toolId) => setCurrentSubView(toolId)}
                />
              ) : selectedProject ? (
                <ProjectDetail 
                  project={selectedProject} 
                  onBack={() => {
                    setSelectedProject(null);
                    setCurrentSubView(null);
                  }} 
                  onSubViewChange={(view) => setCurrentSubView(view)}
                  setActiveTab={setActiveTab}
                />
              ) : (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-bold text-white">{t('projects')}</h2>
                    <button 
                      onClick={() => setCurrentSubView('add-project')}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> {t('addProject')}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {projects.map(project => (
                      <ProjectCard 
                        key={project.id} 
                        project={project} 
                        onClick={() => setSelectedProject(project)}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'library' && (
            <div className="flex flex-col items-center justify-center h-full text-slate-500 space-y-4 animate-in fade-in duration-500">
              <Box className="w-16 h-16 opacity-20" />
              <p className="text-lg font-medium">Legislation Library coming soon...</p>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="h-full animate-in fade-in duration-500">
              <Settings />
            </div>
          )}

          {activeTab === 'admin-profile' && (
            <div className="h-full animate-in fade-in duration-500">
              {/* Admin Profile Page */}
              <div className="max-w-4xl mx-auto space-y-8">
                <div className="bg-[#1e293b] rounded-3xl p-8 border border-white/5 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/5 blur-[80px] rounded-full -mr-32 -mt-32" />
                  <div className="flex items-center gap-8 relative z-10">
                    <div className="w-32 h-32 rounded-3xl bg-indigo-600 flex items-center justify-center border-4 border-white/10 shadow-2xl shadow-indigo-600/30">
                       <Shield className="w-16 h-16 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-2">
                        <h1 className="text-3xl font-black text-white italic tracking-tight">ROOT ACCESS: {currentUser}</h1>
                        <span className="px-3 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-500/20">L3 CLEARANCE</span>
                      </div>
                      <p className="text-slate-400 text-lg font-medium leading-relaxed">
                        Seraiph Global infrastructure core administrator. You have total authority over all linked nodes and orbital data relay stations.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="bg-[#1e293b] rounded-2xl p-6 border border-white/5 space-y-4">
                      <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                        <Zap className="w-3.5 h-3.5 text-amber-500" /> System Entropy Level
                      </h3>
                      <div className="h-2 bg-black/40 rounded-full overflow-hidden">
                         <div className="h-full w-[12%] bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
                      </div>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Normal operation: 0.12% jitter</p>
                   </div>
                   <div className="bg-[#1e293b] rounded-2xl p-6 border border-white/5 space-y-4">
                      <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                        <Database className="w-3.5 h-3.5 text-blue-500" /> Core Encryption
                      </h3>
                      <div className="flex items-center gap-4">
                         <div className="flex-1 h-2 bg-black/40 rounded-full overflow-hidden">
                            <div className="h-full w-full bg-blue-600 shadow-[0_0_10px_rgba(37,99,235,0.5)]" />
                         </div>
                         <span className="text-xs font-black text-blue-400">2048-BIT AES</span>
                      </div>
                   </div>
                </div>

                <div className="bg-black/20 rounded-3xl p-6 border border-white/5">
                   <h2 className="text-sm font-black text-white uppercase tracking-[0.2em] mb-6 flex items-center gap-3">
                      <Terminal className="w-4 h-4 text-indigo-400" /> Administrative Quick-Actions
                   </h2>
                   <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      {[
                        { label: 'Flush DNS', color: 'bg-indigo-500' },
                        { label: 'Reboot Core', color: 'bg-amber-500' },
                        { label: 'Panic Mode', color: 'bg-rose-500' },
                        { label: 'Clear Logs', color: 'bg-slate-600' }
                      ].map((action, i) => (
                        <button key={i} className="flex flex-col items-center gap-3 p-4 bg-[#1e293b] hover:bg-[#1e293b]/80 border border-white/5 rounded-2xl transition-all group">
                           <div className={`w-10 h-10 rounded-xl ${action.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                              <Box className="w-5 h-5 text-white" />
                           </div>
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{action.label}</span>
                        </button>
                      ))}
                   </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
