import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, Key, Globe, Shield, 
  Terminal, Code, BookOpen, Copy, Check, 
  RefreshCcw, Save, Server, Database, Mail, 
  Layout, Activity, Zap
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const Settings: React.FC = () => {
  const [apiKey] = useState('vtx_live_728x_912k_js01_p09m');
  const [copied, setCopied] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'general' | 'api' | 'guide'>('general');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const endpoints = [
    { method: 'GET', path: '/api/v1/projects', desc: 'Sistemdeki tüm projeleri listeler' },
    { method: 'GET', path: '/api/v1/projects/:id', desc: 'Belirtilen projenin detaylarını (statü, docker-id, stack) döndürür' },
    { method: 'GET', path: '/api/v1/stats', desc: 'RAM, CPU ve sistem sağlığı verilerini çeker' },
    { method: 'POST', path: '/api/v1/deploy', desc: 'Yeni bir deployment süreci başlatır' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
          Sistem Ayarları
          <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 text-[10px] uppercase tracking-widest rounded border border-indigo-500/20">
            Admin v.3.0
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">Seraiph OS altyapı, güvenlik ve API entegrasyonlarını yönetin.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-[#1e293b] w-fit rounded-2xl border border-white/5">
        {[
          { id: 'general', label: 'Genel Yapılandırma', icon: SettingsIcon },
          { id: 'api', label: 'API & Entegrasyon', icon: Code },
          { id: 'guide', label: 'Veri Çekme Kılavuzu', icon: BookOpen },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all",
              activeSubTab === tab.id 
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" 
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            )}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {activeSubTab === 'general' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
                <h3 className="font-bold text-white flex items-center gap-3">
                  <Globe className="w-5 h-5 text-indigo-400" /> Panel Erişimi
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Panel Domain</label>
                    <input 
                      type="text" 
                    defaultValue="panel.seraiph-os.com"
                      className="w-full bg-[#0f172a] border border-white/5 rounded-xl px-4 py-3 text-sm text-slate-300 focus:outline-none focus:border-indigo-500/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">SSL Durumu</label>
                    <div className="px-4 py-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-sm font-bold flex items-center gap-2">
                      <Shield className="w-4 h-4" /> Let's Encrypt - Aktif
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
                <h3 className="font-bold text-white flex items-center gap-3">
                  <Server className="w-5 h-5 text-amber-400" /> Altyapı Sağlayıcısı
                </h3>
                <div className="flex items-center justify-between p-6 bg-[#0f172a] rounded-2xl border border-white/5">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-white/5 rounded-xl">
                      <Zap className="w-8 h-8 text-indigo-500" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">Cenuta Cloud Infrastructure</p>
                      <p className="text-xs text-slate-500 mt-1">High-performance EPYC clusters</p>
                    </div>
                  </div>
                  <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all">
                    Bağlantıyı Yenile
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'api' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
                <h3 className="font-bold text-white flex items-center gap-3">
                  <Key className="w-5 h-5 text-indigo-400" /> Private API Key
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Harici uygulamaların Seraiph OS üzerindeki verileri çekebilmesi için bu anahtarı kullanın. 
                  Bu anahtarı asla client-side (frontend) tarafında açıkça paylaşmayın.
                </p>
                <div className="flex gap-2">
                  <div className="flex-1 bg-[#0f172a] border border-white/5 rounded-xl px-4 py-3 font-mono text-sm text-indigo-400 select-all overflow-x-auto whitespace-nowrap">
                    {apiKey}
                  </div>
                  <button 
                    onClick={() => copyToClipboard(apiKey)}
                    className="px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all flex items-center gap-2"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex justify-end pt-4 border-t border-white/5">
                  <button className="text-xs font-bold text-rose-500 hover:text-rose-400 transition-colors uppercase tracking-widest flex items-center gap-2">
                    <RefreshCcw className="w-3 h-3" /> Yeni Anahtar Üret
                  </button>
                </div>
              </div>

              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
                <h3 className="font-bold text-white flex items-center gap-3">
                  <Terminal className="w-5 h-5 text-emerald-400" /> Webhook Endpoint
                </h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Webhook URL</label>
                    <input 
                      type="text" 
                      placeholder="https://your-server.com/webhooks/seraiph"
                      className="w-full bg-[#0f172a] border border-white/5 rounded-xl px-4 py-3 text-sm text-slate-300 focus:outline-none focus:border-indigo-500/50"
                    />
                  </div>
                  <div className="flex gap-4">
                    {['Deployment Başarılı', 'Giriş Denemesi', 'Saldırı Engellendi'].map(event => (
                      <label key={event} className="flex items-center gap-2 cursor-pointer group">
                        <div className="w-4 h-4 rounded border border-white/20 bg-white/5 group-hover:border-indigo-500/50 transition-colors" />
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{event}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'guide' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
                <h3 className="font-bold text-white flex items-center gap-3">
                  <BookOpen className="w-5 h-5 text-indigo-400" /> Veri Çekme Mimarisi
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Seraiph OS, tüm modül verilerini (Proje Listesi, E-posta Hesapları, Veritabanı İstatistikleri) JSON tabanlı RESTful API'ler üzerinden sunar.
                  Aşağıdaki tabloda temel veri çekme noktaları belirtilmiştir.
                </p>
                
                <div className="space-y-4">
                  {endpoints.map((ep, i) => (
                    <div key={i} className="group p-4 bg-[#0f172a] rounded-2xl border border-white/5 hover:border-indigo-500/30 transition-all">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <span className={cn(
                            "px-2 py-0.5 rounded text-[10px] font-black tracking-widest uppercase",
                            ep.method === 'GET' ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                          )}>
                            {ep.method}
                          </span>
                          <span className="font-mono text-sm text-slate-200 group-hover:text-white transition-colors">{ep.path}</span>
                        </div>
                        <button className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-white transition-all">
                          <Copy className="w-3 h-3" />
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-500">{ep.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
                <h3 className="font-bold text-white flex items-center gap-3">
                  <Code className="w-5 h-5 text-amber-400" /> Örnek Entegrasyon (Node.js)
                </h3>
                <div className="bg-[#0f172a] p-6 rounded-2xl border border-white/5 overflow-x-auto">
                  <pre className="text-xs font-mono leading-relaxed">
                    <code className="text-indigo-400">const</code> <code className="text-slate-300">axios = require('axios');</code><br/>
                    <br/>
                    <code className="text-indigo-400">async function</code> <code className="text-emerald-400">getProjectStats</code><code className="text-slate-300">() {"{"}</code><br/>
                    <code className="text-slate-500">  // Header üzerinden yetkilendirme</code><br/>
                    <code className="text-indigo-400">  const</code> <code className="text-slate-300">response = </code><code className="text-indigo-400">await</code><code className="text-slate-300"> axios.get(</code><code className="text-amber-300">'https://api.seraiph-os.com/v1/projects'</code><code className="text-slate-300">, {"{"}</code><br/>
                    <code className="text-slate-300">    headers: {"{"} </code><code className="text-amber-300">'X-Seraiph-Auth'</code><code className="text-slate-300">: </code><code className="text-amber-300">'{apiKey}'</code><code className="text-slate-300"> {"}"}</code><br/>
                    <code className="text-slate-300">  {"}"});</code><br/>
                    <code className="text-indigo-400">  return</code><code className="text-slate-300"> response.data;</code><br/>
                    <code className="text-slate-300">{"}"}</code>
                  </pre>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Panel */}
        <div className="space-y-8">
          {/* Quick Stats */}
          <div className="bg-[#1e293b] rounded-3xl p-8 border border-white/5 shadow-xl space-y-8">
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Sistem Özet</h3>
            <div className="space-y-6">
              {[
                { label: 'Kayıtlı Proje', value: '42', icon: Layout, color: 'text-indigo-400' },
                { label: 'Aktif E-posta', value: '1,204', icon: Mail, color: 'text-blue-400' },
                { label: 'DB Cluster', value: '12 Unit', icon: Database, color: 'text-emerald-400' },
                { label: 'Toplam CPU', value: '96 Core', icon: Activity, color: 'text-rose-400' },
              ].map((s, i) => (
                <div key={i} className="flex items-center justify-between group">
                  <div className="flex items-center gap-3">
                    <div className={cn("p-2 bg-white/5 rounded-lg", s.color)}>
                      <s.icon className="w-4 h-4" />
                    </div>
                    <span className="text-xs text-slate-400 font-medium">{s.label}</span>
                  </div>
                  <span className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors">{s.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Backup & Safety */}
          <div className="bg-rose-500/5 rounded-3xl p-8 border border-rose-500/10 space-y-6">
            <h3 className="text-[10px] font-bold text-rose-500 uppercase tracking-widest">Kritik İşlemler</h3>
            <div className="space-y-4">
              <button className="w-full py-4 bg-[#0f172a] hover:bg-slate-800 text-slate-400 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border border-white/5 transition-all">
                Tüm Önbelleği Temizle
              </button>
              <button className="w-full py-4 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border border-rose-500/20 transition-all">
                Sistemi Fabrika Ayarlarına Sıfırla
              </button>
            </div>
          </div>

          <button className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-3xl font-bold transition-all shadow-xl shadow-indigo-600/20 flex items-center justify-center gap-3">
            <Save className="w-5 h-5" /> Yapılandırmayı Kaydet
          </button>
        </div>
      </div>
    </div>
  );
};
