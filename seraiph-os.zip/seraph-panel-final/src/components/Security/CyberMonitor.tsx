import React from 'react';
import { Shield, AlertTriangle, Activity, Terminal } from 'lucide-react';
import { LogEntry } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface CyberMonitorProps {
  logs: LogEntry[];
  isAttackDetected: boolean;
}

export const CyberMonitor: React.FC<CyberMonitorProps> = ({ logs, isAttackDetected }) => {
  return (
    <div className={cn(
      "flex flex-col h-full bg-[#1e293b] rounded-xl border transition-all duration-500 overflow-hidden shadow-xl",
      isAttackDetected ? "border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.3)]" : "border-white/5"
    )}>
      <div className="p-4 border-b border-white/5 bg-[#0f172a]/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className={cn("w-5 h-5", isAttackDetected ? "text-red-500 animate-pulse" : "text-indigo-400")} />
          <h2 className="font-medium text-slate-200">Cyber-Barrier Monitor</h2>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Gözcü Active</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-2 bg-[#0f172a]/50">
        {logs.map((log) => (
          <div key={log.id} className="flex gap-3 group">
            <span className="text-slate-600 shrink-0">[{log.timestamp}]</span>
            <span className={cn(
              "shrink-0 font-bold uppercase",
              log.type === 'attack' ? "text-red-500" : log.type === 'warning' ? "text-amber-500" : "text-indigo-400"
            )}>
              {log.type}
            </span>
            <span className="text-slate-300 group-hover:text-white transition-colors">
              {log.message}
              {log.sourceIp && <span className="text-slate-500 ml-2 italic">src: {log.sourceIp}</span>}
            </span>
          </div>
        ))}
        {logs.length === 0 && (
          <div className="h-full flex items-center justify-center text-slate-600 italic">
            Waiting for incoming traffic logs...
          </div>
        )}
      </div>

      <div className="p-3 bg-[#0f172a] border-t border-white/5 flex items-center justify-between text-[10px] text-slate-500 uppercase tracking-widest font-bold">
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><Activity className="w-3 h-3" /> 1.2k req/s</span>
          <span className="flex items-center gap-1"><Terminal className="w-3 h-3" /> SSH: Locked</span>
        </div>
        <span>Seraiph OS v2.4.0</span>
      </div>
    </div>
  );
};
