import React, { useState, useMemo } from 'react';
import { 
  Inbox, Send, Trash2, Archive, Star, AlertCircle, 
  Tag, Plus, Search, Filter, ChevronDown, MoreVertical,
  Reply, Forward, Trash, Archive as ArchiveIcon, 
  Flag, MoreHorizontal, Paperclip, Smile, Image,
  Calendar as CalendarIcon, Users, Settings, HelpCircle,
  Menu, X, Check, Clock, Mail, Layout, 
  ChevronRight, Hash, Circle, Square,
  Maximize2, Minimize2, ExternalLink
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---

type Folder = 'inbox' | 'sent' | 'drafts' | 'trash' | 'archive' | 'spam';

interface EmailAccount {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  color: string;
}

interface Label {
  id: string;
  name: string;
  color: string;
}

interface Email {
  id: string;
  accountId: string;
  from: { name: string; email: string; avatar?: string };
  to: { name: string; email: string }[];
  subject: string;
  body: string;
  timestamp: string;
  folder: Folder;
  isRead: boolean;
  isStarred: boolean;
  labels: string[]; // Label IDs
  attachments?: { name: string; size: string; type: string }[];
}

// --- Mock Data ---

const MOCK_ACCOUNTS: EmailAccount[] = [
  { id: 'acc1', email: 'sinan@seraiph-os.com', name: 'Sinan Bulucu', color: 'bg-indigo-500' },
  { id: 'acc2', email: 'admin@firmamyayinda.com', name: 'Admin', color: 'bg-emerald-500' },
  { id: 'acc3', email: 'support@agriportal.tr', name: 'Support', color: 'bg-amber-500' },
];

const MOCK_LABELS: Label[] = [
  { id: 'l1', name: 'Work', color: 'bg-blue-500' },
  { id: 'l2', name: 'Personal', color: 'bg-emerald-500' },
  { id: 'l3', name: 'Urgent', color: 'bg-rose-500' },
  { id: 'l4', name: 'Finance', color: 'bg-amber-500' },
];

const MOCK_EMAILS: Email[] = [
  {
    id: '1',
    accountId: 'acc1',
    from: { name: 'Seraiph System', email: 'system@seraiph-os.com' },
    to: [{ name: 'Sinan Bulucu', email: 'sinan@seraiph-os.com' }],
    subject: 'Welcome to Seraiph Mail Pro',
    body: 'Hello Sinan,\n\nWelcome to the new Seraiph Mail. We have integrated advanced features like multiple account management, integrated calendar, and a powerful labeling system to boost your productivity.\n\nBest regards,\nThe Seraiph Team',
    timestamp: '10:30 AM',
    folder: 'inbox',
    isRead: false,
    isStarred: true,
    labels: ['l1', 'l3'],
  },
  {
    id: '2',
    accountId: 'acc1',
    from: { name: 'GitHub', email: 'noreply@github.com' },
    to: [{ name: 'Sinan Bulucu', email: 'sinan@seraiph-os.com' }],
    subject: '[Seraiph-OS] New issue: Sidebar navigation bug',
    body: 'A new issue has been opened in the Seraiph-OS repository. Please review the details and assign a developer.',
    timestamp: '09:15 AM',
    folder: 'inbox',
    isRead: true,
    isStarred: false,
    labels: ['l1'],
  },
  {
    id: '3',
    accountId: 'acc2',
    from: { name: 'Customer Support', email: 'support@external.com' },
    to: [{ name: 'Admin', email: 'admin@firmamyayinda.com' }],
    subject: 'Inquiry about pricing plans',
    body: 'Dear Admin,\n\nI would like to know more about your enterprise pricing plans for FirmamYayinda. Could you please send me a detailed brochure?\n\nThank you.',
    timestamp: 'Yesterday',
    folder: 'inbox',
    isRead: true,
    isStarred: false,
    labels: ['l4'],
  },
];

// --- Components ---

export const SeraiphMailApp: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [activeView, setActiveView] = useState<'mail' | 'calendar' | 'contacts'>('mail');
  const [selectedAccountId, setSelectedAccountId] = useState<string>(MOCK_ACCOUNTS[0].id);
  const [activeFolder, setActiveFolder] = useState<Folder>('inbox');
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(MOCK_EMAILS[0].id);
  const [searchQuery, setSearchQuery] = useState('');
  const [isComposeOpen, setIsComposeOpen] = useState(false);

  const filteredEmails = useMemo(() => {
    return MOCK_EMAILS.filter(email => 
      email.accountId === selectedAccountId && 
      email.folder === activeFolder &&
      (email.subject.toLowerCase().includes(searchQuery.toLowerCase()) || 
       email.from.name.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [selectedAccountId, activeFolder, searchQuery]);

  const selectedEmail = useMemo(() => 
    MOCK_EMAILS.find(e => e.id === selectedEmailId), 
    [selectedEmailId]
  );

  return (
    <div className="flex h-full bg-[#0f172a] text-slate-300 overflow-hidden rounded-3xl border border-white/5 shadow-2xl animate-in fade-in zoom-in-95 duration-500">
      {/* --- App Sidebar (Slim) --- */}
      <div className="w-16 flex flex-col items-center py-6 bg-[#0f172a] border-r border-white/5 gap-8">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-600/20">
          <Mail className="w-6 h-6 text-white" />
        </div>
        
        <div className="flex flex-col gap-4">
          <button 
            onClick={() => setActiveView('mail')}
            className={cn(
              "p-3 rounded-xl transition-all group relative",
              activeView === 'mail' ? "bg-indigo-600/10 text-indigo-400" : "text-slate-500 hover:text-slate-300"
            )}
          >
            <Inbox className="w-6 h-6" />
            {activeView === 'mail' && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-indigo-500 rounded-r-full" />}
          </button>
          <button 
            onClick={() => setActiveView('calendar')}
            className={cn(
              "p-3 rounded-xl transition-all group relative",
              activeView === 'calendar' ? "bg-indigo-600/10 text-indigo-400" : "text-slate-500 hover:text-slate-300"
            )}
          >
            <CalendarIcon className="w-6 h-6" />
            {activeView === 'calendar' && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-indigo-500 rounded-r-full" />}
          </button>
          <button 
            onClick={() => setActiveView('contacts')}
            className={cn(
              "p-3 rounded-xl transition-all group relative",
              activeView === 'contacts' ? "bg-indigo-600/10 text-indigo-400" : "text-slate-500 hover:text-slate-300"
            )}
          >
            <Users className="w-6 h-6" />
            {activeView === 'contacts' && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-indigo-500 rounded-r-full" />}
          </button>
        </div>

        <div className="mt-auto flex flex-col gap-4">
          <button className="p-3 text-slate-500 hover:text-slate-300 transition-all">
            <Settings className="w-6 h-6" />
          </button>
          <button onClick={onBack} className="p-3 text-slate-500 hover:text-rose-400 transition-all">
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      {activeView === 'mail' ? (
        <>
          {/* --- Folders & Accounts Pane --- */}
          <div className="w-64 bg-[#1e293b]/50 border-r border-white/5 flex flex-col">
            <div className="p-6">
              <button 
                onClick={() => setIsComposeOpen(true)}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" /> New Message
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-4 space-y-8 pb-8">
              {/* Accounts */}
              <div className="space-y-2">
                <h3 className="px-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Accounts</h3>
                {MOCK_ACCOUNTS.map(acc => (
                  <button 
                    key={acc.id}
                    onClick={() => setSelectedAccountId(acc.id)}
                    className={cn(
                      "w-full flex items-center gap-3 p-2 rounded-xl transition-all group",
                      selectedAccountId === acc.id ? "bg-indigo-600/10 text-indigo-400" : "hover:bg-white/5 text-slate-400"
                    )}
                  >
                    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-bold text-white", acc.color)}>
                      {acc.name.charAt(0)}
                    </div>
                    <div className="flex-1 text-left truncate">
                      <p className="text-xs font-bold truncate">{acc.name}</p>
                      <p className="text-[10px] opacity-50 truncate">{acc.email}</p>
                    </div>
                  </button>
                ))}
              </div>

              {/* Folders */}
              <div className="space-y-1">
                <h3 className="px-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Folders</h3>
                {[
                  { id: 'inbox', label: 'Inbox', icon: Inbox, count: 2 },
                  { id: 'sent', label: 'Sent', icon: Send },
                  { id: 'drafts', label: 'Drafts', icon: Archive },
                  { id: 'trash', label: 'Trash', icon: Trash2 },
                  { id: 'archive', label: 'Archive', icon: ArchiveIcon },
                  { id: 'spam', label: 'Spam', icon: AlertCircle },
                ].map(folder => (
                  <button 
                    key={folder.id}
                    onClick={() => setActiveFolder(folder.id as Folder)}
                    className={cn(
                      "w-full flex items-center justify-between p-2 rounded-xl transition-all group",
                      activeFolder === folder.id ? "bg-white/5 text-white" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <folder.icon className="w-4 h-4" />
                      <span className="text-xs font-medium">{folder.label}</span>
                    </div>
                    {folder.count && (
                      <span className="px-1.5 py-0.5 bg-indigo-600 text-white text-[10px] font-bold rounded-md">
                        {folder.count}
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {/* Labels */}
              <div className="space-y-1">
                <div className="flex items-center justify-between px-2 mb-2">
                  <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Labels</h3>
                  <button className="text-slate-500 hover:text-white transition-colors">
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
                {MOCK_LABELS.map(label => (
                  <button 
                    key={label.id}
                    className="w-full flex items-center gap-3 p-2 rounded-xl text-slate-500 hover:text-slate-300 transition-all group"
                  >
                    <div className={cn("w-2 h-2 rounded-full", label.color)} />
                    <span className="text-xs font-medium">{label.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* --- Message List Pane --- */}
          <div className="w-80 bg-[#0f172a] border-r border-white/5 flex flex-col">
            <div className="p-4 border-b border-white/5 space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input 
                  type="text"
                  placeholder="Search in messages..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#1e293b] border border-white/5 rounded-xl py-2 pl-10 pr-4 text-xs text-slate-300 focus:outline-none focus:border-indigo-500/50"
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button className="text-[10px] font-bold text-indigo-400 flex items-center gap-1">
                    Focused <ChevronDown className="w-3 h-3" />
                  </button>
                  <button className="text-[10px] font-bold text-slate-500">Other</button>
                </div>
                <button className="p-1.5 text-slate-500 hover:text-white transition-all">
                  <Filter className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {filteredEmails.length > 0 ? (
                filteredEmails.map(email => (
                  <button 
                    key={email.id}
                    onClick={() => setSelectedEmailId(email.id)}
                    className={cn(
                      "w-full p-4 text-left border-b border-white/5 transition-all group relative",
                      selectedEmailId === email.id ? "bg-indigo-600/5" : "hover:bg-white/5",
                      !email.isRead && "bg-indigo-600/[0.02]"
                    )}
                  >
                    {!email.isRead && <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500" />}
                    <div className="flex items-center justify-between mb-1">
                      <span className={cn("text-xs font-bold truncate", !email.isRead ? "text-white" : "text-slate-400")}>
                        {email.from.name}
                      </span>
                      <span className="text-[10px] text-slate-500">{email.timestamp}</span>
                    </div>
                    <p className={cn("text-xs truncate mb-1", !email.isRead ? "text-slate-200 font-medium" : "text-slate-400")}>
                      {email.subject}
                    </p>
                    <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                      {email.body}
                    </p>
                    <div className="flex items-center gap-1 mt-2">
                      {email.labels.map(lId => {
                        const label = MOCK_LABELS.find(l => l.id === lId);
                        return label ? (
                          <div key={lId} className={cn("w-1.5 h-1.5 rounded-full", label.color)} />
                        ) : null;
                      })}
                      {email.isStarred && <Star className="w-3 h-3 text-amber-500 fill-amber-500 ml-auto" />}
                    </div>
                  </button>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-600 space-y-4">
                  <Inbox className="w-12 h-12 opacity-20" />
                  <p className="text-sm font-medium">No messages found</p>
                </div>
              )}
            </div>
          </div>

          {/* --- Message Detail Pane --- */}
          <div className="flex-1 bg-[#0f172a] flex flex-col min-w-0">
            {selectedEmail ? (
              <>
                {/* Toolbar */}
                <div className="h-14 border-b border-white/5 flex items-center justify-between px-6 shrink-0">
                  <div className="flex items-center gap-1">
                    <button className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-all" title="Reply">
                      <Reply className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-all" title="Forward">
                      <Forward className="w-4 h-4" />
                    </button>
                    <div className="w-px h-4 bg-white/10 mx-2" />
                    <button className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-all" title="Delete">
                      <Trash className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-all" title="Archive">
                      <ArchiveIcon className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-all" title="Flag">
                      <Flag className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-all">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-8 space-y-8">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-lg font-bold text-white shadow-xl shadow-indigo-600/20">
                        {selectedEmail.from.name.charAt(0)}
                      </div>
                      <div>
                        <h2 className="text-xl font-bold text-white">{selectedEmail.subject}</h2>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs font-bold text-slate-300">{selectedEmail.from.name}</span>
                          <span className="text-xs text-slate-500">&lt;{selectedEmail.from.email}&gt;</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-slate-500">{selectedEmail.timestamp}</p>
                      <div className="flex items-center gap-1 mt-2 justify-end">
                        {selectedEmail.labels.map(lId => {
                          const label = MOCK_LABELS.find(l => l.id === lId);
                          return label ? (
                            <span key={lId} className={cn("px-2 py-0.5 rounded-md text-[10px] font-bold text-white", label.color)}>
                              {label.name}
                            </span>
                          ) : null;
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="prose prose-invert max-w-none">
                    <div className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {selectedEmail.body}
                    </div>
                  </div>

                  {/* Quick Reply Box */}
                  <div className="pt-8 border-t border-white/5">
                    <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-4 focus-within:border-indigo-500/50 transition-all">
                      <textarea 
                        placeholder="Click here to reply..."
                        className="w-full bg-transparent border-none focus:ring-0 text-sm text-slate-300 resize-none h-24"
                      />
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center gap-1">
                          <button className="p-2 text-slate-500 hover:text-slate-300 transition-all"><Paperclip className="w-4 h-4" /></button>
                          <button className="p-2 text-slate-500 hover:text-slate-300 transition-all"><Smile className="w-4 h-4" /></button>
                          <button className="p-2 text-slate-500 hover:text-slate-300 transition-all"><Image className="w-4 h-4" /></button>
                        </div>
                        <button className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/20">
                          Send Reply
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-600 space-y-4">
                <Mail className="w-16 h-16 opacity-10" />
                <p className="text-lg font-medium">Select a message to read</p>
              </div>
            )}
          </div>
        </>
      ) : activeView === 'calendar' ? (
        <div className="flex-1 bg-[#0f172a] flex flex-col p-8 space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">Calendar</h2>
            <div className="flex items-center gap-4">
              <div className="flex bg-[#1e293b] rounded-xl p-1 border border-white/5">
                <button className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 rounded-lg shadow-lg">Month</button>
                <button className="px-4 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-300">Week</button>
                <button className="px-4 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-300">Day</button>
              </div>
              <button className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/20 flex items-center gap-2">
                <Plus className="w-4 h-4" /> New Event
              </button>
            </div>
          </div>

          <div className="flex-1 bg-[#1e293b]/30 rounded-3xl border border-white/5 overflow-hidden flex flex-col">
            <div className="grid grid-cols-7 border-b border-white/5 bg-[#0f172a]/50">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                <div key={day} className="py-4 text-center text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                  {day}
                </div>
              ))}
            </div>
            <div className="flex-1 grid grid-cols-7 grid-rows-5">
              {Array.from({ length: 35 }).map((_, i) => {
                const day = i - 1; // Simple mock offset
                const isToday = day === 9;
                return (
                  <div key={i} className="border-r border-b border-white/5 p-2 min-h-[120px] hover:bg-white/[0.02] transition-colors group">
                    <div className="flex items-center justify-between mb-2">
                      <span className={cn(
                        "w-7 h-7 flex items-center justify-center text-xs font-bold rounded-lg",
                        isToday ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : "text-slate-500 group-hover:text-slate-300"
                      )}>
                        {day > 0 && day <= 31 ? day : ''}
                      </span>
                    </div>
                    {isToday && (
                      <div className="space-y-1">
                        <div className="px-2 py-1 bg-indigo-500/20 border-l-2 border-indigo-500 rounded text-[10px] font-bold text-indigo-300 truncate">
                          Seraiph Team Sync
                        </div>
                        <div className="px-2 py-1 bg-emerald-500/20 border-l-2 border-emerald-500 rounded text-[10px] font-bold text-emerald-300 truncate">
                          Project Launch
                        </div>
                      </div>
                    )}
                    {day === 15 && (
                      <div className="px-2 py-1 bg-amber-500/20 border-l-2 border-amber-500 rounded text-[10px] font-bold text-amber-300 truncate">
                        Client Meeting
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-600 space-y-4">
          <Users className="w-16 h-16 opacity-10" />
          <p className="text-lg font-medium">Contacts view coming soon</p>
        </div>
      )}

      {/* --- Compose Modal --- */}
      {isComposeOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-[#1e293b] w-full max-w-2xl rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-4 bg-[#0f172a]/50 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-sm font-bold text-white">New Message</h2>
              <div className="flex items-center gap-2">
                <button className="p-2 text-slate-500 hover:text-white transition-all"><Minimize2 className="w-4 h-4" /></button>
                <button className="p-2 text-slate-500 hover:text-white transition-all"><Maximize2 className="w-4 h-4" /></button>
                <button onClick={() => setIsComposeOpen(false)} className="p-2 text-slate-500 hover:text-rose-400 transition-all"><X className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-4 border-b border-white/5 pb-2">
                <span className="text-xs font-bold text-slate-500 w-8">To</span>
                <input type="text" className="flex-1 bg-transparent border-none focus:ring-0 text-sm text-slate-200" />
              </div>
              <div className="flex items-center gap-4 border-b border-white/5 pb-2">
                <span className="text-xs font-bold text-slate-500 w-8">Cc</span>
                <input type="text" className="flex-1 bg-transparent border-none focus:ring-0 text-sm text-slate-200" />
              </div>
              <div className="flex items-center gap-4 border-b border-white/5 pb-2">
                <span className="text-xs font-bold text-slate-500 w-8">Sub</span>
                <input type="text" className="flex-1 bg-transparent border-none focus:ring-0 text-sm text-slate-200" />
              </div>
              <textarea 
                placeholder="Write your message here..."
                className="w-full bg-transparent border-none focus:ring-0 text-sm text-slate-200 resize-none h-64"
              />
            </div>
            <div className="p-4 bg-[#0f172a]/50 border-t border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-1">
                <button className="p-2 text-slate-500 hover:text-slate-300 transition-all"><Paperclip className="w-4 h-4" /></button>
                <button className="p-2 text-slate-500 hover:text-slate-300 transition-all"><Smile className="w-4 h-4" /></button>
                <button className="p-2 text-slate-500 hover:text-slate-300 transition-all"><Image className="w-4 h-4" /></button>
                <div className="w-px h-4 bg-white/10 mx-2" />
                <button className="p-2 text-slate-500 hover:text-slate-300 transition-all"><Tag className="w-4 h-4" /></button>
              </div>
              <div className="flex items-center gap-3">
                <button onClick={() => setIsComposeOpen(false)} className="px-6 py-2 text-xs font-bold text-slate-500 hover:text-slate-300 transition-all">Discard</button>
                <button className="px-8 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/20">
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
