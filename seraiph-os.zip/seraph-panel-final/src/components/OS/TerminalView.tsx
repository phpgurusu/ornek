import React, { useState, useEffect, useRef } from 'react';
import { Terminal as TerminalIcon, Fullscreen, Minimize2, Trash2 } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const TerminalView: React.FC<{ 
  onClose?: () => void; 
  isMinimized?: boolean; 
  onMinimize?: () => void;
  className?: string;
  hideHeader?: boolean;
}> = ({ onClose, isMinimized, onMinimize, className, hideHeader }) => {
  const [history, setHistory] = useState<string[]>([
    'Seraiph OS v1.0.4 (GNU/Linux 5.15.0-71-generic x86_64)',
    'Welcome to Seraiph Cloud Terminal. Type "help" for a list of commands.',
    '',
    'Last login: Sat May 09 15:42:11 2026 from 192.168.1.104',
  ]);
  const [input, setInput] = useState('');
  const [currentSession, setCurrentSession] = useState('Default Shell');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  if (isMinimized) return null;

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const cmd = input.trim().toLowerCase();
    const newHistory = [...history, `seraiph@root:~$ ${input}`];

    switch (cmd) {
      case 'help':
        newHistory.push(
          'Available commands:',
          '  help      - Show this help message',
          '  clear     - Clear the terminal screen',
          '  ls        - List directory contents',
          '  whoami    - Display current user',
          '  status    - Show system status',
          '  docker ps - List running containers',
          '  date      - Show current date and time',
          '  exit      - Terminate current session'
        );
        break;
      case 'clear':
        setHistory([]);
        setInput('');
        return;
      case 'exit':
        if (onClose) onClose();
        return;
      case 'ls':
        newHistory.push('apps/  data/  logs/  src/  docker-compose.yml  package.json');
        break;
      case 'whoami':
        newHistory.push('root');
        break;
      case 'status':
        newHistory.push(
          'System Status:',
          '  Uptime: 14 days, 2 hours',
          '  Load Average: 0.42, 0.38, 0.35',
          '  Active Servies: 12',
          '  Security Shield: ACTIVE'
        );
        break;
      case 'docker ps':
        newHistory.push(
          'CONTAINER ID   IMAGE               STATUS          PORTS',
          'f8e2d9a1b2c3   go-backend:v1.1     Up 14 days      0.0.0.0:8080->8080/tcp',
          'a1b2c3d4e5f6   react-frontend:v2   Up 14 days      0.0.0.0:3000->3000/tcp',
          'd5e6f7g8h9i0   postgres:16         Up 32 days      0.0.0.0:5432->5432/tcp'
        );
        break;
      case 'date':
        newHistory.push(new Date().toString());
        break;
      default:
        newHistory.push(`Command not found: ${cmd}`);
    }

    setHistory(newHistory);
    setInput('');
  };

  return (
    <div className={cn(
      "h-full flex flex-col bg-[#010409] overflow-hidden transition-all duration-500",
      !className && "rounded-3xl border border-white/10 shadow-2xl ring-1 ring-white/5 animate-in fade-in zoom-in-95",
      className
    )}>
      {/* Terminal Title Bar */}
      {!hideHeader && (
        <div className="px-6 py-3 bg-[#161b22] border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex gap-2">
              <button onClick={onClose} className="w-3 h-3 rounded-full bg-rose-500 hover:bg-rose-400 transition-colors shadow-lg shadow-rose-500/20" />
              <button onClick={onMinimize} className="w-3 h-3 rounded-full bg-amber-500 hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/20" />
              <button className="w-3 h-3 rounded-full bg-emerald-500 hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20" />
            </div>
            <div className="h-4 w-px bg-white/10 mx-2" />
            <div className="flex items-center gap-3">
              <div className="flex bg-[#0d1117] rounded-lg p-0.5 border border-white/5">
                 <button onClick={() => setCurrentSession('Default Shell')} className={cn("px-3 py-1 text-[9px] font-bold uppercase tracking-widest rounded-md transition-all", currentSession === 'Default Shell' ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300")}>
                    SSH: Main
                 </button>
                 <button onClick={() => setCurrentSession('Docker Logs')} className={cn("px-3 py-1 text-[9px] font-bold uppercase tracking-widest rounded-md transition-all", currentSession === 'Docker Logs' ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300")}>
                    Logs
                 </button>
              </div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                 <TerminalIcon className="w-3 h-3" />
                 seraiph@cloud-shell
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setHistory([])}
              className="p-2 hover:bg-rose-500/10 rounded-xl text-slate-500 hover:text-rose-500 transition-all border border-transparent hover:border-rose-500/20"
              title="Clear History"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button className="p-2 hover:bg-white/5 rounded-xl text-slate-500 hover:text-white transition-all border border-transparent hover:border-white/10">
              <Fullscreen className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Terminal Output */}
      <div 
        ref={scrollRef}
        className="flex-1 p-6 overflow-y-auto font-mono text-sm custom-scrollbar bg-[#0f172a]/80"
      >
        <div className="space-y-1">
          {history.map((line, i) => (
            <div key={i} className={line.startsWith('seraiph@root') ? "text-emerald-400" : line.includes('ERROR') ? "text-rose-500" : "text-slate-300"}>
              {line}
            </div>
          ))}
          <form onSubmit={handleCommand} className="flex items-center gap-2 pt-1">
            <span className="text-emerald-400 shrink-0">seraiph@root:~$</span>
            <input 
              autoFocus
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none text-white p-0 focus:ring-0"
            />
          </form>
        </div>
      </div>

      {/* Terminal Footer */}
      <div className="px-6 py-2 bg-[#1e293b]/50 border-t border-white/5 flex items-center justify-between text-[10px] text-slate-500 font-bold uppercase tracking-widest">
        <div className="flex items-center gap-4">
          <span>UTF-8</span>
          <span>Linux (x64)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Connected</span>
        </div>
      </div>
    </div>
  );
};
