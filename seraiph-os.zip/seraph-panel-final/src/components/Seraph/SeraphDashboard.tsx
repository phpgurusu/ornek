import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Shield, Activity, Cpu, GitBranch, Layers, Zap,
  ArrowLeft, RefreshCcw, Download, Terminal, Lock,
  ChevronRight, Dna, Network, Bug, Waves, CheckCircle2
} from 'lucide-react';
import { SeraphService, SeraphCertificate, SideChain, SeraphLogEntry } from '../../services/seraph';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, RadarChart, Radar,
  PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from 'recharts';

function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)); }

// ── DNA Animasyon Bileşeni ─────────────────────────────────────
const DnaStrand: React.FC<{ dna: string }> = ({ dna }) => {
  const [animated, setAnimated] = useState(dna);
  useEffect(() => {
    const id = setInterval(() => {
      setAnimated(SeraphService.mutateDna(dna, 0.018));
    }, 180);
    return () => clearInterval(id);
  }, [dna]);

  return (
    <span className="font-mono text-xs tracking-wider">
      {animated.split('').map((c, i) => (
        <span key={i} className={cn(
          c === 'A' && 'text-emerald-400',
          c === 'T' && 'text-red-400',
          c === 'C' && 'text-blue-400',
          c === 'G' && 'text-amber-400',
          c === '-' && 'text-slate-700',
        )}>{c}</span>
      ))}
    </span>
  );
};

// ── Feromon Bar ────────────────────────────────────────────────
const PheromoneBar: React.FC<{ value: number; color: string }> = ({ value, color }) => (
  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
    <div
      className="h-full rounded-full transition-all duration-700"
      style={{ width: `${value * 100}%`, background: `linear-gradient(90deg, ${color}60, ${color})` }}
    />
  </div>
);

// ── Metrik Kart ────────────────────────────────────────────────
const MetricCard: React.FC<{
  label: string; value: string | number; sub?: string;
  accent: string; icon?: React.ReactNode;
}> = ({ label, value, sub, accent, icon }) => (
  <div className="bg-[#0f172a] rounded-2xl p-4 border border-white/5"
    style={{ borderLeft: `3px solid ${accent}` }}>
    <div className="flex items-start justify-between mb-1">
      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{label}</p>
      {icon && <span style={{ color: accent }} className="opacity-60">{icon}</span>}
    </div>
    <p className="text-xl font-black text-white font-mono" style={{ color: accent }}>{value}</p>
    {sub && <p className="text-[9px] text-slate-600 mt-1 font-mono">{sub}</p>}
  </div>
);

// ── Ağ Topolojisi Canvas ───────────────────────────────────────
const NetworkCanvas: React.FC<{
  chains: SideChain[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}> = ({ chains, selectedId, onSelect }) => {
  const W = 520, H = 300;
  const cx = W / 2 - 40, cy = H / 2;

  const nodes = chains.map((sc) => {
    const groups = ['A', 'B', 'C', 'D'];
    const gIdx = groups.indexOf(sc.group);
    const groupChains = chains.filter(c => c.group === sc.group);
    const idx = groupChains.indexOf(sc);
    const base = (gIdx / 4) * 2 * Math.PI - Math.PI / 2;
    const angle = base + (idx - (groupChains.length - 1) / 2) * 0.38;
    const r = 96 + idx * 20;
    return { ...sc, x: cx + Math.cos(angle) * r, y: cy + Math.sin(angle) * r };
  });

  const mainY = [48, 100, 155, 208, 258];
  const mainX = W - 52;

  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} className="block">
      <defs>
        <radialGradient id="sg-hub" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#6366f1" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
        </radialGradient>
        <filter id="sg-glow">
          <feGaussianBlur stdDeviation="2" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      {/* Spider web rings */}
      {[48, 90, 130].map((r, i) => (
        <ellipse key={i} cx={cx} cy={cy} rx={r} ry={r * 0.85}
          fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 5" />
      ))}
      {Array.from({ length: 8 }, (_, i) => {
        const a = (i / 8) * 2 * Math.PI;
        return <line key={i} x1={cx} y1={cy}
          x2={cx + Math.cos(a) * 140} y2={cy + Math.sin(a) * 125}
          stroke="#1e293b" strokeWidth="0.5" />;
      })}

      {/* Hub glow */}
      <circle cx={cx} cy={cy} r={52} fill="url(#sg-hub)" />

      {/* Pheromone trails */}
      {nodes.map(sc => {
        const col = SeraphService.groupColor(sc.group).dot;
        return (
          <line key={`t-${sc.id}`} x1={sc.x} y1={sc.y}
            x2={mainX} y2={mainY[sc.block - 1] ?? mainY[0]}
            stroke={col} strokeWidth={1.5} strokeDasharray="3 4" opacity={sc.phero * 0.65} />
        );
      })}

      {/* SC→SC links */}
      {nodes.map(sc => sc.links.map(lid => {
        const t = nodes.find(n => n.id === lid);
        if (!t) return null;
        return <line key={`l-${sc.id}-${lid}`} x1={sc.x} y1={sc.y}
          x2={t.x} y2={t.y} stroke="#1e3a52" strokeWidth="0.8" opacity="0.5" />;
      }))}

      {/* Main blocks */}
      {[1, 2, 3, 4, 5].map((h, i) => (
        <g key={h}>
          <rect x={mainX - 34} y={mainY[i] - 16} width={68} height={32} rx={4}
            fill="#0f172a" stroke="#334155" strokeWidth="1" />
          <text x={mainX} y={mainY[i] - 3} textAnchor="middle"
            className="fill-blue-400" fontSize="8" fontFamily="monospace">Block #{h}</text>
          <text x={mainX} y={mainY[i] + 9} textAnchor="middle"
            className="fill-slate-600" fontSize="7" fontFamily="monospace">
            {chains.filter(sc => sc.block === h).length} SC
          </text>
        </g>
      ))}

      {/* SC nodes */}
      {nodes.map(sc => {
        const col = SeraphService.groupColor(sc.group);
        const sel = selectedId === sc.id;
        return (
          <g key={sc.id} onClick={() => onSelect(sel ? null : sc.id)} className="cursor-pointer">
            {sel && <circle cx={sc.x} cy={sc.y} r={18}
              fill="none" stroke={col.dot} strokeWidth="1.5" opacity="0.4" />}
            <circle cx={sc.x} cy={sc.y} r={sel ? 13 : 10}
              fill={col.bg} stroke={col.border} strokeWidth={sel ? 2 : 1}
              filter={sel ? 'url(#sg-glow)' : undefined} />
            <text x={sc.x} y={sc.y + 4} textAnchor="middle"
              fontSize="6.5" fontFamily="monospace" fill={col.text}>
              {sc.id.replace('SC-', '')}
            </text>
          </g>
        );
      })}

      {/* Center */}
      <circle cx={cx} cy={cy} r={16} fill="#020b14" stroke="#6366f1" strokeWidth="1.5" />
      <text x={cx} y={cy - 3} textAnchor="middle" fontSize="6" fontFamily="monospace" fill="#818cf8">SERAPH</text>
      <text x={cx} y={cy + 7} textAnchor="middle" fontSize="5" fontFamily="monospace" fill="#334155">CORE</text>
    </svg>
  );
};

// ── Ana SERAPH Dashboard Bileşeni ─────────────────────────────
interface SeraphDashboardProps {
  onBack: () => void;
}

export const SeraphDashboard: React.FC<SeraphDashboardProps> = ({ onBack }) => {
  const [cert] = useState<SeraphCertificate>(SeraphService.getCertificate());
  const [activeTab, setActiveTab] = useState<'overview' | 'chains' | 'algorithms' | 'logs'>('overview');
  const [selectedChain, setSelectedChain] = useState<string | null>(null);
  const [logs, setLogs] = useState<SeraphLogEntry[]>([
    { id: 'init-0', ts: '00:00:00.000', layer: 'SYSTEM', event: 'SERAPH protokolü başlatıldı — seraph-mainnet-1', color: '#60a5fa' },
    { id: 'init-1', ts: '00:00:00.141', layer: 'SYSTEM', event: 'CONVERGED — 12/12 yan zincir mühürlendi ✦', color: '#4ade80' },
  ]);
  const [pheromones, setPheromones] = useState<Record<string, number>>(
    Object.fromEntries(cert.side_chains.map(sc => [sc.id, sc.phero]))
  );
  const [blockHeight, setBlockHeight] = useState(cert.layers.go.height);
  const logEndRef = useRef<HTMLDivElement>(null);

  // Canlı log akışı
  useEffect(() => {
    const id = setInterval(() => {
      const entry = SeraphService.generateLogEntry();
      setLogs(prev => [...prev.slice(-80), entry]);
      // Feromon simülasyonu
      setPheromones(prev => {
        const next = { ...prev };
        const keys = Object.keys(next);
        const key = keys[Math.floor(Math.random() * keys.length)];
        next[key] = SeraphService.updatePheromone(next[key]);
        return next;
      });
      // Blok yüksekliği
      if (Math.random() < 0.08) setBlockHeight(h => h + 1);
    }, 1400);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const selectedSC = cert.side_chains.find(sc => sc.id === selectedChain);
  const py = cert.layers.python;

  // Radar chart verisi
  const radarData = [
    { subject: 'Spider', value: Math.round(py.spider.density * 100) },
    { subject: 'Ant', value: Math.round(py.ant.active_trails / py.ant.total_trails * 100) },
    { subject: 'Butterfly', value: Math.abs(py.butterfly.lyapunov_exp) < 0.1 ? 90 : 70 },
    { subject: 'Genetic', value: Math.round(py.genetic.best_fitness) },
    { subject: 'Consensus', value: 99 },
  ];

  // Fitness tarih grafiği
  const fitnessHistory = Array.from({ length: 10 }, (_, i) => ({
    gen: i * 5,
    fitness: Math.min(99.99, 70 + py.genetic.improvement * (i / 9) + Math.random() * 2),
  }));
  fitnessHistory[9].fitness = py.genetic.best_fitness;

  const tabs = [
    { id: 'overview', label: 'Genel Bakış', icon: Activity },
    { id: 'chains', label: 'Zincirler', icon: GitBranch },
    { id: 'algorithms', label: 'Algoritmalar', icon: Cpu },
    { id: 'logs', label: 'Sistem Günlüğü', icon: Terminal },
  ] as const;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">

      {/* ── Header ─────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-3">
              SERAPH
              <span className="text-xs font-bold px-2 py-0.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-full tracking-widest">
                v2.1
              </span>
            </h1>
            <p className="text-xs text-slate-500 mt-0.5 font-mono">
              Spider · Ant · Butterfly · Genetic × Cosmos SDK — {cert.chain_id}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">CONVERGED</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#1e293b] border border-white/5 rounded-xl">
            <Layers className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 font-mono">Block #{blockHeight}</span>
          </div>
        </div>
      </div>

      {/* ── Cert ID Banner ──────────────────────────────────────── */}
      <div className="bg-[#1e293b] rounded-3xl p-6 border border-white/5 border-l-4 border-l-indigo-500 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-5">
          <Lock className="w-32 h-32 text-indigo-500" />
        </div>
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">SERAPH SERTİFİKA</p>
            <p className="text-2xl font-black text-white font-mono">{cert.cert_id}</p>
            <p className="text-[10px] text-slate-600 font-mono mt-1 break-all">{cert.cert_hash.slice(0, 48)}...</p>
          </div>
          <div className="flex flex-col gap-2 text-right shrink-0">
            <div className="text-[10px] text-slate-500 font-mono">{cert.sealed_count}/{cert.total_chains} mühürlü</div>
            <div className="text-[10px] text-slate-500 font-mono">Gas: {cert.layers.rust.gas_used.toLocaleString()} units</div>
            <div className="text-[10px] text-slate-500 font-mono">Fitness: {py.genetic.best_fitness}%</div>
          </div>
        </div>
      </div>

      {/* ── Tabs ────────────────────────────────────────────────── */}
      <div className="flex bg-[#1e293b] rounded-2xl border border-white/5 p-1 gap-1">
        {tabs.map(tab => (
          <button key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold transition-all',
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            )}>
            <tab.icon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* ══════════════════════════════════════════════════════════
          GENEL BAKIŞ
      ══════════════════════════════════════════════════════════ */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Metrik kartlar */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard label="MÜHÜR" value={`${cert.sealed_count}/${cert.total_chains}`}
              sub="Tam zincir oluştu" accent="#4ade80" icon={<CheckCircle2 className="w-4 h-4" />} />
            <MetricCard label="FITNESS" value={`${py.genetic.best_fitness}%`}
              sub={`GEN#${py.genetic.generations}`} accent="#f59e0b" icon={<Dna className="w-4 h-4" />} />
            <MetricCard label="GAS" value={cert.layers.rust.gas_used.toLocaleString()}
              sub="CosmWasm units" accent="#a78bfa" icon={<Zap className="w-4 h-4" />} />
            <MetricCard label="LYAPUNOV" value={py.butterfly.lyapunov_exp}
              sub={`λ=${py.butterfly.lambda}`} accent="#f472b6" icon={<Waves className="w-4 h-4" />} />
          </div>

          {/* Ağ + Radar */}
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-3 bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-xl">
              <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Network className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-black text-slate-300 uppercase tracking-widest">Ağ Topolojisi</span>
                </div>
                <span className="text-[9px] font-bold text-indigo-400 font-mono">
                  yoğunluk: {py.spider.density.toFixed(3)} · merkeziyetsiz: {py.spider.is_decentralized ? '✓' : '✗'}
                </span>
              </div>
              <div className="p-2">
                <NetworkCanvas chains={cert.side_chains} selectedId={selectedChain} onSelect={setSelectedChain} />
              </div>
              {selectedSC && (
                <div className="px-6 py-4 border-t border-white/5 bg-[#0f172a]/60">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-black text-sm font-mono" style={{ color: SeraphService.groupColor(selectedSC.group).text }}>
                      {selectedSC.id}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full font-mono">✦ SEALED</span>
                    <span className="text-[10px] text-slate-500 font-mono ml-auto">Block #{selectedSC.block}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <DnaStrand dna={selectedSC.dna} />
                    <div className="text-[10px] text-slate-600 font-mono">φ={pheromones[selectedSC.id]?.toFixed(4)}</div>
                  </div>
                  <PheromoneBar value={pheromones[selectedSC.id] ?? selectedSC.phero}
                    color={SeraphService.groupColor(selectedSC.group).dot} />
                </div>
              )}
            </div>

            <div className="lg:col-span-2 space-y-4">
              {/* Radar */}
              <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-4 shadow-xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3">Algoritma Radar</p>
                <div className="h-[180px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid stroke="#1e293b" />
                      <PolarAngleAxis dataKey="subject" tick={{ fontSize: 9, fill: '#475569', fontFamily: 'monospace' }} />
                      <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                      <Radar name="Score" dataKey="value" stroke="#6366f1" fill="#6366f1" fillOpacity={0.2} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Fitness evrimi */}
              <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-4 shadow-xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3">Fitness Evrimi</p>
                <div className="h-[100px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={fitnessHistory}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                      <XAxis dataKey="gen" tick={{ fontSize: 8, fill: '#475569' }} axisLine={false} tickLine={false} />
                      <YAxis domain={[65, 100]} tick={{ fontSize: 8, fill: '#475569' }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid rgba(255,255,255,0.05)', borderRadius: 8, fontSize: 10 }} />
                      <Line type="monotone" dataKey="fitness" stroke="#4ade80" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Katman özeti */}
              <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-4 shadow-xl space-y-2">
                {[
                  { color: '#00acd7', label: 'Go', detail: `${cert.layers.go.sdk} · CometBFT ${cert.layers.go.cometbft}` },
                  { color: '#ce422b', label: 'Rust', detail: `CosmWasm ${cert.layers.rust.cosmwasm} · ${cert.layers.rust.events} event` },
                  { color: '#3572a5', label: 'Python', detail: `Spider·Ant·Butterfly·Genetic` },
                ].map(({ color, label, detail }) => (
                  <div key={label} className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ background: color }} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black text-slate-300" style={{ color }}>{label}</span>
                        <span className="text-[9px] text-slate-600 font-mono truncate ml-2">{detail}</span>
                      </div>
                    </div>
                    <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* İmzalar */}
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-6 shadow-xl">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Kriptografik İmzalar</p>
            <div className="space-y-2">
              {[
                { label: 'BUTTERFLY SIG', value: cert.butterfly_sig, color: '#f472b6' },
                { label: 'GO ED25519', value: cert.go_node_sig, color: '#00acd7' },
                { label: 'GENOME SIG', value: cert.genome_sig, color: '#4ade80' },
                { label: 'MERKLE COMMITMENT', value: cert.commitment, color: '#f59e0b' },
              ].map(({ label, value, color }) => (
                <div key={label} className="flex items-center gap-4 p-3 bg-[#0f172a]/60 rounded-xl">
                  <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest min-w-[140px]">{label}</span>
                  <span className="font-mono text-[10px] truncate" style={{ color }}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════
          ZİNCİRLER
      ══════════════════════════════════════════════════════════ */}
      {activeTab === 'chains' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Ana bloklar */}
          <div>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3">Ana Zincir Blokları</p>
            <div className="grid grid-cols-5 gap-3">
              {cert.main_blocks.map(mb => (
                <div key={mb.height} className="bg-[#1e293b] rounded-2xl p-4 border border-white/5 border-t-2 border-t-blue-500/40">
                  <div className="font-black text-blue-400 text-sm font-mono mb-2">Block #{mb.height}</div>
                  <div className="text-[9px] text-slate-600 font-mono mb-3 break-all">{mb.hash}</div>
                  <div className="text-[9px] text-slate-500 font-mono mb-2">{mb.ibc} · {mb.votes}✓</div>
                  <div className="flex flex-wrap gap-1">
                    {mb.linked.map(lid => {
                      const col = SeraphService.groupColor(
                        cert.side_chains.find(s => s.id === lid)?.group ?? 'A'
                      );
                      return (
                        <span key={lid} className="text-[8px] px-1.5 py-0.5 rounded font-mono font-bold"
                          style={{ background: col.bg, color: col.text, border: `1px solid ${col.border}` }}>
                          {lid}
                        </span>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SC tablosu */}
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-xl">
            <div className="px-6 py-4 border-b border-white/5">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Yan Zincirler — Mühür Tablosu</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    {['ID', 'GRUP', 'DURUM', 'BLOK', 'FEROMON', 'DNA', 'MÜHÜR', 'BAĞLANTILAR'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-[9px] font-black text-slate-600 uppercase tracking-widest">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cert.side_chains.map((sc, i) => {
                    const col = SeraphService.groupColor(sc.group);
                    const phero = pheromones[sc.id] ?? sc.phero;
                    return (
                      <tr key={sc.id}
                        onClick={() => setSelectedChain(selectedChain === sc.id ? null : sc.id)}
                        className={cn(
                          'border-b border-white/[0.03] cursor-pointer transition-colors',
                          selectedChain === sc.id ? 'bg-indigo-600/5' : i % 2 === 0 ? 'bg-[#0f172a]/30' : ''
                        )}>
                        <td className="px-4 py-3 font-black font-mono text-xs" style={{ color: col.text }}>{sc.id}</td>
                        <td className="px-4 py-3">
                          <span className="text-[9px] px-2 py-0.5 rounded font-mono font-bold"
                            style={{ background: col.bg, color: col.dot, border: `1px solid ${col.border}` }}>
                            Grup {sc.group}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-[9px] px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full font-mono">
                            ✦ {sc.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-blue-400">#{sc.block}</td>
                        <td className="px-4 py-3 min-w-[100px]">
                          <div className="text-[9px] text-slate-500 font-mono mb-1">{phero.toFixed(4)}</div>
                          <PheromoneBar value={phero} color={col.dot} />
                        </td>
                        <td className="px-4 py-3"><DnaStrand dna={sc.dna} /></td>
                        <td className="px-4 py-3 font-mono text-[9px] text-slate-600">{sc.seal?.slice(0, 10)}...</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1 flex-wrap">
                            {sc.links.map(l => <span key={l} className="text-[8px] text-slate-600 font-mono">{l}</span>)}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════
          ALGORİTMALAR
      ══════════════════════════════════════════════════════════ */}
      {activeTab === 'algorithms' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in duration-300">
          {/* Spider */}
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 border-l-4 border-l-purple-500 p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 bg-purple-500/10 rounded-xl border border-purple-500/20">
                <Bug className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h3 className="font-black text-white text-sm uppercase tracking-wide">Örümcek Ağı</h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Merkeziyetsiz topoloji</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <MetricCard label="DÜĞÜM" value={py.spider.node_count} accent="#a78bfa" />
              <MetricCard label="KENAR" value={py.spider.edge_count} accent="#a78bfa" />
              <MetricCard label="YOĞUNLUK" value={py.spider.density.toFixed(3)} accent="#a78bfa" />
              <MetricCard label="ORT. DERECE" value={py.spider.avg_degree} sub={`Merkeziyetsiz: ${py.spider.is_decentralized ? '✓' : '✗'}`} accent="#a78bfa" />
            </div>
            <div className="p-3 bg-[#0f172a] rounded-xl font-mono text-[9px] text-slate-600 space-y-1">
              <div><span className="text-purple-400">density</span> = edges / (n × (n-1))</div>
              <div><span className="text-purple-400">links</span>: en yakın 3 komşuya otomatik bağlan</div>
              <div><span className="text-purple-400">decentralized</span>: max_deg &lt; avg_deg × 2.5</div>
            </div>
          </div>

          {/* Ant */}
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 border-l-4 border-l-amber-500 p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 bg-amber-500/10 rounded-xl border border-amber-500/20">
                <Zap className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <h3 className="font-black text-white text-sm uppercase tracking-wide">Karınca Kolonisi</h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Feromon tabanlı optimizasyon</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <MetricCard label="KARINCA" value={py.ant.ant_count} accent="#f59e0b" />
              <MetricCard label="AKTİF İZ" value={py.ant.active_trails} sub={`/ ${py.ant.total_trails}`} accent="#f59e0b" />
              <MetricCard label="BUHARLAŞMA ρ" value={py.ant.evap_rate} accent="#f59e0b" />
              <MetricCard label="MİN. FEROMON" value="0.01" sub="Asla sıfıra düşmez" accent="#f59e0b" />
            </div>
            <div className="p-3 bg-[#0f172a] rounded-xl font-mono text-[9px] text-slate-600 space-y-1">
              <div><span className="text-amber-400">τ(t+1)</span> = τ(t) × (1-ρ) + Δτ</div>
              <div><span className="text-amber-400">P(i→j)</span> = τ^α × η^β / Σ</div>
              <div><span className="text-amber-400">konvoy</span>: popülasyon asla 0'a düşmez</div>
            </div>
          </div>

          {/* Butterfly */}
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 border-l-4 border-l-pink-500 p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 bg-pink-500/10 rounded-xl border border-pink-500/20">
                <Waves className="w-5 h-5 text-pink-400" />
              </div>
              <div>
                <h3 className="font-black text-white text-sm uppercase tracking-wide">Kelebek Etkisi</h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Kaotik imzalama sistemi</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <MetricCard label="LAMBDA λ" value={py.butterfly.lambda} accent="#f472b6" />
              <MetricCard label="LYAPUNOV" value={py.butterfly.lyapunov_exp} accent="#f472b6" />
              <MetricCard label="KAOTİK" value={py.butterfly.is_chaotic ? 'EVET' : 'YAKIN'} sub="Kaotik bölge sınırı" accent="#f472b6" />
              <MetricCard label="ÜRETİLEN" value={py.butterfly.keys_generated} sub="benzersiz anahtar" accent="#f472b6" />
            </div>
            <div className="p-3 bg-[#0f172a] rounded-xl font-mono text-[9px] text-slate-600 space-y-1">
              <div><span className="text-pink-400">x(n+1)</span> = λ × x(n) × (1 - x(n))</div>
              <div><span className="text-pink-400">ε</span> = 1e-10 · XOR(seq1, seq2+ε)</div>
              <div><span className="text-pink-400">3.57 &lt; λ &lt; 4</span> → tam kaos bölgesi</div>
            </div>
          </div>

          {/* Genetic */}
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 border-l-4 border-l-emerald-500 p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
                <Dna className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="font-black text-white text-sm uppercase tracking-wide">Genetik Algoritma</h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Güvenlik genomu evrimi</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <MetricCard label="NESİL" value={py.genetic.generations} accent="#4ade80" />
              <MetricCard label="FITNESS" value={`${py.genetic.best_fitness}%`} accent="#4ade80" />
              <MetricCard label="GELİŞİM" value={`+${py.genetic.improvement}%`} accent="#4ade80" />
              <MetricCard label="ORT. FITNESS" value={`${py.genetic.avg_fitness}%`} accent="#4ade80" />
            </div>
            <div className="p-3 bg-[#0f172a] rounded-xl">
              <div className="text-[9px] text-slate-600 font-mono mb-2">EN İYİ DNA</div>
              <DnaStrand dna={py.genetic.best_dna} />
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════
          LOGS
      ══════════════════════════════════════════════════════════ */}
      {activeTab === 'logs' && (
        <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-xl animate-in fade-in duration-300">
          <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-black text-slate-300 uppercase tracking-widest">Sistem Günlüğü</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Canlı Akış</span>
            </div>
          </div>
          <div className="h-[480px] overflow-y-auto bg-[#020b14] p-1">
            {logs.map(log => (
              <div key={log.id}
                className="flex items-baseline gap-3 px-4 py-1.5 border-b border-white/[0.02] hover:bg-white/[0.01] transition-colors">
                <span className="font-mono text-[9px] text-slate-700 shrink-0 min-w-[90px]">{log.ts}</span>
                <span className="font-mono text-[9px] font-black shrink-0 min-w-[80px]" style={{ color: log.color }}>
                  [{log.layer}]
                </span>
                <span className="font-mono text-[10px] text-slate-500">{log.event}</span>
              </div>
            ))}
            <div ref={logEndRef} />
          </div>
        </div>
      )}

      {/* Quick actions footer */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
        {[
          { label: 'Sertifika Yenile', icon: RefreshCcw, color: 'hover:bg-indigo-600' },
          { label: 'JSON İndir', icon: Download, color: 'hover:bg-emerald-600' },
          { label: 'Terminal', icon: Terminal, color: 'hover:bg-amber-600' },
          { label: 'Zinciri Gör', icon: GitBranch, color: 'hover:bg-blue-600' },
        ].map(({ label, icon: Icon, color }) => (
          <button key={label}
            className={cn(
              'flex items-center justify-center gap-2 p-3 bg-[#1e293b] border border-white/5 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest transition-all group',
              color
            )}>
            <Icon className="w-4 h-4 group-hover:text-white transition-colors" />
            <span className="group-hover:text-white transition-colors">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
