import React, { useState } from 'react';
import { Shield, Lock, User, Terminal, ChevronRight, Activity, Cpu } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface LoginPageProps {
  onLogin: (username: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthenticating(true);
    setError('');

    // Simulate login delay
    setTimeout(() => {
      if (username === 'admin' && password === 'admin') {
        onLogin('Sinan Bulucu');
      } else {
        setError('Invalid credentials. Root access denied.');
        setIsAuthenticating(false);
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#010409] flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-600/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute top-1/4 left-1/3 w-[400px] h-[400px] bg-emerald-600/5 rounded-full blur-[100px]" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo Section */}
        <div className="text-center mb-10 space-y-4">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-indigo-600 shadow-[0_0_40px_rgba(79,70,229,0.3)] border border-white/20 mb-4 animate-in zoom-in duration-700">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-black text-white tracking-tight uppercase italic underline decoration-indigo-500 decoration-4 underline-offset-8">
            Seraiph OS
          </h1>
          <p className="text-slate-500 text-sm font-bold uppercase tracking-[0.3em]">
            Central Node Management
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-[#0d1117] border border-white/10 rounded-[2.5rem] p-8 shadow-2xl shadow-indigo-600/5 ring-1 ring-white/5 animate-in slide-in-from-bottom-8 duration-700">
          <div className="flex items-center gap-3 mb-8 pb-4 border-b border-white/5">
             <Terminal className="w-5 h-5 text-indigo-400" />
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">System Authentication</span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Username</label>
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600 group-focus-within:text-indigo-400 transition-colors" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-indigo-500/50 transition-all text-sm font-bold placeholder:text-slate-700"
                  placeholder="ID: seraiph-admin"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Secure Token</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600 group-focus-within:text-indigo-400 transition-colors" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-indigo-500/50 transition-all text-sm font-bold placeholder:text-slate-700"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-500 text-xs font-bold animate-in fade-in slide-in-from-top-2">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isAuthenticating}
              className="w-full group bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl py-4 font-black uppercase tracking-widest text-xs transition-all shadow-xl shadow-indigo-600/20 flex items-center justify-center gap-3 relative overflow-hidden"
            >
              {isAuthenticating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Decrypting...</span>
                </>
              ) : (
                <>
                  <span>Initialize Access</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 flex items-center justify-between px-2">
             <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Hardware Firewall Active</span>
             </div>
             <span className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">v1.0.4-LTS</span>
          </div>
        </div>

        {/* Footer Stats */}
        <div className="mt-12 grid grid-cols-3 gap-4">
           {[
             { label: 'Uptime', icon: Activity, value: '99.9%' },
             { label: 'Latency', icon: Cpu, value: '12ms' },
             { label: 'Security', icon: Shield, value: 'High' }
           ].map((stat, i) => (
             <div key={i} className="bg-[#0d1117]/50 border border-white/5 rounded-2xl p-4 text-center">
                <stat.icon className="w-4 h-4 text-slate-600 mx-auto mb-2" />
                <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.2em] mb-1">{stat.label}</p>
                <p className="text-xs font-black text-indigo-400">{stat.value}</p>
             </div>
           ))}
        </div>
      </div>
    </div>
  );
};
