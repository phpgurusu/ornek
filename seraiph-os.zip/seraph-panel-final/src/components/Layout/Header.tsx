import React from 'react';
import { Server, Database, Activity, Bell, Search, User, Languages, Lock } from 'lucide-react';
import { ServerStats } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface HeaderProps {
  stats: ServerStats;
  currentUser: string | null;
  onLogout: () => void;
  onProfileClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ stats, currentUser, onLogout, onProfileClick }) => {
  const { language, setLanguage } = useLanguage();

  return (
    <header className="h-16 bg-[#0f172a] border-b border-white/5 flex items-center justify-between px-8 sticky top-0 z-10">
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className={cn(
              "w-2 h-2 rounded-full",
              stats.health === 'healthy' ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]"
            )} />
            <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">System Status</span>
          </div>
          <div className="h-4 w-px bg-white/10" />
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-medium text-slate-400">DB: {stats.dbConnected ? 'Connected' : 'Offline'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-medium text-slate-400">Host: Cenuta-TR-01</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center bg-[#1e293b] rounded-lg p-1 border border-white/5">
          <button 
            onClick={() => setLanguage('tr')}
            className={cn(
              "px-2 py-1 text-[10px] font-bold rounded transition-all",
              language === 'tr' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" : "text-slate-500 hover:text-slate-300"
            )}
          >
            TR
          </button>
          <button 
            onClick={() => setLanguage('en')}
            className={cn(
              "px-2 py-1 text-[10px] font-bold rounded transition-all",
              language === 'en' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" : "text-slate-500 hover:text-slate-300"
            )}
          >
            EN
          </button>
        </div>

        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search logs, projects..."
            className="bg-[#1e293b] border border-white/5 rounded-lg py-1.5 pl-10 pr-4 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 w-64"
          />
        </div>
        
        <div className="flex items-center gap-4">
          <button className="relative p-2 text-slate-400 hover:text-white transition-colors">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-[#0f172a]" />
          </button>
          <div className="h-8 w-px bg-white/10" />
          <div className="flex items-center gap-3 pl-2">
            <button 
              onClick={onProfileClick}
              className="text-right hidden sm:block hover:opacity-80 transition-opacity"
            >
              <p className="text-xs font-black text-white italic tracking-tight">{currentUser}</p>
              <div className="flex items-center justify-end gap-1.5">
                 <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                 <p className="text-[9px] text-slate-500 font-black uppercase tracking-wider">Root Access</p>
              </div>
            </button>
            <div 
              onClick={onProfileClick}
              className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center border border-white/10 shadow-lg shadow-indigo-500/20 cursor-pointer hover:scale-105 transition-transform"
            >
              <User className="w-5 h-5 text-white" />
            </div>
            <button 
              onClick={onLogout}
              className="p-2 text-slate-500 hover:text-rose-500 transition-colors"
              title="Terminate Session"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
