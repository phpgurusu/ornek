import React from 'react';
import { LayoutDashboard, MessageSquare, ShieldAlert, BookOpen, Settings, ExternalLink, Box, Database, Cpu, HardDrive, Terminal, Code, Layers } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const { t } = useLanguage();
  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
  };
  const menuItems = [
    { id: 'dashboard', label: t('dashboard'), icon: LayoutDashboard },
    { id: 'projects', label: t('projects'), icon: Box },
    { id: 'terminal', label: 'Terminal', icon: Terminal },
    { id: 'ai-chat', label: t('aiAssistant'), icon: MessageSquare },
    { id: 'security', label: t('cyberLogs'), icon: ShieldAlert },
    { id: 'seraph', label: 'SERAPH', icon: Layers },
    { id: 'library', label: t('legislation'), icon: BookOpen },
    { id: 'settings', label: t('settings') || 'Ayarlar', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-[#0f172a] border-r border-white/5 flex flex-col h-full">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
          <Box className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="font-bold text-lg text-white tracking-tight">Seraiph OS</h1>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Cloud Panel</p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => handleTabChange(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
              item.id === 'seraph'
                ? activeTab === item.id
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                  : "text-indigo-400 hover:bg-indigo-600/10 hover:text-indigo-300 border border-indigo-500/20"
                : activeTab === item.id
                  ? "bg-indigo-600/10 text-indigo-400 shadow-sm"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
            )}
          >
            <item.icon className={cn("w-5 h-5", activeTab === item.id ? "text-indigo-400" : "text-slate-500")} />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto">
        <div className="bg-[#1e293b] rounded-xl p-4 border border-white/5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Cenuta Server</span>
            <ExternalLink className="w-3 h-3 text-slate-600" />
          </div>
          <div className="space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>CPU Load</span>
                <span>42%</span>
              </div>
              <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-[42%]" />
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>RAM Usage</span>
                <span>6.4GB / 16GB</span>
              </div>
              <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 w-[40%]" />
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </aside>
  );
};
