import React, { useState } from 'react';
import { 
  ArrowLeft, Search, Plus, Trash2, Settings, ChevronLeft, 
  ChevronRight, ExternalLink, Wrench, Smartphone, CheckCircle2,
  AlertCircle, Info, Filter
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface EmailAccountsProps {
  project: Project;
  onBack: () => void;
  onCreateClick: () => void;
  onCheckEmail: (email: string) => void;
  onManageEmail: (email: string) => void;
}

export const EmailAccounts: React.FC<EmailAccountsProps> = ({ project, onBack, onCreateClick, onCheckEmail, onManageEmail }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('Tümü');

  const accounts = [
    { email: 'ebulten@artanadanismanlik.com', restriction: 'Kısıtlanmamış', used: '79.8 KB', total: '512 MB', percent: 0.02 },
    { email: 'ebulten@artanasyntech.com', restriction: 'Kısıtlanmamış', used: '81.18 KB', total: '512 MB', percent: 0.02 },
    { email: 'ebulten@dimagperest.com.tr', restriction: 'Kısıtlanmamış', used: '79.04 KB', total: '512 MB', percent: 0.02 },
    { email: 'info@artanadanismanlik.com', restriction: 'Kısıtlanmamış', used: '3.99 MB', total: '512 MB', percent: 0.78 },
    { email: 'info@artanasyntech.com', restriction: 'Kısıtlanmamış', used: '80.97 KB', total: '256 MB', percent: 0.03 },
    { email: 'noreply@dimagperest.com.tr', restriction: 'Kısıtlanmamış', used: '79.04 KB', total: '256 MB', percent: 0.03 },
    { email: 'teklif@artanasyntech.com.tr', restriction: 'Kısıtlanmamış', used: '81.11 KB', total: '512 MB', percent: 0.02 },
  ];

  const filters = ['Tümü', 'Restricted', 'Sistem Hesabı', 'Exceeded Storage'];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">E-posta Hesapları</h1>
            <p className="text-xs text-slate-500 mt-1">List Email Accounts</p>
          </div>
        </div>
        
        <div className="bg-indigo-600/10 border border-indigo-500/20 p-4 rounded-xl flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <p className="text-xs text-slate-300 leading-relaxed">
            This feature lets you create and manage email accounts. Want to learn more? Read our <a href="#" className="text-indigo-400 hover:underline inline-flex items-center gap-1">documentation <ExternalLink className="w-3 h-3" /></a>.
          </p>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="flex justify-end">
        <div className="bg-[#1e293b] rounded-xl border border-white/5 p-1 flex items-center gap-4 px-6 py-2 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold text-white">∞</span>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Mevcut</span>
          </div>
          <div className="w-px h-8 bg-white/5" />
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold text-white">17</span>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Kullanıldı</span>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-4 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="relative flex-1 min-w-[300px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text"
              placeholder="Arama..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex bg-[#0f172a] rounded-lg border border-white/5 p-1">
              <button className="p-1.5 text-slate-500 hover:text-white transition-colors"><ChevronLeft className="w-4 h-4" /></button>
              <div className="px-3 flex items-center text-xs font-medium text-slate-400 border-x border-white/5">
                Sayfa 1 / 1
              </div>
              <button className="p-1.5 text-slate-500 hover:text-white transition-colors"><ChevronRight className="w-4 h-4" /></button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mr-2">Filter:</span>
            {filters.map(filter => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={cn(
                  "px-3 py-1 rounded-lg text-[10px] font-bold transition-all",
                  activeFilter === filter 
                    ? "bg-indigo-600 text-white" 
                    : "bg-[#0f172a] text-slate-400 hover:text-slate-200 border border-white/5"
                )}
              >
                {filter}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={onCreateClick}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-indigo-600/20"
            >
              <Plus className="w-4 h-4" /> Oluştur
            </button>
            <button className="p-2 bg-[#0f172a] text-slate-400 hover:text-white border border-white/5 rounded-lg transition-all">
              <Settings className="w-4 h-4" />
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-red-600/10 hover:bg-red-600/20 text-red-500 border border-red-500/20 rounded-lg text-xs font-bold transition-all">
              <Trash2 className="w-4 h-4" /> Sil
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#1e293b] rounded-2xl border border-white/5 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#0f172a]/50 border-b border-white/5">
                <th className="p-4 w-10">
                  <input type="checkbox" className="rounded border-white/10 bg-[#0f172a] text-indigo-600" />
                </th>
                <th className="p-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Hesap @ Etki Alanı</th>
                <th className="p-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Restrictions</th>
                <th className="p-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Storage: Kullanıldı / Allocated / %</th>
                <th className="p-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {accounts.map((acc, i) => (
                <tr key={i} className="hover:bg-white/[0.02] transition-colors group">
                  <td className="p-4">
                    <input type="checkbox" className="rounded border-white/10 bg-[#0f172a] text-indigo-600" />
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-200">{acc.email}</span>
                      {acc.email.includes('httpddym5') && (
                        <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400 text-[8px] font-bold uppercase border border-indigo-500/20">Sistem</span>
                      )}
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2 text-emerald-500">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span className="text-xs font-medium">{acc.restriction}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="space-y-1.5 min-w-[200px]">
                      <div className="flex justify-between text-[10px] font-mono text-slate-400">
                        <span>{acc.used} / {acc.total}</span>
                        <span>{acc.percent}%</span>
                      </div>
                      <div className="h-1.5 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
                        <div 
                          className={cn(
                            "h-full transition-all duration-500",
                            acc.percent > 90 ? "bg-red-500" : acc.percent > 70 ? "bg-amber-500" : "bg-indigo-500"
                          )}
                          style={{ width: `${acc.percent * 10}%` }} // Scaling for visual representation since percent is very low
                        />
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center justify-end gap-2 opacity-60 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => onCheckEmail(acc.email)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0f172a] hover:bg-indigo-600/10 text-slate-400 hover:text-indigo-400 border border-white/5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all"
                      >
                        <ExternalLink className="w-3 h-3" /> E-postayı Kontrol Et
                      </button>
                      <button 
                        onClick={() => onManageEmail(acc.email)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0f172a] hover:bg-indigo-600/10 text-slate-400 hover:text-indigo-400 border border-white/5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all"
                      >
                        <Wrench className="w-3 h-3" /> Yönet
                      </button>
                      <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0f172a] hover:bg-indigo-600/10 text-slate-400 hover:text-indigo-400 border border-white/5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all">
                        <Smartphone className="w-3 h-3" /> Connect Devices
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 bg-[#0f172a]/30 border-t border-white/5 flex items-center justify-between">
          <p className="text-[10px] text-slate-500 font-medium">1 - 18 of 18</p>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">cPanel 102.0.18</span>
          </div>
        </div>
      </div>
    </div>
  );
};
