import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Terminal, Layout, Server, Database, 
  CheckCircle2, Loader2, Play, Box, Check,
  Activity, Shield, RefreshCw
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SetupManagementProps {
  project: Project;
  onBack: () => void;
}

type SetupStep = {
  id: string;
  title: string;
  status: 'pending' | 'loading' | 'success' | 'error';
  logs: string[];
};

export const SetupManagement: React.FC<SetupManagementProps> = ({ project, onBack }) => {
  const stack = project.stack || {
    frontend: 'react',
    backends: ['python'],
    database: 'mysql'
  };

  const [frontendSteps, setFrontendSteps] = useState<SetupStep[]>([
    { id: 'fe-1', title: 'React Sunucusu İndirme', status: 'pending', logs: [] },
    { id: 'fe-2', title: 'Dist Paket Çözümleme', status: 'pending', logs: [] },
    { id: 'fe-3', title: 'Kurulum & Yapılandırma', status: 'pending', logs: [] },
    { id: 'fe-4', title: 'Frontend Başlatma', status: 'pending', logs: [] },
  ]);

  // Create state for multiple backends
  const initialBackendSteps = (stack.backends || ['python']).map(bId => ({
    bId,
    steps: [
      { id: `${bId}-1`, title: 'Bileşen Yükleme', status: 'pending', logs: [] },
      { id: `${bId}-2`, title: 'Çalışma Ortamı Kurulumu', status: 'pending', logs: [] },
      { id: `${bId}-3`, title: 'Sunucu Başlatma', status: 'pending', logs: [] },
      { id: `${bId}-4`, title: 'DB Bağlantısı', status: 'pending', logs: [] },
    ] as SetupStep[]
  }));

  const [backendStates, setBackendStates] = useState(initialBackendSteps);

  const [isRunning, setIsRunning] = useState(false);
  const [activeLogs, setActiveLogs] = useState<string[]>(['[SYSTEM] Setup terminal ready. Click "Start Setup" to begin.']);

  const addLog = (log: string) => {
    setActiveLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${log}`].slice(-100));
  };

  const simulateFrontendSetup = async () => {
    addLog('Starting Frontend Setup...');
    
    // Step 1
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-1' ? { ...s, status: 'loading' } : s));
    addLog('Downloading React server components...');
    await new Promise(r => setTimeout(r, 2000));
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-1' ? { ...s, status: 'success' } : s));
    addLog('React server downloaded successfully.');

    // Step 2
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-2' ? { ...s, status: 'loading' } : s));
    addLog('Extracting dist folder and resolving dependencies...');
    await new Promise(r => setTimeout(r, 1500));
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-2' ? { ...s, status: 'success' } : s));
    addLog('Dist resolved. Dependencies satisfied.');

    // Step 3
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-3' ? { ...s, status: 'loading' } : s));
    addLog('Configuring environment variables and build scripts...');
    await new Promise(r => setTimeout(r, 1800));
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-3' ? { ...s, status: 'success' } : s));
    addLog('Final setup complete.');

    // Step 4
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-4' ? { ...s, status: 'loading' } : s));
    addLog('Starting static file server...');
    await new Promise(r => setTimeout(r, 1200));
    setFrontendSteps(prev => prev.map(s => s.id === 'fe-4' ? { ...s, status: 'success' } : s));
    addLog('Frontend is LIVE at ' + project.url);
  };

  const simulateBackendSetup = async (bId: string) => {
    const backendName = bId === 'python' ? 'FastAPI' : bId === 'go' ? 'Go Fiber' : bId === 'php' ? 'PHP Laravel' : 'PHP Vanilla';
    addLog(`Starting Backend Setup (${backendName})...`);
    
    const updateStep = (stepIdx: number, status: SetupStep['status']) => {
      setBackendStates(prev => prev.map(bs => {
        if (bs.bId === bId) {
          const newSteps = [...bs.steps];
          newSteps[stepIdx] = { ...newSteps[stepIdx], status };
          return { ...bs, steps: newSteps };
        }
        return bs;
      }));
    };

    // Step 1
    updateStep(0, 'loading');
    addLog(`Installing ${bId} core libraries and dependencies...`);
    await new Promise(r => setTimeout(r, 2000));
    updateStep(0, 'success');
    addLog(`${backendName} core components installed.`);

    // Step 2
    updateStep(1, 'loading');
    if (bId === 'python') addLog('python -m venv venv && source venv/bin/activate');
    else if (bId === 'go') addLog('go mod download && building binary...');
    else if (bId === 'php') addLog('composer install && generating APP_KEY...');
    else addLog('Setting up Apache/Nginx config for PHP-FPM...');
    await new Promise(r => setTimeout(r, 1500));
    updateStep(1, 'success');
    addLog('Environment ready.');

    // Step 3
    updateStep(2, 'loading');
    if (bId === 'python') addLog('uvicorn main:app --port 8000');
    else if (bId === 'go') addLog('./server -port 8080');
    else if (bId === 'php') addLog('php artisan serve --port 8000');
    else addLog('php-fpm -D && service nginx start');
    await new Promise(r => setTimeout(r, 2000));
    updateStep(2, 'success');
    addLog(`${backendName} process running.`);

    // Step 4
    updateStep(3, 'loading');
    addLog(`Mapping to ${stack.database || 'Primary DB'}...`);
    await new Promise(r => setTimeout(r, 1800));
    updateStep(3, 'success');
    addLog(`${backendName} linked to data layer.`);
  };

  const handleStartSetup = async () => {
    setIsRunning(true);
    addLog('Initializing Seraiph OS Setup Sequence...');
    
    const backendPromises = backendStates.map(bs => simulateBackendSetup(bs.bId));
    
    await Promise.all([simulateFrontendSetup(), ...backendPromises]);
    
    addLog('SETUP SEQUENCE COMPLETE. ALL SYSTEMS NOMINAL.');
    setIsRunning(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">Setup Yönetimi</h1>
            <p className="text-xs text-slate-500 mt-1">{project.name} için bileşen yapılandırması</p>
          </div>
        </div>
        <button 
          onClick={handleStartSetup}
          disabled={isRunning}
          className={cn(
            "px-6 py-3 rounded-xl text-sm font-bold transition-all flex items-center gap-2",
            isRunning ? "bg-slate-800 text-slate-500 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20"
          )}
        >
          {isRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
          {isRunning ? 'Kurulum Sürüyor...' : 'Setup Başlat'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Frontend Section */}
        <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-xl">
          <div className="p-6 bg-[#0f172a]/50 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400">
                <Layout className="w-5 h-5" />
              </div>
              <h2 className="font-bold text-white uppercase tracking-wider text-sm">Frontend (React)</h2>
            </div>
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-2 py-1 bg-slate-800 rounded">
              Ready to deploy
            </div>
          </div>
          <div className="p-6 space-y-4">
            {frontendSteps.map((step) => (
              <div key={step.id} className="flex items-center justify-between p-4 bg-[#0f172a]/30 rounded-2xl border border-white/5">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center transition-all",
                    step.status === 'success' ? "bg-emerald-500/20 text-emerald-500" :
                    step.status === 'loading' ? "bg-indigo-500/20 text-indigo-500" : "bg-slate-800 text-slate-600"
                  )}>
                    {step.status === 'success' ? <Check className="w-4 h-4" /> : 
                     step.status === 'loading' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Box className="w-4 h-4" />}
                  </div>
                  <span className={cn(
                    "text-sm font-medium",
                    step.status === 'success' ? "text-slate-200" : "text-slate-500"
                  )}>{step.title}</span>
                </div>
                {step.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
              </div>
            ))}
          </div>
        </div>

        {/* Backend Sections */}
        {backendStates.map((bs) => (
          <div key={bs.bId} className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-xl">
            <div className="p-6 bg-[#0f172a]/50 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500/10 rounded-lg text-purple-400">
                  <Server className="w-5 h-5" />
                </div>
                <h2 className="font-bold text-white uppercase tracking-wider text-sm">
                  Backend ({bs.bId === 'python' ? 'Python FastAPI' : bs.bId === 'go' ? 'Go Fiber' : bs.bId === 'php' ? 'PHP Laravel' : 'PHP Vanilla'})
                </h2>
              </div>
            </div>
            <div className="p-6 space-y-4">
              {bs.steps.map((step) => (
                <div key={step.id} className="flex items-center justify-between p-4 bg-[#0f172a]/30 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center transition-all",
                      step.status === 'success' ? "bg-emerald-500/20 text-emerald-500" :
                      step.status === 'loading' ? "bg-indigo-500/20 text-indigo-500" : "bg-slate-800 text-slate-600"
                    )}>
                      {step.status === 'success' ? <Check className="w-4 h-4" /> : 
                       step.status === 'loading' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Box className="w-4 h-4" />}
                    </div>
                    <span className={cn(
                      "text-sm font-medium",
                      step.status === 'success' ? "text-slate-200" : "text-slate-500"
                    )}>{step.title}</span>
                  </div>
                  {step.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Console / Terminal Section */}
        <div className="lg:col-span-2 bg-[#0f172a] rounded-2xl border border-white/5 overflow-hidden shadow-2xl">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-indigo-400" />
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Setup Terminal</h3>
            </div>
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/20 shadow-inner" />
              <div className="w-3 h-3 rounded-full bg-amber-500/20 shadow-inner" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/20 shadow-inner" />
            </div>
          </div>
          <div className="p-6 h-[250px] overflow-y-auto font-mono text-[11px] leading-relaxed space-y-1 custom-scrollbar">
            {activeLogs.map((log, i) => (
              <div key={i} className={cn(
                "flex gap-4",
                log.includes('SUCCESS') || log.includes('LIVE') || log.includes('READY') ? "text-emerald-400" :
                log.includes('Starting') ? "text-indigo-400" : "text-slate-500"
              )}>
                <span className="opacity-30 shrink-0 select-none">{i + 1}</span>
                <span>{log}</span>
              </div>
            ))}
            {isRunning && (
              <div className="flex gap-4 text-indigo-400 animate-pulse">
                <span className="opacity-30 shrink-0 select-none">{activeLogs.length + 1}</span>
                <span>_</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
