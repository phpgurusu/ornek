import React, { useState } from 'react';
import { 
  Shield, ShieldCheck, ShieldAlert, Lock, 
  Globe, Link2, RefreshCcw, Plus, Search, 
  Trash2, ArrowLeft, Zap, Info, Clock,
  FileCheck, Key, Fingerprint, Database,
  Activity, ExternalLink, Download, AlertTriangle,
  Layers
} from 'lucide-react';
import { SeraphDashboard } from '../Seraph/SeraphDashboard';
import { Project } from '../../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, Cell 
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface CertificateManagementProps {
  project: Project;
  onBack: () => void;
}

const usageData = [
  { name: 'Ücretsiz SSL', value: 8, color: '#10b981' },
  { name: 'Ücretli SSL', value: 2, color: '#6366f1' },
  { name: 'DID Zinciri', value: 1, color: '#f59e0b' },
];

export const CertificateManagement: React.FC<CertificateManagementProps> = ({ project, onBack }) => {
  const [activeTab, setActiveTab] = useState<'ssl' | 'cosmos' | 'usage' | 'seraph'>('ssl');
  const [showInstallForm, setShowInstallForm] = useState(false);
  const [installMethod, setInstallMethod] = useState<'letsencrypt' | 'manual' | 'cloudflare'>('letsencrypt');

  const certificates = [
    { domain: project.url.replace('https://', ''), type: 'Let\'s Encrypt (Free)', expiry: 82, status: 'valid', auto: true },
    { domain: 'api.' + project.url.replace('https://', ''), type: 'Sectigo (Paid)', expiry: 12, status: 'warning', auto: false },
    { domain: 'shop.' + project.url.replace('https://', ''), type: 'Let\'s Encrypt (Free)', expiry: 2, status: 'critical', auto: true },
    { domain: 'blog.' + project.url.replace('https://', ''), type: 'Cloudflare Edge', expiry: 310, status: 'valid', auto: true },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
              Sertifika Yönetimi
              <Zap className="w-5 h-5 text-amber-500 fill-amber-500/20" />
            </h1>
            <p className="text-xs text-slate-500 mt-1">SSL/TLS sertifikaları ve Cosmos DID kimlik zinciri kontrolü</p>
          </div>
        </div>
        <div className="flex bg-[#1e293b] rounded-2xl border border-white/5 p-1">
          {[
            { id: 'ssl', label: 'SSL Sertifikaları', icon: ShieldCheck },
            { id: 'cosmos', label: 'Cosmos DID', icon: Fingerprint },
            { id: 'usage', label: 'Kullanım Raporu', icon: Activity },
            { id: 'seraph', label: 'SERAPH', icon: Layers },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap",
                activeTab === tab.id 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
              )}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'ssl' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           {/* Summary Stats */}
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl flex items-center gap-4">
                 <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                    <ShieldCheck className="w-6 h-6 text-emerald-500" />
                 </div>
                 <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Geçerli</p>
                    <p className="text-2xl font-black text-white">8</p>
                 </div>
              </div>
              <div className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl flex items-center gap-4">
                 <div className="p-3 bg-amber-500/10 rounded-2xl border border-amber-500/20">
                    <Clock className="w-6 h-6 text-amber-500" />
                 </div>
                 <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Kritik Yakın (10 Gün)</p>
                    <p className="text-2xl font-black text-white">2</p>
                 </div>
              </div>
              <div className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl flex items-center gap-4">
                 <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                    <RefreshCcw className="w-6 h-6 text-indigo-400" />
                 </div>
                 <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Auto-Renewal Aktif</p>
                    <p className="text-2xl font-black text-white">92%</p>
                 </div>
              </div>
           </div>

           {/* Certificates Table */}
           <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-2xl">
              <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
                 <h3 className="text-sm font-bold text-white uppercase tracking-widest">Domain SSL Listesi</h3>
                 <button 
                  onClick={() => setShowInstallForm(true)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-600/20 flex items-center gap-2 transition-all"
                 >
                    <Plus className="w-3.5 h-3.5" /> Sertifika Yükle
                 </button>
              </div>

              {showInstallForm && (
                <div className="p-8 bg-[#0f172a]/40 border-b border-white/5 animate-in slide-in-from-top-4 duration-500">
                   <div className="max-w-3xl mx-auto space-y-6">
                      <div className="flex items-center justify-between">
                         <div className="flex items-center gap-4">
                            <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                               <Shield className="w-6 h-6 text-indigo-400" />
                            </div>
                            <div>
                               <h4 className="text-lg font-bold text-white tracking-tight">Yeni Sertifika Kurulumu</h4>
                               <p className="text-xs text-slate-500 uppercase font-black tracking-widest">Domain: {project.url.replace('https://', '')}</p>
                            </div>
                         </div>
                         <button 
                          onClick={() => setShowInstallForm(false)}
                          className="p-2 text-slate-500 hover:text-white transition-colors"
                         >
                            <Plus className="w-5 h-5 rotate-45" />
                         </button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                         <button 
                          onClick={() => setInstallMethod('letsencrypt')}
                          className={cn(
                            "p-6 rounded-2xl border transition-all text-left group",
                            installMethod === 'letsencrypt' 
                              ? "bg-indigo-600/10 border-indigo-500 text-white shadow-xl shadow-indigo-600/10" 
                              : "bg-[#1e293b] border-white/5 text-slate-400 hover:border-white/10"
                          )}
                         >
                            <div className="flex items-center gap-3 mb-3">
                               <Zap className={cn("w-5 h-5", installMethod === 'letsencrypt' ? "text-amber-500" : "text-slate-500")} />
                               <span className="text-sm font-bold uppercase tracking-widest">Let's Encrypt</span>
                            </div>
                            <p className="text-[10px] font-medium leading-relaxed opacity-60">
                               Otomatik doğrulama ve 90 günlük ücretsiz periyot.
                            </p>
                         </button>
                         <button 
                          onClick={() => setInstallMethod('cloudflare')}
                          className={cn(
                            "p-6 rounded-2xl border transition-all text-left group",
                            installMethod === 'cloudflare' 
                              ? "bg-orange-600/10 border-orange-500 text-white shadow-xl shadow-orange-600/10" 
                              : "bg-[#1e293b] border-white/5 text-slate-400 hover:border-white/10"
                          )}
                         >
                            <div className="flex items-center gap-3 mb-3">
                               <RefreshCcw className={cn("w-5 h-5", installMethod === 'cloudflare' ? "text-orange-500" : "text-slate-500")} />
                               <span className="text-sm font-bold uppercase tracking-widest">Cloudflare Free</span>
                            </div>
                            <p className="text-[10px] font-medium leading-relaxed opacity-60">
                               Cloudflare Edge sertifikası ile sınırsız ücretsiz koruma.
                            </p>
                         </button>
                         <button 
                          onClick={() => setInstallMethod('manual')}
                          className={cn(
                            "p-6 rounded-2xl border transition-all text-left group",
                            installMethod === 'manual' 
                              ? "bg-indigo-600/10 border-indigo-500 text-white shadow-xl shadow-indigo-600/10" 
                              : "bg-[#1e293b] border-white/5 text-slate-400 hover:border-white/10"
                          )}
                         >
                            <div className="flex items-center gap-3 mb-3">
                               <Lock className={cn("w-5 h-5", installMethod === 'manual' ? "text-indigo-400" : "text-slate-500")} />
                               <span className="text-sm font-bold uppercase tracking-widest">Manuel (Ücretli)</span>
                            </div>
                            <p className="text-[10px] font-medium leading-relaxed opacity-60">
                               Özel SSL sağlayıcınızdan alınan dosyaları yükleyin.
                            </p>
                         </button>
                      </div>

                      {installMethod === 'letsencrypt' ? (
                        <div className="bg-[#1e293b] p-6 rounded-2xl border border-white/5 space-y-6">
                           <div className="flex items-center gap-3 text-emerald-400 bg-emerald-500/5 p-4 rounded-xl border border-emerald-500/10">
                              <ShieldCheck className="w-5 h-5" />
                              <span className="text-[10px] font-bold uppercase tracking-widest">Let's Encrypt Altyapısı Hazır</span>
                           </div>
                           <div className="space-y-4">
                              <div className="flex items-center justify-between text-xs">
                                 <span className="text-slate-400">Yenileme:</span>
                                 <span className="text-white font-bold">Otomatik (90 Gün)</span>
                              </div>
                           </div>
                           <button className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 transition-all">
                              Let's Encrypt Sertifikası Al ve Kur
                           </button>
                        </div>
                      ) : installMethod === 'cloudflare' ? (
                        <div className="bg-[#1e293b] p-6 rounded-2xl border border-white/5 space-y-6">
                           <div className="flex items-center gap-3 text-orange-400 bg-orange-500/5 p-4 rounded-xl border border-orange-500/10">
                              <Globe className="w-5 h-5" />
                              <span className="text-[10px] font-bold uppercase tracking-widest">Cloudflare Proxy Bağlantısı Aktif</span>
                           </div>
                           <div className="space-y-4">
                              <div className="flex items-center justify-between text-xs">
                                 <span className="text-slate-400">Sertifika Türü:</span>
                                 <span className="text-white font-bold">Universal Edge SSL</span>
                              </div>
                           </div>
                           <button className="w-full py-4 bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 transition-all">
                              Cloudflare Sertifikasını Aktif Et
                           </button>
                        </div>
                      ) : (
                        <div className="space-y-4 animate-in fade-in duration-300">
                           <div className="grid grid-cols-1 gap-4">
                              <div className="space-y-2">
                                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Sertifika (CRT / PEM)</label>
                                 <textarea 
                                    className="w-full bg-[#0f172a] border border-white/5 rounded-2xl p-4 text-[10px] font-mono text-indigo-400 focus:outline-none focus:border-indigo-500/50 h-32 custom-scrollbar"
                                    placeholder="-----BEGIN CERTIFICATE-----"
                                 />
                              </div>
                              <div className="space-y-2">
                                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Private Key (KEY)</label>
                                 <textarea 
                                    className="w-full bg-[#0f172a] border border-white/5 rounded-2xl p-4 text-[10px] font-mono text-rose-400 focus:outline-none focus:border-rose-500/50 h-32 custom-scrollbar"
                                    placeholder="-----BEGIN PRIVATE KEY-----"
                                 />
                              </div>
                              <div className="space-y-2">
                                 <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Certificate Bundle (Optional)</label>
                                 <textarea 
                                    className="w-full bg-[#0f172a] border border-white/5 rounded-2xl p-4 text-[10px] font-mono text-slate-400 focus:outline-none focus:border-white/10 h-24 custom-scrollbar"
                                    placeholder="-----BEGIN CERTIFICATE-----"
                                 />
                              </div>
                           </div>
                           <button className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-xl shadow-indigo-600/20 transition-all">
                              Sertifikayı Kaydet ve Uygula
                           </button>
                        </div>
                      )}
                   </div>
                </div>
              )}
              <div className="overflow-x-auto">
                 <table className="w-full text-left">
                    <thead>
                       <tr className="bg-white/[0.02] border-b border-white/5">
                          <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Alan Adı</th>
                          <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Tür</th>
                          <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest w-1/3">Kalan Süre</th>
                          <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Durum</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                       {certificates.map((cert) => (
                         <tr key={cert.domain} className="hover:bg-white/[0.02] group transition-all">
                            <td className="p-6">
                               <div className="flex items-center gap-3">
                                  <div className="p-2 bg-[#0f172a] rounded-lg border border-white/5">
                                     <Globe className="w-4 h-4 text-slate-400" />
                                  </div>
                                  <span className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors uppercase">{cert.domain}</span>
                               </div>
                            </td>
                            <td className="p-6 text-xs text-slate-400 font-medium italic">{cert.type}</td>
                            <td className="p-6">
                               <div className="space-y-2">
                                  <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                                     <span className={cn(
                                       cert.status === 'critical' ? 'text-rose-500' : cert.status === 'warning' ? 'text-amber-500' : 'text-emerald-500'
                                     )}>{cert.expiry} GÜN KALDI</span>
                                     <span className="text-slate-600">365 GÜN</span>
                                  </div>
                                  <div className="h-1.5 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
                                     <div 
                                       className={cn(
                                         "h-full rounded-full transition-all duration-1000",
                                         cert.status === 'critical' ? "bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.4)]" : 
                                         cert.status === 'warning' ? "bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]" : 
                                         "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]"
                                       )}
                                       style={{ width: `${(cert.expiry / 365) * 100}%` }}
                                     />
                                  </div>
                               </div>
                            </td>
                            <td className="p-6 text-right">
                               <div className="flex items-center justify-end gap-3">
                                  {cert.auto ? (
                                    <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-black uppercase rounded-lg border border-emerald-500/20 shadow-lg shadow-emerald-500/5">
                                       <ShieldCheck className="w-3.5 h-3.5" />
                                       Sistem Onaylı
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-2">
                                       <div className="px-2 py-1 bg-amber-500/10 text-amber-400 text-[9px] font-black uppercase rounded border border-amber-500/20">
                                          Manuel Islem
                                       </div>
                                       <button 
                                          onClick={() => {
                                             setInstallMethod('manual');
                                             setShowInstallForm(true);
                                             window.scrollTo({ top: 0, behavior: 'smooth' });
                                          }}
                                          className="p-2 bg-[#0f172a] hover:bg-white/5 rounded-xl border border-white/5 text-slate-400 hover:text-white transition-all group flex items-center gap-2"
                                          title="Sertifikayı Yenile"
                                       >
                                          <RefreshCcw className="w-4 h-4 group-active:rotate-180 transition-transform duration-500" />
                                       </button>
                                    </div>
                                  )}
                               </div>
                            </td>
                         </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'cosmos' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* DID Identity Card */}
              <div className="lg:col-span-2 bg-[#1e293b] p-10 rounded-3xl border border-white/5 shadow-2xl relative overflow-hidden flex flex-col space-y-10 group">
                 <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:scale-110 transition-transform duration-700">
                    <Fingerprint className="w-48 h-48 text-indigo-500" />
                 </div>
                 <div className="relative z-10 space-y-6">
                    <div className="flex items-center gap-4">
                       <div className="p-4 bg-indigo-600/10 rounded-2xl border border-indigo-500/20">
                          <Fingerprint className="w-10 h-10 text-indigo-400" />
                       </div>
                       <div>
                          <h3 className="text-xl font-bold text-white tracking-tight uppercase">Cosmos DID - Firma Kimlik Zinciri</h3>
                          <p className="text-xs text-slate-500">Blok zinciri tabanlı değişmez dijital kimlik kanıtı</p>
                       </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
                       <div className="space-y-1">
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Identiy DID URL</p>
                          <div className="p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5 font-mono text-xs text-indigo-400 break-all border-l-4 border-l-indigo-600">
                             did:cosmos:pub:seraiph-systems-inc-v1
                          </div>
                       </div>
                       <div className="space-y-1">
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Firma Doğrulama Kodu</p>
                          <div className="p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5 font-mono text-xs text-slate-300 border-l-4 border-l-emerald-500">
                             6F1A-D2E8-55CF-99B1-A012
                          </div>
                       </div>
                    </div>
                 </div>

                 <div className="relative z-10 grid grid-cols-3 gap-8 pt-10 border-t border-white/5">
                    <div className="text-center space-y-2">
                       <p className="text-emerald-500 font-black text-xs uppercase tracking-widest">Konsensüs</p>
                       <p className="text-lg font-bold text-white">AKTİF (99.9%)</p>
                    </div>
                    <div className="text-center space-y-2">
                       <p className="text-blue-500 font-black text-xs uppercase tracking-widest">Blok Numarası</p>
                       <p className="text-lg font-bold text-white">#12,548,221</p>
                    </div>
                    <div className="text-center space-y-2">
                       <p className="text-amber-500 font-black text-xs uppercase tracking-widest">Validatörler</p>
                       <p className="text-lg font-bold text-white">24 Aktif Node</p>
                    </div>
                 </div>
              </div>

              {/* Identity Timeline */}
              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-2xl flex flex-col">
                 <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-6">Kimlik Tarihçesi</h3>
                 <div className="space-y-8 flex-1">
                    {[
                      { event: 'Firma Onayı Yenilendi', time: 'Bugün 15:42', icon: ShieldCheck, color: 'text-emerald-500' },
                      { event: 'Yeni Blok Doğrulandı', time: '2 dk önce', icon: Link2, color: 'text-indigo-400' },
                      { event: 'Sertifika İmzalandı', time: 'Dün 22:10', icon: Key, color: 'text-blue-500' },
                      { event: 'DID Zinciri Başlatıldı', time: '14 May 2024', icon: Zap, color: 'text-amber-500' },
                    ].map((item, i) => (
                      <div key={i} className="flex gap-4 relative">
                         {i < 3 && <div className="absolute left-6 top-10 bottom-[-24px] w-0.5 bg-white/5" />}
                         <div className={cn("relative z-10 w-12 h-12 rounded-2xl border border-white/5 bg-[#0f172a] flex items-center justify-center shrink-0", item.color)}>
                            <item.icon className="w-5 h-5" />
                         </div>
                         <div className="pt-1">
                            <p className="text-sm font-bold text-slate-200">{item.event}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase">{item.time}</p>
                         </div>
                      </div>
                    ))}
                 </div>
                 <button className="w-full py-3 bg-white/5 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest text-slate-400 rounded-xl mt-8 transition-all">
                    Sertifika Zincirini Gör →
                 </button>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'usage' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-[#1e293b] p-10 rounded-3xl border border-white/5 shadow-2xl space-y-8">
                 <h3 className="text-sm font-bold text-white uppercase tracking-widest">Kullanım Dağılımı</h3>
                 <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                       <BarChart data={usageData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                          <XAxis dataKey="name" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                          <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '12px' }}
                            itemStyle={{ color: '#fff', fontSize: '10px' }}
                            cursor={{ fill: 'rgba(255,255,255,0.02)' }}
                          />
                          <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                             {usageData.map((entry, index) => (
                               <Cell key={`cell-${index}`} fill={entry.color} />
                             ))}
                          </Bar>
                       </BarChart>
                    </ResponsiveContainer>
                 </div>
                 <div className="grid grid-cols-2 gap-6 pt-6 border-t border-white/5">
                    <div className="space-y-1">
                       <p className="text-sm font-bold text-white">Toplam Maliyet</p>
                       <p className="text-2xl font-black text-indigo-400">$240.00 / Yıl</p>
                    </div>
                    <div className="space-y-1">
                       <p className="text-sm font-bold text-white">Tasarruf (Free SSL)</p>
                       <p className="text-2xl font-black text-emerald-500">$590.00 / Yıl</p>
                    </div>
                 </div>
              </div>

              <div className="bg-[#1e293b] p-10 rounded-3xl border border-white/5 shadow-2xl flex flex-col justify-between">
                 <div className="space-y-6">
                    <div className="p-4 bg-amber-500/10 rounded-3xl border border-amber-500/20 w-fit">
                       <AlertTriangle className="w-8 h-8 text-amber-500" />
                    </div>
                    <div className="space-y-2">
                       <h3 className="text-xl font-bold text-white tracking-tight">Kapasite & Limit Uyarısı</h3>
                       <p className="text-sm text-slate-500 leading-relaxed">
                          DID kimlik zinciri kotanızın %85'ine ulaştınız. Blok kayıtlarının devam etmesi için paketinizi yükseltmeniz veya eski kayıtları arşivlemeniz gerekebilir.
                       </p>
                    </div>
                 </div>
                 <div className="space-y-4 pt-10">
                    <div className="flex justify-between text-xs font-bold uppercase tracking-widest text-slate-500">
                       <span>DID KOTA KULLANIMI</span>
                       <span>8.5 GB / 10 GB</span>
                    </div>
                    <div className="h-2 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
                       <div className="h-full bg-amber-500 w-[85%]" />
                    </div>
                    <button className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-sm shadow-xl shadow-indigo-600/20 transition-all active:scale-95">
                       Şimdi Yükselt
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Quick Actions & Live Logs Footer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pt-8 border-t border-white/5">
         <div className="lg:col-span-1 bg-[#1e293b]/50 p-8 rounded-3xl border border-white/5 flex flex-col space-y-4">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Hızlı İşlemler</h3>
            <div className="grid grid-cols-2 gap-3">
               <button className="p-4 bg-[#0f172a] hover:bg-indigo-600 border border-white/5 rounded-2xl transition-all group">
                  <RefreshCcw className="w-5 h-5 text-indigo-400 group-hover:text-white mb-2 mx-auto" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 group-hover:text-white text-center block">Tümünü Yenile</span>
               </button>
               <button className="p-4 bg-[#0f172a] hover:bg-emerald-600 border border-white/5 rounded-2xl transition-all group">
                  <Download className="w-5 h-5 text-emerald-400 group-hover:text-white mb-2 mx-auto" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 group-hover:text-white text-center block">CA Bundle İndir</span>
               </button>
            </div>
         </div>

         <div className="lg:col-span-2 bg-[#1e293b]/50 p-8 rounded-3xl border border-white/5 flex flex-col space-y-4 relative">
            <div className="flex items-center justify-between">
               <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Sertifika Olay Logları</h3>
               <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Streaming</span>
               </div>
            </div>
            <div className="h-[100px] overflow-y-auto font-mono text-[10px] text-slate-500 space-y-1 custom-scrollbar">
               <p><span className="text-slate-600">[15:58:22]</span> SSL-DAEMON: Let's Encrypt renewal check started for primary domain...</p>
               <p className="text-emerald-500/80"><span className="text-slate-600">[15:58:25]</span> SUCCESS: shop.eraiph.io renewed via DNS-01 challenge.</p>
               <p><span className="text-slate-600">[15:58:30]</span> COSMO-CHAIN: Identity block #12,548,221 verified by 18 nodes.</p>
               <p className="text-amber-500/80"><span className="text-slate-600">[15:59:01]</span> WARNING: Sectigo cert for api.seraiph.io expires in 12 days. Auto-renew FAIL: Manual intervention required.</p>
            </div>
         </div>
      </div>

      {/* SERAPH tab panel — tam ekran, diğer içeriklerin üstüne binmez */}
      {activeTab === 'seraph' && (
        <div className="animate-in fade-in slide-in-from-top-2 duration-300">
          <SeraphDashboard onBack={() => setActiveTab('ssl')} />
        </div>
      )}
    </div>
  );
};
