import React, { useState } from 'react';
import { 
  Globe, Plus, Shield, Search, ArrowLeft, 
  ExternalLink, ChevronRight, Settings, 
  Trash2, RefreshCcw, Link as LinkIcon, 
  Lock, AlertCircle, CheckCircle2, Users,
  Server, Package
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface DomainManagementProps {
  project: Project;
  onBack: () => void;
}

interface DomainItem {
  id: string;
  name: string;
  type: 'primary' | 'addon' | 'subdomain' | 'alias';
  documentRoot: string;
  status: 'active' | 'pending' | 'error';
  ssl: boolean;
  redirect?: string;
}

type DomainTab = 'domains' | 'subdomains' | 'redirects' | 'dns' | 'users' | 'nameservers' | 'packages';

export const DomainManagement: React.FC<DomainManagementProps> = ({ project, onBack }) => {
  const [activeTab, setActiveTab] = useState<DomainTab>('domains');
  const [isAddingDomain, setIsAddingDomain] = useState(false);
  const [newDomainType, setNewDomainType] = useState<'addon' | 'subdomain'>('addon');
  
  const [domains] = useState<DomainItem[]>([
    { id: '1', name: project.url.replace('https://', ''), type: 'primary', documentRoot: '/public_html', status: 'active', ssl: true },
    { id: '2', name: 'api.' + project.url.replace('https://', ''), type: 'subdomain', documentRoot: '/public_html/api', status: 'active', ssl: true },
    { id: '3', name: 'shop.' + project.url.replace('https://', ''), type: 'addon', documentRoot: '/public_html/shop', status: 'pending', ssl: false },
    { id: '4', name: 'blog.' + project.url.replace('https://', ''), type: 'subdomain', documentRoot: '/public_html/blog', status: 'active', ssl: true, redirect: 'https://medium.com/@seraiph' },
  ]);

  const stats = [
    { label: 'Toplam Domain', value: domains.length, icon: Globe, color: 'text-indigo-400' },
    { label: 'Aktif SSL', value: domains.filter(d => d.ssl).length, icon: Shield, color: 'text-emerald-400' },
    { label: 'Yönlendirme', value: domains.filter(d => d.redirect).length, icon: LinkIcon, color: 'text-amber-400' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={isAddingDomain ? () => setIsAddingDomain(false) : onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              {isAddingDomain ? 'Yeni Domain Ekle' : 'Domain Yönetimi'}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              {isAddingDomain ? 'Sisteme yeni bir alan adı veya eklenti domain tanımlayın' : 'Domainlerinizi, alt alan adlarınızı ve yönlendirmelerinizi yönetin'}
            </p>
          </div>
        </div>
        {!isAddingDomain && (
          <button 
            onClick={() => setIsAddingDomain(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-600/20 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Yeni Domain Ekle
          </button>
        )}
      </div>

      {isAddingDomain ? (
        <div className="bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl p-8 max-w-3xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {/* Domain Type Toggle */}
          <div className="flex p-1 bg-[#0f172a] rounded-2xl border border-white/5 w-fit mx-auto">
            <button 
              onClick={() => setNewDomainType('addon')}
              className={cn(
                "px-8 py-3 rounded-xl text-xs font-bold transition-all",
                newDomainType === 'addon' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : "text-slate-500 hover:text-slate-300"
              )}
            >
              Addon Domain
            </button>
            <button 
              onClick={() => setNewDomainType('subdomain')}
              className={cn(
                "px-8 py-3 rounded-xl text-xs font-bold transition-all",
                newDomainType === 'subdomain' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : "text-slate-500 hover:text-slate-300"
              )}
            >
              Alt Alan Adı (Subdomain)
            </button>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {newDomainType === 'addon' ? (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">Domain Adı</label>
                  <div className="relative group">
                    <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                    <input 
                      type="text" 
                      placeholder="example.com"
                      className="w-full bg-[#0f172a] border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all font-medium"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">Alt Alan Adı</label>
                  <div className="flex gap-2">
                    <div className="relative flex-1 group">
                      <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                      <input 
                        type="text" 
                        placeholder="blog"
                        className="w-full bg-[#0f172a] border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all font-medium"
                      />
                    </div>
                    <div className="relative group min-w-[140px]">
                      <select className="appearance-none w-full bg-[#0f172a] border border-white/5 rounded-2xl py-4 px-4 text-sm text-indigo-400 font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all cursor-pointer">
                        <option>@{project.url.replace('https://', '')}</option>
                        <option>@seraiph.net</option>
                        <option>@seraiph.io</option>
                      </select>
                      <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none rotate-90" />
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">Belge Dizini (Document Root)</label>
                <div className="relative group">
                  <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                  <input 
                    type="text" 
                    placeholder={newDomainType === 'addon' ? "/public_html/example.com" : "/public_html/blog"}
                    className="w-full bg-[#0f172a] border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-white/5 border border-white/5 rounded-2xl">
              <input type="checkbox" id="create-ftp" className="w-4 h-4 rounded border-white/10 bg-[#0f172a] text-indigo-600 focus:ring-0 focus:ring-offset-0" />
              <label htmlFor="create-ftp" className="text-sm font-medium text-slate-300 cursor-pointer">
                Bu domain ile ilişkilendirilmiş bir FTP hesabı oluşturulsun mu?
              </label>
            </div>

            <div className="pt-6 border-t border-white/5">
              <details className="group">
                <summary className="flex items-center justify-between cursor-pointer list-none">
                  <div className="flex items-center gap-3 text-indigo-400">
                    <Settings className="w-5 h-5" />
                    <span className="text-sm font-bold uppercase tracking-widest">Gelişmiş Ayarlar (Alan & Trafik)</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-500 group-open:rotate-90 transition-transform" />
                </summary>
                
                <div className="mt-8 space-y-10 animate-in fade-in slide-in-from-top-4 duration-300">
                  {/* Quota Settings */}
                  <div className="space-y-6">
                    <div className="flex justify-between items-end">
                      <div className="space-y-1">
                        <p className="text-sm font-bold text-white uppercase tracking-wider">Disk Kotası (MB)</p>
                        <p className="text-xs text-slate-500">Bu domainin kullanabileceği maksimum disk alanı.</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <input 
                          type="number" 
                          className="w-24 bg-[#0f172a] border border-white/5 rounded-xl py-2 px-3 text-sm text-indigo-400 font-bold text-center focus:outline-none focus:border-indigo-500/50"
                          defaultValue={1024}
                        />
                        <span className="text-xs font-bold text-slate-500">MB</span>
                      </div>
                    </div>
                    <div className="relative group">
                       <input 
                        type="range" 
                        min="256" 
                        max="10240" 
                        step="256"
                        className="w-full h-2 bg-[#0f172a] rounded-lg appearance-none cursor-pointer accent-indigo-600"
                       />
                       <div className="flex justify-between mt-2 px-1">
                         <span className="text-[10px] text-slate-600 font-bold">256 MB</span>
                         <span className="text-[10px] text-slate-600 font-bold">10 GB</span>
                       </div>
                    </div>
                  </div>

                  {/* Bandwidth Settings */}
                  <div className="space-y-6">
                    <div className="flex justify-between items-end">
                      <div className="space-y-1">
                        <p className="text-sm font-bold text-white uppercase tracking-wider">Aylık Trafik Limiti (GB)</p>
                        <p className="text-xs text-slate-500">Bu domainin gerçekleştirebileceği aylık veri transfer miktarı.</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <input 
                          type="number" 
                          className="w-24 bg-[#0f172a] border border-white/5 rounded-xl py-2 px-3 text-sm text-emerald-400 font-bold text-center focus:outline-none focus:border-indigo-500/50"
                          defaultValue={50}
                        />
                        <span className="text-xs font-bold text-slate-500">GB</span>
                      </div>
                    </div>
                    <div className="relative group">
                       <input 
                        type="range" 
                        min="1" 
                        max="500" 
                        step="10"
                        className="w-full h-2 bg-[#0f172a] rounded-lg appearance-none cursor-pointer accent-emerald-600"
                       />
                       <div className="flex justify-between mt-2 px-1">
                         <span className="text-[10px] text-slate-600 font-bold">1 GB</span>
                         <span className="text-[10px] text-slate-600 font-bold">500 GB (Limitless)</span>
                       </div>
                    </div>
                  </div>
                </div>
              </details>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <button 
              onClick={() => setIsAddingDomain(false)}
              className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-slate-300 rounded-2xl font-bold transition-all"
            >
              İptal
            </button>
            <button className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold shadow-xl shadow-indigo-600/20 active:scale-[0.98] transition-all">
              Domain Oluştur ve Yayınla
            </button>
          </div>
        </div>
      ) : (
      <>
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-[#1e293b] p-6 rounded-2xl border border-white/5 shadow-lg flex items-center gap-4">
            <div className={cn("p-3 rounded-xl bg-[#0f172a] border border-white/5", stat.color)}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{stat.label}</p>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 p-1 bg-[#1e293b] rounded-2xl border border-white/5 w-fit">
        {[
          { id: 'domains', label: 'Domainler' },
          { id: 'subdomains', label: 'Alt Alan Adları' },
          { id: 'redirects', label: 'Yönlendirmeler' },
          { id: 'dns', label: 'Zone Editor' },
          { id: 'users', label: 'Kullanıcı Yönetimi' },
          { id: 'nameservers', label: 'Name Server' },
          { id: 'packages', label: 'Paket Yönetimi' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "px-4 py-2 rounded-xl text-[11px] font-bold transition-all whitespace-nowrap",
              activeTab === tab.id 
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" 
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Content Area */}
      {activeTab === 'domains' && (
        <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-2xl animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
             <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Domain ara..."
                  className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-2 pl-10 pr-4 text-xs text-slate-300 focus:outline-none focus:border-indigo-500/50 transition-all font-medium"
                />
             </div>
             <div className="flex gap-2">
                <button className="p-2 text-slate-500 hover:text-white hover:bg-white/5 rounded-xl transition-all">
                  <RefreshCcw className="w-4 h-4" />
                </button>
             </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-white/[0.02] border-b border-white/5">
                  <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Domain</th>
                  <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Tür</th>
                  <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Dizin</th>
                  <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                  <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest">SSL</th>
                  <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">İşlemler</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {domains.map((domain) => (
                  <tr key={domain.id} className="hover:bg-white/[0.02] group transition-all">
                    <td className="p-6">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors uppercase">{domain.name}</span>
                          <ExternalLink className="w-3 h-3 text-slate-600 cursor-pointer hover:text-white" />
                        </div>
                        {domain.redirect && (
                          <div className="flex items-center gap-1 text-[10px] text-amber-400 font-bold uppercase">
                            <RefreshCcw className="w-3 h-3" />
                            <span>{domain.redirect} adresine yönlü</span>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="p-6">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest border",
                        domain.type === 'primary' ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" :
                        domain.type === 'subdomain' ? "bg-blue-500/10 text-blue-400 border-blue-500/20" :
                        "bg-slate-500/10 text-slate-400 border-slate-500/20"
                      )}>
                        {domain.type}
                      </span>
                    </td>
                    <td className="p-6 text-xs text-slate-400 font-mono italic">{domain.documentRoot}</td>
                    <td className="p-6">
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          domain.status === 'active' ? "bg-emerald-500 shadow-lg shadow-emerald-500/20" :
                          domain.status === 'pending' ? "bg-amber-500 shadow-lg shadow-amber-500/20" :
                          "bg-rose-500 shadow-lg shadow-rose-500/20"
                        )} />
                        <span className="text-xs font-medium text-slate-300 capitalize">{domain.status}</span>
                      </div>
                    </td>
                    <td className="p-6">
                      {domain.ssl ? (
                        <div className="flex items-center gap-1.5 text-emerald-500">
                          <Lock className="w-3.5 h-3.5" />
                          <span className="text-[10px] font-bold uppercase">Aktif</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-slate-500">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span className="text-[10px] font-bold uppercase">Yok</span>
                        </div>
                      )}
                    </td>
                    <td className="p-6 text-right">
                      <div className="flex justify-end gap-2">
                        <button className="p-2 bg-[#0f172a] hover:bg-white/5 rounded-xl border border-white/5 text-slate-400 hover:text-white transition-all shadow-sm">
                          <Settings className="w-4 h-4" />
                        </button>
                        <button className="p-2 bg-[#0f172a] hover:bg-rose-500/10 rounded-xl border border-white/5 text-slate-400 hover:text-rose-500 transition-all shadow-sm">
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <ChevronRight className="w-4 h-4 text-slate-700 ml-2 self-center group-hover:text-indigo-400 transition-colors" />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-8 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-300 space-y-8 text-center py-16">
          <div className="p-5 bg-indigo-500/10 rounded-3xl w-fit mx-auto mb-6">
             <Users className="w-12 h-12 text-indigo-400" />
          </div>
          <div className="max-w-md mx-auto space-y-4">
             <h2 className="text-xl font-bold text-white">Domain Kullanıcı Yönetimi</h2>
             <p className="text-sm text-slate-500 leading-relaxed">
                Domainlerinize erişim yetkisi olan kullanıcıları buradan yönetebilirsiniz. FTP, Webmail ve SSH yetkilendirmelerini buradan atayabilirsiniz.
             </p>
             <button className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-sm transition-all shadow-lg shadow-indigo-600/20 active:scale-95">
                Kullanıcı Tanımla
             </button>
          </div>
        </div>
      )}

      {activeTab === 'nameservers' && (
        <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-8 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-300 space-y-8">
           <div className="flex items-center gap-4 border-b border-white/5 pb-6">
              <Server className="w-6 h-6 text-indigo-400" />
              <h2 className="text-lg font-bold text-white uppercase tracking-wider">Name Server Ayarları</h2>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-2">Primary NS</p>
                 <div className="bg-[#0f172a] p-4 rounded-2xl border border-white/5 flex items-center justify-between group">
                    <span className="text-sm text-indigo-400 font-bold font-mono">ns1.seraiph.com</span>
                    <button className="text-[10px] font-bold text-slate-500 hover:text-white uppercase tracking-widest hidden group-hover:block transition-all">Değiştir</button>
                 </div>
              </div>
              <div className="space-y-4">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-2">Secondary NS</p>
                 <div className="bg-[#0f172a] p-4 rounded-2xl border border-white/5 flex items-center justify-between group">
                    <span className="text-sm text-indigo-400 font-bold font-mono">ns2.seraiph.com</span>
                    <button className="text-[10px] font-bold text-slate-500 hover:text-white uppercase tracking-widest hidden group-hover:block transition-all">Değiştir</button>
                 </div>
              </div>
           </div>

           <div className="pt-6 border-t border-white/5">
              <div className="bg-amber-500/5 border border-amber-500/10 p-5 rounded-2xl flex gap-4 items-start">
                 <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                 <p className="text-xs text-slate-400 leading-relaxed">
                    Name server değişikliklerinin küresel olarak yayılması 24-48 saat sürebilir. Bu işlem sırasında web sitenize erişimde kesintiler yaşanabilir.
                 </p>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'packages' && (
        <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-8 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="flex items-center gap-4 border-b border-white/5 pb-6 mb-8">
              <Package className="w-6 h-6 text-indigo-400" />
              <h2 className="text-lg font-bold text-white uppercase tracking-wider">Aktif Paket Planları</h2>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { name: 'Seraiph Cloud Basic', price: '₺49/ay', features: ['5GB Disk', '1 Domain', '10 Email'], current: true },
                { name: 'Seraiph Cloud Pro', price: '₺99/ay', features: ['25GB Disk', '5 Domain', 'Limitsiz Email'] },
                { name: 'Enterprise Elite', price: '₺249/ay', features: ['100GB Disk', 'Limitsiz Domain', 'Full Root Access'] },
              ].map((pkg) => (
                <div key={pkg.name} className={cn(
                  "p-6 rounded-3xl border flex flex-col space-y-6 transition-all",
                  pkg.current 
                    ? "bg-indigo-600 border-indigo-500 shadow-xl shadow-indigo-600/20" 
                    : "bg-[#0f172a]/50 border-white/5 hover:bg-[#0f172a]"
                )}>
                   <div className="space-y-1">
                      <h3 className="font-bold text-white">{pkg.name}</h3>
                      <p className="text-2xl font-black text-white">{pkg.price}</p>
                   </div>
                   <ul className="space-y-2">
                      {pkg.features.map(f => (
                        <li key={f} className="flex items-center gap-2 text-xs font-medium">
                           <CheckCircle2 className={cn("w-3.5 h-3.5", pkg.current ? "text-indigo-200" : "text-emerald-500")} />
                           <span className={pkg.current ? "text-indigo-100" : "text-slate-400"}>{f}</span>
                        </li>
                      ))}
                   </ul>
                   <button className={cn(
                     "w-full py-3 rounded-2xl font-bold text-xs uppercase tracking-widest transition-all",
                     pkg.current 
                       ? "bg-white text-indigo-600 cursor-default" 
                       : "bg-white/5 text-slate-300 hover:bg-white/10"
                   )}>
                      {pkg.current ? 'Aktif Paket' : 'Yükselt'}
                   </button>
                </div>
              ))}
           </div>
        </div>
      )}

      {/* Quick Settings Footer (Only for Domains tab) */}
      {activeTab === 'domains' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="bg-[#1e293b]/50 p-8 rounded-3xl border border-white/5 flex items-center gap-6">
              <div className="p-4 bg-amber-500/10 rounded-2xl">
                 <RefreshCcw className="w-8 h-8 text-amber-500" />
              </div>
              <div className="space-y-1">
                 <h3 className="text-lg font-bold text-white">Zone Editor</h3>
                 <p className="text-xs text-slate-500">A, CNAME, MX ve TXT kayıtlarını hızlıca düzenleyin.</p>
                 <button className="text-xs font-bold text-indigo-400 mt-2 hover:indigo-300">Yönet →</button>
              </div>
           </div>
           <div className="bg-[#1e293b]/50 p-8 rounded-3xl border border-white/5 flex items-center gap-6">
              <div className="p-4 bg-emerald-500/10 rounded-2xl">
                 <Shield className="w-8 h-8 text-emerald-500" />
              </div>
              <div className="space-y-1">
                 <h3 className="text-lg font-bold text-white">AutoSSL</h3>
                 <p className="text-xs text-slate-500">Tüm domainleriniz için ücretsiz SSL sertifikalarını yenileyin.</p>
                 <button className="text-xs font-bold text-indigo-400 mt-2 hover:indigo-300">Şimdi Çalıştır →</button>
              </div>
           </div>
        </div>
      )}
      </>
      )}
    </div>
  );
};
