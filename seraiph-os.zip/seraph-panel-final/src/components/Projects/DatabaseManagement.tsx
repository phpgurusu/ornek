import React, { useState } from 'react';
import { 
  ArrowLeft, ArrowRight, Database, Shield, Zap, HardDrive, 
  Settings, Save, Globe, Lock, Cpu, Activity,
  Cloud, RefreshCcw, Plus, Trash2, Check,
  Terminal, Server, AlertCircle, Wand2, Share2, 
  UserPlus, Key, Copy
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface DatabaseManagementProps {
  project: Project;
  onBack: () => void;
}

type DBModule = 'overview' | 'pma' | 'manage' | 'wizard' | 'remote';

type DBInstance = {
  id: string;
  type: 'mysql' | 'postgresql' | 'redis';
  version: string;
  status: 'running' | 'scaling' | 'backup';
  cpu: number;
  ram: number;
  storage: number;
};

export const DatabaseManagement: React.FC<DatabaseManagementProps> = ({ project, onBack }) => {
  const [activeModule, setActiveModule] = useState<DBModule>('overview');
  const [selectedInstanceId, setSelectedInstanceId] = useState<string | null>(null);
  
  // Wizard State
  const [wizardStep, setWizardStep] = useState(1);
  const [wizardData, setWizardData] = useState({
    dbName: '',
    dbUser: '',
    dbPass: '',
    privileges: ['ALL PRIVILEGES']
  });

  const stack = project.stack || {
    database: 'mysql',
    secondaryDb: 'redis'
  };

  const [instances, setInstances] = useState<DBInstance[]>(() => {
    const list: DBInstance[] = [];
    if (stack.database) {
      list.push({ 
        id: 'primary-db', 
        type: stack.database as 'mysql' | 'postgresql', 
        version: stack.database === 'mysql' ? '8.0.35' : '16.1', 
        status: 'running', cpu: 2, ram: 4, storage: 20 
      });
    }
    return list;
  });

  const [firewallIps] = useState(['192.168.1.1', '10.0.0.5']);
  
  const menuItems = [
    { id: 'overview', label: 'Genel Bakış', icon: Activity },
    { id: 'pma', label: 'phpMyAdmin', icon: Globe },
    { id: 'manage', label: 'Veritabanlarını Yönet', icon: HardDrive },
    { id: 'wizard', label: 'Veritabanı Sihirbazı', icon: Wand2 },
    { id: 'remote', label: 'Uzak Veritabanı', icon: Share2 },
  ];

  const handleUpdateResources = (id: string, updates: Partial<DBInstance>) => {
    setInstances(prev => prev.map(inst => inst.id === id ? { ...inst, ...updates } : inst));
  };

  const renderModule = () => {
    switch (activeModule) {
      case 'pma':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl relative overflow-hidden">
               <div className="absolute -bottom-10 -right-10 opacity-5">
                  <Globe className="w-64 h-64" />
               </div>
               <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center justify-between">
                  <div className="space-y-4 max-w-xl">
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl w-fit">
                      <Globe className="w-10 h-10" />
                    </div>
                    <h2 className="text-2xl font-bold text-white">phpMyAdmin Explorer</h2>
                    <p className="text-slate-400 text-sm leading-relaxed">
                      Seraiph OS üzerinden veritabanı tablolarını, sorgularını ve verilerini görsel olarak yönetin. 
                      Tek tıkla güvenli oturum açma yeteneği ile doğrudan erişim sağlayın.
                    </p>
                    <div className="flex gap-4">
                      <a 
                        href={`https://pma.${project.url.replace('https://', '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-bold transition-all flex items-center gap-3 shadow-lg shadow-emerald-600/20"
                      >
                        phpMyAdmin'i Aç <ArrowRight className="w-5 h-5" />
                      </a>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 w-full md:w-auto">
                    {[
                      { label: 'DB Sayısı', value: '4', icon: Database },
                      { label: 'Tablo Sayısı', value: '28', icon: HardDrive },
                      { label: 'Dizin Boyutu', value: '1.2 GB', icon: Server },
                      { label: 'Aktif Session', value: '2', icon: Activity },
                    ].map((stat, i) => (
                      <div key={i} className="p-6 bg-[#0f172a] border border-white/5 rounded-3xl text-center space-y-2">
                        <stat.icon className="w-5 h-5 text-emerald-400 mx-auto" />
                        <p className="text-2xl font-bold text-white">{stat.value}</p>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{stat.label}</p>
                      </div>
                    ))}
                  </div>
               </div>
            </div>
          </div>
        );

      case 'wizard':
        return (
          <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold text-white">Veritabanı Sihirbazı</h2>
              <p className="text-sm text-slate-500 italic">3 adımda güvenli veritabanı, kullanıcı ve yetkilendirmeyi tamamlayın.</p>
            </div>

            <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-8">
              {wizardStep === 1 && (
                <div className="space-y-6">
                  <div className="p-4 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl flex gap-4">
                    <Database className="w-6 h-6 text-indigo-400" />
                    <div>
                      <h4 className="font-bold text-white text-sm">Adım 1: Veritabanı Oluşturma</h4>
                      <p className="text-[11px] text-slate-500">Sistem veritabanı adının önüne proje ön ekini otomatik ekler.</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Veritabanı Adı</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">seraiph_</span>
                      <input 
                        type="text" 
                        value={wizardData.dbName}
                        onChange={(e) => setWizardData({...wizardData, dbName: e.target.value})}
                        className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-4 pl-20 pr-4 text-white focus:outline-none focus:border-indigo-500/50"
                        placeholder="my_app_prod"
                      />
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 2 && (
                <div className="space-y-6">
                  <div className="p-4 bg-amber-500/5 border border-amber-500/10 rounded-2xl flex gap-4">
                    <UserPlus className="w-6 h-6 text-amber-400" />
                    <div>
                      <h4 className="font-bold text-white text-sm">Adım 2: Kullanıcı Hesabı</h4>
                      <p className="text-[11px] text-slate-500">Güçlü bir şifre belirleyin veya sistemin üretmesini sağlayın.</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Kullanıcı Adı</label>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">seraiph_</span>
                            <input 
                                type="text" 
                                value={wizardData.dbUser}
                                onChange={(e) => setWizardData({...wizardData, dbUser: e.target.value})}
                                className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-4 pl-20 pr-4 text-white focus:outline-none focus:border-indigo-500/50"
                                placeholder="db_user"
                            />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Şifre</label>
                        <input 
                            type="password" 
                            className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-4 px-4 text-white focus:outline-none focus:border-indigo-500/50"
                            placeholder="••••••••••••"
                        />
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 3 && (
                <div className="space-y-6">
                  <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl flex gap-4">
                    <Shield className="w-6 h-6 text-emerald-400" />
                    <div>
                      <h4 className="font-bold text-white text-sm">Adım 3: Yetki Tanımlama</h4>
                      <p className="text-[11px] text-slate-500">Kullanıcının veritabanı üzerindeki yetkilerini sınırlandırın.</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP'].map(priv => (
                      <label key={priv} className="flex items-center gap-3 p-4 bg-[#0f172a] rounded-xl border border-white/5 cursor-pointer">
                        <input type="checkbox" defaultChecked />
                        <span className="text-xs font-bold text-slate-300">{priv}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                {wizardStep > 1 && (
                  <button 
                    onClick={() => setWizardStep(prev => prev - 1)}
                    className="px-6 py-4 bg-slate-800 text-white rounded-xl text-sm font-bold transition-all"
                  >
                    Geri Dön
                  </button>
                )}
                <button 
                  onClick={() => wizardStep < 3 ? setWizardStep(prev => prev + 1) : setActiveModule('manage')}
                  className="flex-1 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all"
                >
                  {wizardStep === 3 ? 'Tamamla' : 'Sonraki Adım'}
                </button>
              </div>
            </div>
          </div>
        );

      case 'remote':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-white flex items-center gap-3">
                    <Share2 className="w-6 h-6 text-orange-400" /> Remote Database Access
                  </h2>
                </div>
                <div className="p-4 bg-orange-400/5 border border-orange-400/10 rounded-2xl flex gap-4 text-xs text-slate-400 leading-relaxed">
                   <AlertCircle className="w-5 h-5 text-orange-400 shrink-0" />
                   Dış dünyadan erişimi açmadan önce IP whitelist eklediğinizden emin olun. Seraiph OS veritabanı sorgularınızı 256-bit SSL ile şifreler.
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="space-y-4">
                      <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">İzin Verilen IP Adresleri</h4>
                      <div className="flex flex-wrap gap-2">
                        {firewallIps.map(ip => (
                          <span key={ip} className="px-3 py-1.5 bg-[#0f172a] rounded-lg border border-white/5 text-[10px] font-mono text-slate-400">{ip}</span>
                        ))}
                      </div>
                   </div>
                   <div className="space-y-4">
                      <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Bağlantı Bilgileri</h4>
                      <div className="bg-[#0f172a] p-4 rounded-xl border border-white/5 space-y-2">
                        <p className="text-[10px] text-slate-500 font-bold uppercase">Host</p>
                        <p className="text-xs text-indigo-400 font-mono">sql.{project.url.replace('https://', '')}</p>
                      </div>
                   </div>
                </div>
            </div>
          </div>
        );

      case 'manage':
      default:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
            {instances.map(inst => (
              <div key={inst.id} className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-8">
                <div className="flex items-center gap-5">
                  <div className="p-5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-2xl">
                    <Database className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white capitalize">{inst.type} {inst.version}</h3>
                    <p className="text-xs text-slate-500 mt-1">Uptime: 99.9% | RAM: {inst.ram}GB</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedInstanceId(inst.id)}
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all"
                >
                  Instance Detayları
                </button>
              </div>
            ))}
          </div>
        );
      
      case 'overview':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {menuItems.filter(m => m.id !== 'overview').map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveModule(item.id as DBModule)}
                className="p-8 bg-[#1e293b] rounded-3xl border border-white/5 hover:border-indigo-500/30 transition-all text-left space-y-4 group"
              >
                <div className="p-3 bg-white/5 rounded-xl w-fit group-hover:bg-indigo-500 group-hover:text-white transition-all">
                  <item.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">{item.label}</h3>
                  <p className="text-[11px] text-slate-500 mt-1">Yönetim araçlarını açın</p>
                </div>
              </button>
            ))}
          </div>
        );
    }
  };

  const selectedInstance = instances.find(i => i.id === selectedInstanceId);

  if (selectedInstance) {
    return (
      <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setSelectedInstanceId(null)}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
              {selectedInstance.type.toUpperCase()} Yönetimi
            </h1>
            <p className="text-xs text-slate-500 mt-1">Instance: {selectedInstance.id}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-8">
            <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-xl p-8 space-y-8">
                <div className="grid grid-cols-2 gap-8 text-slate-200">
                    <div className="space-y-4">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">CPU Cores</label>
                        <div className="flex items-center gap-4">
                            <input 
                                type="range" min="1" max="16" value={selectedInstance.cpu}
                                onChange={(e) => handleUpdateResources(selectedInstance.id, { cpu: parseInt(e.target.value) })}
                                className="flex-1 accent-indigo-500"
                            />
                            <span className="text-sm font-bold">{selectedInstance.cpu} Cores</span>
                        </div>
                    </div>
                    <div className="space-y-4">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">RAM (GB)</label>
                        <div className="flex items-center gap-4">
                            <input 
                                type="range" min="1" max="32" value={selectedInstance.ram}
                                onChange={(e) => handleUpdateResources(selectedInstance.id, { ram: parseInt(e.target.value) })}
                                className="flex-1 accent-indigo-500"
                            />
                            <span className="text-sm font-bold">{selectedInstance.ram} GB</span>
                        </div>
                    </div>
                </div>
                <div className="pt-8 border-t border-white/5 flex justify-end">
                    <button className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all">
                        Değişiklikleri Kaydet
                    </button>
                </div>
            </div>
          </div>

          <div className="space-y-8">
             <div className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 space-y-6">
                <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Performans Özeti</h3>
                <div className="space-y-4">
                    <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500">I/O Wait</span>
                        <span className="text-white font-bold">0.8ms</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500">Connections</span>
                        <span className="text-emerald-400 font-bold">12 / 100</span>
                    </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
      {/* Header */}
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={activeModule === 'overview' ? onBack : () => setActiveModule('overview')}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
              Veri Tabanı Yönetimi
              <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 text-[10px] uppercase tracking-widest rounded border border-indigo-500/20">
                {activeModule.toUpperCase()}
              </span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">İzole konteynerler ve performans odaklı altyapı yönetimi</p>
          </div>
        </div>

        <div className="flex gap-2 p-1 bg-[#1e293b] rounded-2xl border border-white/5 overflow-x-auto w-fit">
          {menuItems.map((item) => (
             <button
                key={item.id}
                onClick={() => {
                   setActiveModule(item.id as DBModule);
                   if (item.id === 'wizard') setWizardStep(1);
                }}
                className={cn(
                  "px-4 py-2 rounded-xl transition-all flex items-center gap-2 whitespace-nowrap",
                  activeModule === item.id ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : "text-slate-500 hover:text-slate-300 hover:bg-white/5"
                )}
             >
                <item.icon className="w-4 h-4" />
                <span className="text-xs font-bold">{item.label}</span>
             </button>
          ))}
        </div>
      </div>

      {renderModule()}
    </div>
  );
};
