import React, { useState } from 'react';
import { 
  Cpu, Box, RefreshCcw, Terminal, Archive, 
  Settings, AlertCircle, CheckCircle2, 
  ArrowLeft, Search, Activity, Package,
  Zap, Database, Server, Terminal as SSHIcon,
  Play, Square, Info, ExternalLink,
  ChevronRight, Disc
} from 'lucide-react';
import { Project } from '../../types';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell 
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SoftwareManagementProps {
  project: Project;
  onBack: () => void;
  onGlobalTabChange: (tab: string) => void;
}

const resourceData = [
  { name: 'Go API', value: 35, color: '#6366f1' },
  { name: 'Nginx', value: 15, color: '#10b981' },
  { name: 'PostgreSQL', value: 25, color: '#3b82f6' },
  { name: 'Redis', value: 10, color: '#ef4444' },
  { name: 'Diğer', value: 15, color: '#475569' },
];

export const SoftwareManagement: React.FC<SoftwareManagementProps> = ({ project, onBack, onGlobalTabChange }) => {
  const [activeTab, setActiveTab] = useState<'runtimes' | 'docker' | 'updates' | 'logs'>('runtimes');

  const dockerContainers = [
    { id: 'c-1', name: 'app-frontend', image: 'react-app:v2.4', status: 'running', ram: '124MB', cpu: '2.4%', uptime: '14d' },
    { id: 'c-2', name: 'app-backend', image: 'go-backend:v1.1', status: 'running', ram: '256MB', cpu: '12.1%', uptime: '14d' },
    { id: 'c-3', name: 'app-database', image: 'postgres:16', status: 'running', ram: '840MB', cpu: '4.5%', uptime: '32d' },
    { id: 'c-4', name: 'app-redis', image: 'redis:7-alpine', status: 'running', ram: '42MB', cpu: '0.8%', uptime: '32d' },
  ];

  const metrics = [
    { label: 'Çalışan Servis', value: '12', icon: Activity, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { label: 'Bekleyen Güncelleme', value: '4', icon: AlertCircle, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { label: 'Docker Container', value: '8', icon: Box, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
    { label: 'Paket Sayısı', value: '1.428', icon: Package, color: 'text-blue-500', bg: 'bg-blue-500/10' },
  ];

  const runtimeServices = [
    { name: 'Go Runtime', version: '1.22.x', port: '8080', status: 'active', usage: '12% CPU / 45MB RAM' },
    { name: 'Rust Engine', version: '1.77.x', port: '9000', status: 'active', usage: '8% CPU / 12MB RAM' },
    { name: 'Python Worker', version: '3.11.x', port: 'N/A', status: 'active', usage: '18% CPU / 120MB RAM' },
    { name: 'Nginx Proxy', version: '1.24.x', port: '80/443', status: 'active', usage: '2% CPU / 15MB RAM' },
    { name: 'PostgreSQL', version: '16.2', port: '5432', status: 'active', usage: '5% CPU / 850MB RAM' },
    { name: 'Redis Stack', version: '7.2', port: '6379', status: 'active', usage: '1% CPU / 240MB RAM' },
    { name: 'Cosmos DB Proxy', version: 'v2.4', port: '10255', status: 'active', usage: '4% CPU / 32MB RAM' },
    { name: 'Certbot (SSL)', version: '2.9.x', port: 'N/A', status: 'idle', usage: 'Auto-renewal active' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Yazılım Yönetimi</h1>
            <p className="text-xs text-slate-500 mt-1">Uygulama altyapısı, servisler ve container yönetim paneli</p>
          </div>
        </div>
        <div className="flex bg-[#1e293b] rounded-2xl border border-white/5 p-1">
          <button 
            onClick={() => onGlobalTabChange('terminal')}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20"
          >
             <SSHIcon className="w-3.5 h-3.5" /> Terminal Aç
          </button>
        </div>
      </div>

      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((stat, i) => (
          <div key={i} className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl flex items-center gap-4">
            <div className={cn("p-3 rounded-2xl border border-white/5", stat.bg)}>
              <stat.icon className={cn("w-6 h-6", stat.color)} />
            </div>
            <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{stat.label}</p>
              <p className="text-2xl font-black text-white">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main Grid: Services & Resource Share */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Resource Usage & Quick Actions */}
        <div className="lg:col-span-1 space-y-8">
           {/* Resource Usage Chart */}
           <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Kaynak Kullanım Payı</h3>
              <div className="h-[200px] w-full flex items-center justify-center">
                 <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                       <Pie
                        data={resourceData}
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                       >
                         {resourceData.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                         ))}
                       </Pie>
                       <Tooltip 
                        contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '12px' }}
                        itemStyle={{ color: '#fff', fontSize: '10px' }}
                       />
                    </PieChart>
                 </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 {resourceData.map((item) => (
                   <div key={item.name} className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.name}</span>
                   </div>
                 ))}
              </div>
           </div>

           {/* Quick Actions */}
           <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-4">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Hızlı İşlemler</h3>
              <div className="grid grid-cols-2 gap-3">
                 <button className="flex flex-col items-center gap-3 p-4 bg-[#0f172a]/50 hover:bg-slate-800 rounded-2xl border border-white/5 transition-all group">
                    <RefreshCcw className="w-5 h-5 text-indigo-400 group-hover:rotate-180 transition-transform duration-500" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Restart All</span>
                 </button>
                 <button className="flex flex-col items-center gap-3 p-4 bg-[#0f172a]/50 hover:bg-slate-800 rounded-2xl border border-white/5 transition-all group">
                    <Zap className="w-5 h-5 text-amber-500 group-hover:scale-110 transition-transform" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Update Soft</span>
                 </button>
                 <button className="flex flex-col items-center gap-3 p-4 bg-[#0f172a]/50 hover:bg-slate-800 rounded-2xl border border-white/5 transition-all group">
                    <SSHIcon className="w-5 h-5 text-emerald-500 group-hover:translate-x-1 transition-transform" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Open SSH</span>
                 </button>
                 <button className="flex flex-col items-center gap-3 p-4 bg-[#0f172a]/50 hover:bg-slate-800 rounded-2xl border border-white/5 transition-all group">
                    <Archive className="w-5 h-5 text-blue-500 group-hover:-translate-y-1 transition-transform" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Take Backup</span>
                 </button>
              </div>
           </div>
        </div>

        {/* Runtime Services List */}
        <div className="lg:col-span-2 bg-[#1e293b] rounded-3xl border border-white/5 shadow-xl overflow-hidden flex flex-col">
           <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
              <div className="flex items-center gap-4">
                 <h3 className="text-sm font-bold text-white uppercase tracking-widest">Runtime Servisleri</h3>
                 <div className="flex bg-[#0f172a] rounded-lg border border-white/5 p-1 gap-1">
                    <button className={cn("px-3 py-1 text-[10px] font-bold rounded-md transition-all", activeTab === 'runtimes' ? "bg-white/5 text-white" : "text-slate-500 hover:text-slate-300")} onClick={() => setActiveTab('runtimes')}>Tümü</button>
                    <button className={cn("px-3 py-1 text-[10px] font-bold rounded-md transition-all", activeTab === 'docker' ? "bg-white/5 text-white" : "text-slate-500 hover:text-slate-300")} onClick={() => setActiveTab('docker')}>Docker</button>
                 </div>
              </div>
              <div className="relative">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
                 <input 
                  type="text" 
                  placeholder="Servis ara..."
                  className="bg-[#0f172a] border border-white/5 rounded-xl py-1.5 pl-9 pr-3 text-[10px] font-medium text-slate-300 focus:outline-none focus:border-indigo-500/50"
                 />
              </div>
           </div>

           <div className="divide-y divide-white/5 max-h-[700px] overflow-y-auto custom-scrollbar">
              {activeTab === 'runtimes' ? (
                runtimeServices.map((service, i) => (
                  <div key={i} className="p-6 hover:bg-white/[0.02] flex items-center justify-between group transition-all">
                    <div className="flex items-center gap-6">
                        <div className={cn(
                          "p-4 rounded-2xl border",
                          service.status === 'active' ? "bg-emerald-500/5 border-emerald-500/10" : "bg-slate-500/5 border-white/5"
                        )}>
                          {service.name.includes('Go') && <Disc className="w-6 h-6 text-indigo-400" />}
                          {service.name.includes('Rust') && <Zap className="w-6 h-6 text-orange-400" />}
                          {service.name.includes('Python') && <Cpu className="w-6 h-6 text-blue-400" />}
                          {service.name.includes('DB') || service.name.includes('Postgre') || service.name.includes('Redis') ? <Database className="w-6 h-6 text-teal-400" /> : null}
                          {service.name.includes('Nginx') || service.name.includes('Proxy') ? <Server className="w-6 h-6 text-emerald-400" /> : null}
                          {service.name.includes('Cert') && <Shield className="w-6 h-6 text-amber-500" />}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-3">
                              <h4 className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors uppercase">{service.name}</h4>
                              <span className="text-[10px] font-bold text-slate-500 font-mono italic">v{service.version}</span>
                          </div>
                          <div className="flex items-center gap-4 text-[10px] text-slate-500 font-medium tracking-tight">
                              <span className="flex items-center gap-1.5">
                                <div className={cn("w-1.5 h-1.5 rounded-full", service.status === 'active' ? "bg-emerald-500 shadow-lg shadow-emerald-500/20" : "bg-slate-600")} />
                                {service.status.toUpperCase()}
                              </span>
                              {service.port !== 'N/A' && <span>PORT: {service.port}</span>}
                          </div>
                        </div>
                    </div>
                    <div className="flex items-center gap-12">
                        <div className="text-right hidden md:block">
                          <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Kaynak Kullanımı</p>
                          <p className="text-xs font-mono text-slate-300">{service.usage}</p>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 bg-[#0f172a] hover:bg-white/5 rounded-xl border border-white/5 text-slate-500 hover:text-white transition-all shadow-sm">
                              <RefreshCcw className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-2 bg-[#0f172a] hover:bg-white/5 rounded-xl border border-white/5 text-slate-500 hover:text-white transition-all shadow-sm">
                              <Settings className="w-3.5 h-3.5" />
                          </button>
                        </div>
                    </div>
                  </div>
                ))
              ) : (
                dockerContainers.map((container) => (
                  <div key={container.id} className="p-6 hover:bg-white/[0.02] flex items-center justify-between group transition-all">
                    <div className="flex items-center gap-6">
                        <div className="p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/10">
                          <Box className="w-6 h-6 text-indigo-400" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-3">
                              <h4 className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors">{container.name}</h4>
                              <span className="text-[10px] font-bold text-slate-500 font-mono italic">{container.image}</span>
                          </div>
                          <div className="flex items-center gap-4 text-[10px] text-slate-500 font-medium tracking-tight">
                              <span className="flex items-center gap-1.5">
                                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/20" />
                                {container.status.toUpperCase()}
                              </span>
                              <span>UPTIME: {container.uptime}</span>
                          </div>
                        </div>
                    </div>
                    <div className="flex items-center gap-12">
                        <div className="text-right hidden md:block">
                          <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Kaynak Kullanımı</p>
                          <p className="text-xs font-mono text-slate-300">{container.cpu} CPU / {container.ram} RAM</p>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 bg-[#0f172a] hover:bg-white/5 rounded-xl border border-white/5 text-emerald-500 transition-all shadow-sm">
                              <Play className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-2 bg-[#0f172a] hover:bg-white/5 rounded-xl border border-white/5 text-rose-500 transition-all shadow-sm">
                              <Square className="w-3.5 h-3.5" />
                          </button>
                        </div>
                    </div>
                  </div>
                ))
              )}
           </div>
        </div>
      </div>

      {/* Pending Updates & Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
         {/* Pending Updates */}
         <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
            <div className="flex items-center justify-between">
               <div className="flex items-center gap-4">
                  <AlertCircle className="w-6 h-6 text-amber-500" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-widest">Bekleyen Güncellemeler</h3>
               </div>
               <button className="px-4 py-1.5 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-600 hover:text-white rounded-xl text-[10px] font-black uppercase tracking-widest border border-emerald-500/20 transition-all">
                  TÜMÜNÜ GÜNCELLE
               </button>
            </div>
            
            <div className="space-y-4">
               {[
                 { pkg: 'System Kernel Patch 2024-Q2', type: 'security', version: 'v5.10.211', severity: 'High' },
                 { pkg: 'PostgreSQL Maintenance Update', type: 'minor', version: 'v16.2 -> v16.3', severity: 'Medium' },
                 { pkg: 'Nginx Security Fix', type: 'security', version: 'v1.24.0 -> v1.25.1', severity: 'Critical' },
                 { pkg: 'Python 3.11.x Pip Upgrade', type: 'minor', version: 'v24.0', severity: 'Low' },
               ].map((update, i) => (
                 <div key={i} className="flex items-center justify-between p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5 group transition-all">
                    <div className="flex items-center gap-4">
                       <div className={cn(
                         "w-1 h-8 rounded-full",
                         update.type === 'security' ? "bg-rose-500" : "bg-blue-500"
                       )} />
                       <div className="space-y-0.5">
                          <p className="text-xs font-bold text-slate-200">{update.pkg}</p>
                          <p className="text-[10px] text-slate-500 font-mono">{update.version}</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-6">
                       <span className={cn(
                         "text-[9px] font-black uppercase px-2 py-0.5 rounded border",
                         update.severity === 'Critical' ? "text-rose-500 border-rose-500/20 bg-rose-500/5" :
                         update.severity === 'High' ? "text-orange-500 border-orange-500/20 bg-orange-500/5" :
                         "text-slate-500 border-white/5 bg-white/10"
                       )}>
                         {update.severity}
                       </span>
                       <button className="p-2 opacity-0 group-hover:opacity-100 hover:bg-white/10 rounded-xl text-indigo-400 transition-all">
                          <Play className="w-3.5 h-3.5" />
                       </button>
                    </div>
                 </div>
               ))}
            </div>
         </div>

         {/* Deployment Logs */}
         <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
            <div className="flex items-center justify-between">
               <div className="flex items-center gap-4">
                  <Terminal className="w-6 h-6 text-indigo-400" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-widest">Deployment Logları</h3>
               </div>
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Canlı Servis</span>
               </div>
            </div>

            <div className="bg-[#0f172a] rounded-2xl border border-white/5 p-4 font-mono text-[10px] text-slate-400 space-y-2 h-[240px] overflow-y-auto custom-scrollbar">
               <p className="text-emerald-500/80">[14:32:01] Go API: Container started on port 8080</p>
               <p className="text-slate-500">[14:32:05] Redis: Database is ready to accept connections</p>
               <p className="text-slate-500">[14:32:08] Nginx: Worker process 1528 started</p>
               <p className="text-amber-500/80">[14:33:45] WARNING: Python Worker reached 80% RAM utilization (112MB)</p>
               <p className="text-slate-500">[14:35:12] Certbot: Skipping renewal, 82 days remaining</p>
               <p className="text-indigo-400">[14:38:22] CI/CD: New commit detected (sha: f8e2d9)</p>
               <p className="text-slate-500">[14:38:25] Build: Running tests for Go Runtime...</p>
               <p className="text-emerald-500/80">[14:38:45] Success: Tests passed (28 passed, 0 failed)</p>
               <p className="text-slate-500">[14:39:00] Build: Push successful. Deploying new image...</p>
            </div>

            <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase tracking-widest pt-2">
               <span>Gösterilen Log: 142</span>
               <button className="text-indigo-400 hover:text-indigo-300 transition-colors">TÜMÜNÜ AÇ →</button>
            </div>
         </div>
      </div>
    </div>
  );
};

function Shield(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
    </svg>
  )
}
