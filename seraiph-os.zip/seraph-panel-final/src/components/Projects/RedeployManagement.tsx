import React, { useState, useEffect } from 'react';
import { 
  RefreshCw, Play, Clock, CheckCircle2, 
  XCircle, Loader2, GitBranch, Terminal,
  ArrowLeft, Search, Filter, Trash2,
  ChevronRight, AlertCircle, Info, Zap
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface RedeployManagementProps {
  project: Project;
  onBack: () => void;
}

export const RedeployManagement: React.FC<RedeployManagementProps> = ({ project, onBack }) => {
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployProgress, setDeployProgress] = useState(0);
  const [activeTab, setActiveTab] = useState<'history' | 'logs'>('history');

  const deployments = [
    { id: 'dep-102', version: 'v2.4.2', author: 'Sinan B.', date: 'Today, 14:20', status: 'success', branch: 'main', commit: 'f8e2d9a' },
    { id: 'dep-101', version: 'v2.4.1', author: 'Sinan B.', date: 'Today, 09:12', status: 'success', branch: 'main', commit: 'a1b2c3d' },
    { id: 'dep-100', version: 'v2.4.0', author: 'Sinan B.', date: 'Yesterday, 18:45', status: 'failed', branch: 'main', commit: 'd5e6f7g', error: 'Build timeout' },
    { id: 'dep-099', version: 'v2.3.9', author: 'System', date: '2 days ago', status: 'success', branch: 'main', commit: 'b4a5c6d' },
    { id: 'dep-098', version: 'v2.3.8', author: 'Sinan B.', date: '3 days ago', status: 'success', branch: 'main', commit: 'e2f1g0h' },
  ];

  const handleRedeploy = () => {
    setIsDeploying(true);
    setDeployProgress(0);
  };

  useEffect(() => {
    if (isDeploying) {
      const interval = setInterval(() => {
        setDeployProgress(prev => {
          if (prev >= 100) {
            setIsDeploying(false);
            clearInterval(interval);
            return 100;
          }
          return prev + 5;
        });
      }, 200);
      return () => clearInterval(interval);
    }
  }, [isDeploying]);

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
              Redeploy Management
              <RefreshCw className={cn("w-5 h-5 text-indigo-400", isDeploying && "animate-spin")} />
            </h1>
            <p className="text-xs text-slate-500 mt-1">Uygulamayı yeniden yayına al, sürüm geçmişini ve logları yönet</p>
          </div>
        </div>
        <button 
          onClick={handleRedeploy}
          disabled={isDeploying}
          className={cn(
            "px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-xl",
            isDeploying 
              ? "bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5" 
              : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20 active:scale-95"
          )}
        >
          {isDeploying ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Deploying... {deployProgress}%
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 fill-white" /> Trigger Redeploy
            </>
          )}
        </button>
      </div>

      {isDeploying && (
        <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-2xl space-y-6 animate-in zoom-in-95 duration-500">
           <div className="flex items-center justify-between">
              <div className="space-y-1">
                 <h3 className="text-sm font-bold text-white uppercase tracking-widest">Active Build Process</h3>
                 <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Version: v2.4.3 • Commit: g9h8i7j</p>
              </div>
              <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                 <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Building Image</span>
              </div>
           </div>
           
           <div className="space-y-2">
              <div className="h-2 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
                 <div 
                  className="h-full bg-gradient-to-r from-indigo-600 to-indigo-400 transition-all duration-300" 
                  style={{ width: `${deployProgress}%` }}
                 />
              </div>
              <div className="flex justify-between text-[9px] font-bold text-slate-500 uppercase tracking-widest">
                 <span>Pulling Base Image</span>
                 <span>Deploying to Cluster</span>
              </div>
           </div>

           <div className="bg-[#0f172a] rounded-2xl border border-white/5 p-4 font-mono text-[10px] text-slate-400 h-32 overflow-y-auto custom-scrollbar">
              <p className="text-slate-500">[16:48:01] Preparing build environment...</p>
              <p className="text-slate-500">[16:48:05] Checking repository credentials...</p>
              <p className="text-indigo-400">[16:48:10] Running: npm install</p>
              <p className="text-slate-500">[16:48:22] Found 1428 packages. Building production bundle...</p>
              {deployProgress > 50 && <p className="text-indigo-400">[16:48:35] Running: npm run build</p>}
              {deployProgress > 80 && <p className="text-emerald-500">[16:48:45] Build successful. Exporting static files...</p>}
           </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Summary & Info */}
        <div className="lg:col-span-1 space-y-6">
           <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-6">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Deployment Info</h3>
              <div className="space-y-4">
                 <div className="flex items-center justify-between p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-3">
                       <GitBranch className="w-4 h-4 text-indigo-400" />
                       <span className="text-xs font-bold text-white uppercase">Default Branch</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 bg-white/5 px-2 py-0.5 rounded">main</span>
                 </div>
                 <div className="flex items-center justify-between p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-3">
                       <Terminal className="w-4 h-4 text-emerald-400" />
                       <span className="text-xs font-bold text-white uppercase">Root Directory</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 bg-white/5 px-2 py-0.5 rounded">./src</span>
                 </div>
                 <div className="flex items-center justify-between p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-3">
                       <Zap className="w-4 h-4 text-amber-500" />
                       <span className="text-xs font-bold text-white uppercase">Build Command</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 bg-white/5 px-2 py-0.5 rounded">npm run build</span>
                 </div>
              </div>

              <div className="p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/20 sm:flex gap-4 items-start">
                 <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-1" />
                 <p className="text-[10px] font-medium leading-relaxed text-indigo-300">
                    Auto-reploy is active. Every push to the <code className="text-white">main</code> branch will trigger a new build automatically.
                 </p>
              </div>
           </div>

           <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-xl space-y-4">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Danger Zone</h3>
              <button className="w-full flex items-center justify-between p-4 bg-rose-500/5 hover:bg-rose-500/10 border border-rose-500/10 rounded-2xl text-rose-500 transition-all group">
                 <div className="flex items-center gap-3">
                    <Trash2 className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-tight">Purge Build Cache</span>
                 </div>
                 <ChevronRight className="w-4 h-4 opacity-40 group-hover:opacity-100 transition-opacity" />
              </button>
           </div>
        </div>

        {/* Right Column: Deployment History */}
        <div className="lg:col-span-2 bg-[#1e293b] rounded-3xl border border-white/5 shadow-xl overflow-hidden flex flex-col">
           <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
              <div className="flex items-center gap-4">
                 <h3 className="text-sm font-bold text-white uppercase tracking-widest">Sürüm Geçmişi</h3>
                 <div className="flex bg-[#0f172a] rounded-lg border border-white/5 p-1 gap-1">
                    <button 
                      className={cn("px-3 py-1 text-[10px] font-bold rounded-md transition-all", activeTab === 'history' ? "bg-white/5 text-white" : "text-slate-500 hover:text-slate-300")}
                      onClick={() => setActiveTab('history')}
                    >All</button>
                    <button 
                      className={cn("px-3 py-1 text-[10px] font-bold rounded-md transition-all", activeTab === 'logs' ? "bg-white/5 text-white" : "text-slate-500 hover:text-slate-300")}
                      onClick={() => setActiveTab('logs')}
                    >System Logs</button>
                 </div>
              </div>
              <div className="flex items-center gap-3">
                 <Filter className="w-4 h-4 text-slate-500" />
                 <Search className="w-4 h-4 text-slate-500" />
              </div>
           </div>

           <div className="divide-y divide-white/5">
              {deployments.map((dep) => (
                <div key={dep.id} className="p-6 hover:bg-white/[0.02] transition-colors group">
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-6">
                         <div className={cn(
                           "p-4 rounded-2xl border",
                           dep.status === 'success' ? "bg-emerald-500/5 border-emerald-500/10 text-emerald-500" : "bg-rose-500/5 border-rose-500/10 text-rose-500"
                         )}>
                            {dep.status === 'success' ? <CheckCircle2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                         </div>
                         <div className="space-y-1">
                            <div className="flex items-center gap-3">
                               <h4 className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors uppercase">{dep.version}</h4>
                               <span className="text-[10px] font-bold text-slate-500 font-mono italic">#{dep.commit}</span>
                            </div>
                            <div className="flex items-center gap-4 text-[10px] text-slate-500 font-medium tracking-tight">
                               <span className="flex items-center gap-1.5 capitalize">
                                  <Clock className="w-3 h-3" />
                                  {dep.date}
                               </span>
                               <span className="flex items-center gap-1.5">
                                  <GitBranch className="w-3 h-3" />
                                  {dep.branch}
                               </span>
                            </div>
                         </div>
                      </div>
                      <div className="flex items-center gap-12">
                         <div className="text-right hidden md:block">
                            <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Author</p>
                            <p className="text-xs font-bold text-slate-300">{dep.author}</p>
                         </div>
                         <div className="flex gap-2">
                            <button 
                              onClick={() => onBack()}
                              className="p-2 bg-[#0f172a] hover:bg-white/5 rounded-xl border border-white/5 text-slate-500 hover:text-white transition-all shadow-sm"
                            >
                               <Terminal className="w-4 h-4" />
                            </button>
                            <button className="p-2 bg-[#0f172a] hover:bg-indigo-600/10 rounded-xl border border-white/5 text-indigo-400 transition-all shadow-sm">
                               <RefreshCw className="w-4 h-4" />
                            </button>
                         </div>
                      </div>
                   </div>
                   {dep.error && (
                     <div className="mt-4 p-3 bg-rose-500/5 rounded-xl border border-rose-500/10 flex items-center gap-3">
                        <AlertCircle className="w-4 h-4 text-rose-500" />
                        <span className="text-[10px] font-mono text-rose-400">{dep.error}</span>
                     </div>
                   )}
                </div>
              ))}
           </div>
           
           <div className="p-6 bg-[#0f172a]/20 border-t border-white/5 text-center">
              <button className="text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-indigo-400 transition-colors">
                 Show Older Deployments (24 more) →
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};
