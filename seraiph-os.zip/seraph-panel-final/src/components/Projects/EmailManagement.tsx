import React from 'react';
import { 
  ArrowLeft, Mail, ArrowRight, Shuffle, MessageSquare, AtSign, 
  List, Activity, Filter, CheckCircle, Upload, ShieldAlert, 
  Archive, Lock, UserCheck, HardDrive, ChevronRight 
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface EmailManagementProps {
  project: Project;
  onBack: () => void;
  onToolClick: (toolId: string) => void;
}

export const EmailManagement: React.FC<EmailManagementProps> = ({ project, onBack, onToolClick }) => {
  const emailTools = [
    { id: 'email-read', title: 'E-posta Oku', icon: Mail, color: 'text-indigo-400', desc: 'Gelen mesajlarınızı kontrol edin ve yanıtlayın' },
    { id: 'email-accounts', title: 'E-posta Hesapları', icon: Mail, color: 'text-blue-400', desc: 'Hesap oluşturun ve yönetin' },
    { id: 'routing', title: 'E-posta Yönlendirmesi', icon: Shuffle, color: 'text-purple-400', desc: 'Gelen e-posta akışını kontrol edin' },
    { id: 'mailing-lists', title: 'Posta Listeleri', icon: List, color: 'text-cyan-400', desc: 'Toplu e-posta gönderim listeleri' },
    { id: 'spam-filters', title: 'Spam ve Antivirüs Filtreleri', icon: ShieldAlert, color: 'text-red-400', desc: 'Seraiph OS gelişmiş koruma kalkanı' },
    { id: 'disk-usage', title: 'Email Disk Usage', icon: HardDrive, color: 'text-blue-600', desc: 'Kota kullanımını görüntüleyin ve temizleyin' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-white">E-posta Yönetimi</h1>
              <div className="px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-500 border border-blue-500/20 text-[10px] font-bold uppercase tracking-wider">
                {project.name}
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-1">Kurumsal e-posta servislerini ve güvenlik ayarlarını yönetin</p>
          </div>
        </div>
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {emailTools.map((tool, i) => (
          <button 
            key={i}
            onClick={() => onToolClick(tool.id)}
            className="bg-[#1e293b] p-5 rounded-2xl border border-white/5 hover:border-blue-500/30 transition-all group text-left flex flex-col gap-4 shadow-lg"
          >
            <div className="flex items-center justify-between w-full">
              <div className={cn("p-3 rounded-xl bg-[#0f172a] border border-white/5 group-hover:scale-110 transition-transform", tool.color)}>
                <tool.icon className="w-6 h-6" />
              </div>
              <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-blue-400 transition-colors" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-200 group-hover:text-white transition-colors">{tool.title}</h3>
              <p className="text-[11px] text-slate-500 font-medium mt-1 leading-relaxed">{tool.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Quick Stats / Info */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl">
          <h3 className="text-sm font-bold text-slate-200 uppercase tracking-widest mb-6 flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-400" />
            Son E-posta Faaliyetleri
          </h3>
          <div className="space-y-4">
            {[
              { user: 'info@' + project.url.split('//')[1], action: 'Giriş yapıldı', time: '5 dk önce', status: 'success' },
              { user: 'destek@' + project.url.split('//')[1], action: 'Şifre değiştirildi', time: '1 saat önce', status: 'warning' },
              { user: 'satis@' + project.url.split('//')[1], action: 'Yeni hesap oluşturuldu', time: '3 saat önce', status: 'success' },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-[#0f172a]/50 border border-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Mail className="w-4 h-4 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-200">{item.user}</p>
                    <p className="text-[10px] text-slate-500">{item.action}</p>
                  </div>
                </div>
                <span className="text-[10px] text-slate-500 font-mono">{item.time}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl">
          <h3 className="text-sm font-bold text-slate-200 uppercase tracking-widest mb-6">Disk Kullanımı</h3>
          <div className="space-y-6">
            <div className="relative pt-1">
              <div className="flex mb-2 items-center justify-between">
                <div>
                  <span className="text-[10px] font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                    Kullanılan Alan
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-semibold inline-block text-blue-600">
                    45%
                  </span>
                </div>
              </div>
              <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200/10">
                <div style={{ width: "45%" }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"></div>
              </div>
              <p className="text-[10px] text-slate-500 text-center">4.5 GB / 10 GB Toplam Kota</p>
            </div>
            
            <div className="pt-4 border-t border-white/5">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-3">Güvenlik Durumu</p>
              <div className="flex items-center gap-2 text-emerald-500">
                <ShieldAlert className="w-4 h-4" />
                <span className="text-xs font-bold">SpamAssassin™ Aktif</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
