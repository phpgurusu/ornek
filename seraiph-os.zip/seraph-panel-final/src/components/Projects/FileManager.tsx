import React, { useState } from 'react';
import { 
  Folder, File, FolderPlus, FilePlus, Upload, 
  Download, Scissors, Copy, Trash2, Edit3, 
  Archive, ChevronRight, ChevronDown, Search,
  MoreVertical, ArrowLeft, HardDrive, Shield,
  RefreshCcw, ExternalLink, Code, Wand2, GitBranch,
  Image, Globe, Zap, Activity
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface FileManagerProps {
  project: Project;
  onBack: () => void;
}

interface FileItem {
  id: string;
  name: string;
  type: 'folder' | 'file';
  size?: string;
  modified: string;
  permissions: string;
  owner: string;
}

type FileView = 'overview' | 'explorer' | 'disk' | 'backup' | 'wizard' | 'restoration';

export const FileManager: React.FC<FileManagerProps> = ({ project, onBack }) => {
  const [activeView, setActiveView] = useState<FileView>('overview');
  const [currentPath, setCurrentPath] = useState<string[]>(['public_html']);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [expandedFolders, setExpandedFolders] = useState<string[]>(['root', 'public_html']);

  const dashboardItems = [
    { id: 'explorer', label: 'Dosya Yöneticisi', icon: Folder, desc: 'Dosyalarınızı yönetin, yükleyin ve düzenleyin' },
    { id: 'disk', label: 'Disk Kullanımı', icon: HardDrive, desc: 'Dizin bazlı depolama raporu' },
    { id: 'backup', label: 'Yedekleme', icon: Archive, desc: 'Tam veya kısmi yedekler oluşturun' },
    { id: 'wizard', label: 'Yedekleme Sihirbazı', icon: Wand2, desc: 'Adım adım yedekleme ve geri yükleme' },
    { id: 'restoration', label: 'File and Directory Restoration', icon: RefreshCcw, desc: 'Silinen dosyaları yedeğinden kurtarın' },
  ];

  if (activeView === 'overview') {
    return (
      <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
              Dosya Yönetimi
              <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 text-[10px] uppercase tracking-widest rounded border border-indigo-500/20">
                PRO
              </span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">Dosyalarınızı, yedeklerinizi ve altyapı raporlarınızı kontrol edin</p>
          </div>
        </div>

        <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-2xl">
          <div className="p-5 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
             <div className="flex items-center gap-3">
                <Folder className="w-5 h-5 text-indigo-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">Dosyalar</h2>
             </div>
             <ChevronDown className="w-4 h-4 text-slate-500" />
          </div>
          <div className="p-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-10">
            {dashboardItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id as FileView)}
                className="flex items-start gap-4 hover:scale-[1.02] transition-all group text-left"
              >
                <div className={cn(
                  "p-3 rounded-2xl bg-white/5 border border-white/5 group-hover:bg-indigo-500 group-hover:text-white transition-all shrink-0",
                  (item as any).accent
                )}>
                  <item.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-200 group-hover:text-white transition-colors">{item.label}</h3>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{item.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="bg-[#1e293b]/50 p-6 rounded-3xl border border-white/5 flex items-center justify-between">
              <div className="space-y-1">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Disk Kotası</p>
                 <p className="text-lg font-bold text-white">420 MB / 5 GB</p>
              </div>
              <div className="w-32 h-2 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
                 <div className="h-full bg-indigo-500 w-[12%]" />
              </div>
           </div>
           <div className="bg-[#1e293b]/50 p-6 rounded-3xl border border-white/5 flex items-center justify-between">
              <div className="space-y-1">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Yedekleme Durumu</p>
                 <p className="text-lg font-bold text-emerald-400">Güncel</p>
              </div>
              <Activity className="w-6 h-6 text-emerald-400/50" />
           </div>
        </div>
      </div>
    );
  }

  // --- Disk Usage View ---
  if (activeView === 'disk') {
    return (
      <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setActiveView('overview')}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Disk Kullanımı</h1>
            <p className="text-xs text-slate-500 mt-1">Dizinlerinizin diskteki boyutlarını ve kullanım oranlarını inceleyin</p>
          </div>
        </div>

        <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-8 shadow-2xl space-y-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-indigo-400 uppercase tracking-widest">Kullanım Özeti</h3>
              <div className="space-y-4">
                 {[
                   { name: 'public_html', size: '320.5 MB', percent: 64 },
                   { name: 'mail', size: '45.2 MB', percent: 9 },
                   { name: 'logs', size: '28.1 MB', percent: 6 },
                   { name: 'tmp', size: '12.4 MB', percent: 3 },
                   { name: 'Diğer', size: '13.8 MB', percent: 3 },
                 ].map((dir) => (
                   <div key={dir.name} className="space-y-2">
                     <div className="flex justify-between text-xs font-medium">
                       <span className="text-slate-300">{dir.name}</span>
                       <span className="text-slate-500">{dir.size} ({dir.percent}%)</span>
                     </div>
                     <div className="h-1.5 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
                       <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${dir.percent}%` }} />
                     </div>
                   </div>
                 ))}
              </div>
            </div>

            <div className="bg-[#0f172a]/50 p-8 rounded-3xl border border-white/5 flex flex-col items-center justify-center text-center space-y-4">
               <div className="relative w-32 h-32">
                 <svg className="w-full h-full transform -rotate-90">
                   <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-white/5" />
                   <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-indigo-500" strokeDasharray={364.4} strokeDashoffset={364.4 * (1 - 0.12)} strokeLinecap="round" />
                 </svg>
                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                   <p className="text-2xl font-bold text-white">12%</p>
                   <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Kullanıldı</p>
                 </div>
               </div>
               <div className="space-y-1">
                 <p className="text-slate-300 font-medium">Toplam Disk Kapasitesi</p>
                 <p className="text-2xl font-bold text-white">5.00 GB</p>
                 <p className="text-xs text-slate-500">Boş Alan: 4.58 GB</p>
               </div>
            </div>
          </div>

          <div className="pt-6 border-t border-white/5">
             <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">En Büyük Dizinler</h3>
             <table className="w-full text-left">
                <thead>
                   <tr className="border-b border-white/5">
                      <th className="py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Dizin</th>
                      <th className="py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Disk Boyutu</th>
                   </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                   {['/public_html/wp-content/uploads', '/public_html/assets/images', '/mail/sinan/cur', '/tmp', '/logs/apache2'].map((path) => (
                      <tr key={path} className="hover:bg-white/[0.02] transition-colors">
                         <td className="py-4 text-xs text-slate-300 font-mono">{path}</td>
                         <td className="py-4 text-xs font-bold text-indigo-400 text-right">{(Math.random() * 100 + 10).toFixed(1)} MB</td>
                      </tr>
                   ))}
                </tbody>
             </table>
          </div>
        </div>
      </div>
    );
  }

  // --- Backup View ---
  if (activeView === 'backup') {
    return (
      <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setActiveView('overview')}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Yedekleme</h1>
            <p className="text-xs text-slate-500 mt-1">Verilerinizi tam veya kısmi olarak yedekleyin</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
           {/* Full Backup */}
           <div className="bg-[#1e293b] p-10 rounded-3xl border border-white/5 shadow-2xl flex flex-col space-y-6">
              <div className="p-4 bg-indigo-500/10 rounded-2xl w-fit">
                 <Archive className="w-8 h-8 text-indigo-400" />
              </div>
              <div className="space-y-2">
                 <h2 className="text-xl font-bold text-white tracking-tight">Tam Yedekleme</h2>
                 <p className="text-sm text-slate-500 leading-relaxed">
                    Tüm dosyalarınızı, veritabanlarınızı ve email yapılandırmanızı içeren tek bir arşiv oluşturun.
                 </p>
              </div>
              <button className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-sm transition-all shadow-lg shadow-indigo-600/20 active:scale-95">
                 Tam Yedekle (Download)
              </button>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                 <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Mevcut Tam Yedekler</p>
                 <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-xs text-slate-300">backup-2024-05-01.tar.gz</span>
                    <button className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300">İndir</button>
                 </div>
              </div>
           </div>

           {/* Partial Backups */}
           <div className="bg-[#1e293b] p-10 rounded-3xl border border-white/5 shadow-2xl space-y-8">
              <h2 className="text-xl font-bold text-white tracking-tight">Kısmi Yedeklemeler (Download)</h2>
              <div className="grid gap-4">
                 {[
                   { label: 'Ev Dizini', icon: Folder },
                   { label: 'MySQL Veritabanları', icon: Zap },
                   { label: 'Email Yönlendirmeleri', icon: RefreshCcw },
                   { label: 'Email Filtreleri', icon: Search },
                 ].map((item) => (
                   <button key={item.label} className="w-full p-4 hover:bg-white/5 border border-white/5 rounded-2xl flex items-center justify-between group transition-all">
                      <div className="flex items-center gap-4">
                         <div className="p-2.5 bg-white/5 rounded-xl group-hover:bg-indigo-500 transition-all">
                            <item.icon className="w-5 h-5 text-slate-400 group-hover:text-white" />
                         </div>
                         <span className="text-sm font-bold text-slate-300 group-hover:text-white">{item.label}</span>
                      </div>
                      <Download className="w-4 h-4 text-slate-500 group-hover:text-indigo-400" />
                   </button>
                 ))}
              </div>
           </div>
        </div>
      </div>
    );
  }

  // --- Backup Wizard View ---
  if (activeView === 'wizard') {
    return (
      <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setActiveView('overview')}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Yedekleme Sihirbazı</h1>
            <p className="text-xs text-slate-500 mt-1">Yedekleme ve geri yükleme işlemlerini adım adım tamamlayın</p>
          </div>
        </div>

        <div className="bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl overflow-hidden">
          {/* Steps Indicator */}
          <div className="p-6 bg-[#0f172a]/40 border-b border-white/5 flex justify-center gap-12">
             {[
               { id: 1, label: 'Seçim' },
               { id: 2, label: 'Hangi Veri?' },
               { id: 3, label: 'İşleme Başla' }
             ].map((step, i) => (
               <div key={step.id} className="flex items-center gap-3">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all border",
                    step.id === 1 ? "bg-indigo-600 border-indigo-500 text-white" : "bg-white/5 border-white/5 text-slate-500"
                  )}>
                    {step.id}
                  </div>
                  <span className={cn("text-xs font-bold uppercase tracking-widest", step.id === 1 ? "text-indigo-400" : "text-slate-500")}>
                    {step.label}
                  </span>
                  {i < 2 && <div className="w-12 h-px bg-white/10 ml-3" />}
               </div>
             ))}
          </div>

          <div className="p-12 space-y-10 text-center">
             <div className="space-y-4 max-w-lg mx-auto">
                <h2 className="text-2xl font-bold text-white">İşlemi başatmak için bir seçenek belirleyin</h2>
                <p className="text-sm text-slate-500 leading-relaxed">
                   Site verilerinizi güvenle yedeklemek veya mevcut bir yedekten geri yüklemek için aşağıdaki butonları kullanın.
                </p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8 px-4">
                <button className="group p-8 bg-[#0f172a]/50 hover:bg-[#0f172a] border border-white/5 rounded-3xl transition-all space-y-6">
                   <div className="p-4 bg-indigo-500/10 rounded-2xl w-fit mx-auto group-hover:scale-110 transition-transform">
                      <Archive className="w-10 h-10 text-indigo-400" />
                   </div>
                   <div className="space-y-2">
                      <h3 className="text-lg font-bold text-white">Yedekle</h3>
                      <p className="text-xs text-slate-500">Kopyasını almak istediğiniz verileri seçin.</p>
                   </div>
                </button>
                <button className="group p-8 bg-[#0f172a]/50 hover:bg-[#0f172a] border border-white/5 rounded-3xl transition-all space-y-6">
                   <div className="p-4 bg-emerald-500/10 rounded-2xl w-fit mx-auto group-hover:scale-110 transition-transform">
                      <RefreshCcw className="w-10 h-10 text-emerald-400" />
                   </div>
                   <div className="space-y-2">
                      <h3 className="text-lg font-bold text-white">Geri Yükle</h3>
                      <p className="text-xs text-slate-500">Mevcut bir yedeği sisteme aktarın.</p>
                   </div>
                </button>
             </div>
          </div>
          
          <div className="p-6 bg-white/[0.02] border-t border-white/5 flex justify-between items-center">
             <p className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">Sihirbaz v2.4 (cPanel Engine)</p>
             <button disabled className="px-6 py-2 bg-white/5 text-slate-500 rounded-xl text-xs font-bold cursor-not-allowed">
                Sonraki Adım
             </button>
          </div>
        </div>
      </div>
    );
  }

  // --- Restoration View ---
  if (activeView === 'restoration') {
    return (
      <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setActiveView('overview')}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Restore (Geri Yükleme)</h1>
            <p className="text-xs text-slate-500 mt-1">Sistem tarafından otomatik alınan veya yüklediğiniz yedeklerden geri yükleyin</p>
          </div>
        </div>

        <div className="bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl overflow-hidden flex flex-col">
          <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
             <div className="flex items-center gap-3">
                <RefreshCcw className="w-5 h-5 text-indigo-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">Mevcut Geri Yükleme Noktaları</h2>
             </div>
             <button className="flex items-center gap-2 px-3 py-1.5 bg-[#0f172a] hover:bg-slate-800 border border-white/10 rounded-xl text-[10px] font-bold text-slate-400 hover:text-white transition-all">
                <RefreshCcw className="w-3 h-3" /> Listele
             </button>
          </div>
          
          <div className="p-0">
             <table className="w-full text-left">
                <thead className="bg-white/[0.02]">
                   <tr className="border-b border-white/5">
                      <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest w-[40%]">Yedekleme Tarihi</th>
                      <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest w-[20%]">Tür</th>
                      <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest w-[20%]">Boyut</th>
                      <th className="p-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Eylem</th>
                   </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                   {[
                     { date: 'Bugün 04:00', type: 'Sistem', size: '420 MB' },
                     { date: 'Dün 04:00', type: 'Sistem', size: '418 MB' },
                     { date: '07 Mayıs 2024', type: 'Manuel', size: '390 MB' },
                     { date: '01 Mayıs 2024', type: 'Sistem', size: '385 MB' },
                   ].map((restore) => (
                     <tr key={restore.date} className="hover:bg-white/[0.02] group transition-all">
                        <td className="p-6">
                           <div className="flex items-center gap-4">
                              <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/20" />
                              <span className="text-sm font-bold text-slate-200">{restore.date}</span>
                           </div>
                        </td>
                        <td className="p-6 text-xs text-slate-400">{restore.type}</td>
                        <td className="p-6 text-xs text-slate-500 font-mono">{restore.size}</td>
                        <td className="p-6 text-right">
                           <button className="px-4 py-2 bg-indigo-500/10 hover:bg-indigo-600 text-indigo-400 hover:text-white rounded-xl text-[10px] font-bold transition-all border border-indigo-500/20 group-hover:border-indigo-500">
                             Geri Yükle
                           </button>
                        </td>
                     </tr>
                   ))}
                </tbody>
             </table>
          </div>
          <div className="p-6 bg-[#0f172a]/20 border-t border-white/5 text-center">
             <p className="text-[10px] text-slate-500 font-medium">Bu işlem geri alınamaz. Lütfen işlemi başlatmadan önce emim olun.</p>
          </div>
        </div>

        <div className="bg-amber-500/5 border border-amber-500/10 p-6 rounded-3xl flex gap-6">
           <div className="p-3 bg-amber-500/10 rounded-2xl h-fit">
              <Shield className="w-6 h-6 text-amber-500" />
           </div>
           <div className="space-y-1">
              <h4 className="text-sm font-bold text-amber-400">Önemli Uyarı</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                 Geri yükleme işlemi başladığında web siteniz geçici olarak servis dışı kalabilir ve mevcut verileriniz yedeğin üzerindekilerle değiştirilir. Büyük veritabanları için işlemin bitmesi birkaç dakika sürebilir.
              </p>
           </div>
        </div>
      </div>
    );
  }

  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => 
      prev.includes(folderId) ? prev.filter(f => f !== folderId) : [...prev, folderId]
    );
  };

  const mockFiles: FileItem[] = [
    { id: '1', name: 'cgi-bin', type: 'folder', modified: '01.05.2024 14:20', permissions: '0755', owner: 'seraiph' },
    { id: '2', name: 'images', type: 'folder', modified: '02.05.2024 09:12', permissions: '0755', owner: 'seraiph' },
    { id: '3', name: 'includes', type: 'folder', modified: '01.05.2024 14:20', permissions: '0755', owner: 'seraiph' },
    { id: '4', name: 'index.php', type: 'file', size: '12.45 KB', modified: '05.05.2024 18:45', permissions: '0644', owner: 'seraiph' },
    { id: '5', name: 'config.php', type: 'file', size: '4.10 KB', modified: '05.05.2024 18:46', permissions: '0600', owner: 'seraiph' },
    { id: '6', name: '.htaccess', type: 'file', size: '0.8 KB', modified: '28.04.2024 10:00', permissions: '0644', owner: 'seraiph' },
    { id: '7', name: 'robots.txt', type: 'file', size: '1.2 KB', modified: '03.05.2024 11:30', permissions: '0644', owner: 'seraiph' },
  ];

  const toolbarActions = [
    { icon: FilePlus, label: 'Dosya', color: 'text-blue-400' },
    { icon: FolderPlus, label: 'Klasör', color: 'text-amber-400' },
    { icon: Copy, label: 'Kopyala' },
    { icon: Scissors, label: 'Taşı' },
    { icon: Upload, label: 'Yükle', color: 'text-emerald-400' },
    { icon: Download, label: 'İndir' },
    { icon: Trash2, label: 'Sil', color: 'text-rose-500' },
    { icon: Edit3, label: 'Düzenle' },
    { icon: Code, label: 'HTML Editör' },
    { icon: Shield, label: 'İzinler' },
    { icon: Archive, label: 'Sıkıştır' },
    { icon: ExternalLink, label: 'Çıkart' },
  ];

  return (
    <div className="max-w-7xl mx-auto flex flex-col h-[calc(100vh-140px)] animate-in fade-in zoom-in-95 duration-500 pb-10">
      {/* cPanel Style Toolbar */}
      <div className="bg-[#1e293b] rounded-t-3xl border border-white/10 p-3 flex flex-wrap items-center gap-1 shadow-2xl">
        <button onClick={() => setActiveView('overview')} className="p-2.5 hover:bg-white/5 text-slate-400 hover:text-white rounded-xl transition-all mr-2">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="h-8 w-px bg-white/10 mx-1" />
        
        {toolbarActions.map((action, i) => (
          <button 
            key={i}
            className={cn(
              "flex flex-col items-center gap-1.5 px-3 py-2 rounded-xl hover:bg-white/5 transition-all group",
              selectedItems.length === 0 && !['Dosya', 'Klasör', 'Yükle'].includes(action.label) ? "opacity-30 grayscale cursor-not-allowed" : "opacity-100"
            )}
          >
            <action.icon className={cn("w-4 h-4", action.color || "text-slate-300")} />
            <span className="text-[10px] font-bold text-slate-400 tracking-tight group-hover:text-white">{action.label}</span>
          </button>
        ))}

        <div className="flex-1 min-w-[150px] flex justify-end">
          <div className="relative w-full max-w-[240px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
            <input 
              type="text" 
              placeholder="Dosyalarda ara..."
              className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-2 pl-9 pr-4 text-xs text-slate-300 focus:outline-none focus:border-indigo-500/50"
            />
          </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden border-x border-white/10">
        {/* Directory Tree Sidebar */}
        <div className="w-64 bg-[#1e293b]/30 border-r border-white/10 flex flex-col hidden md:flex">
          <div className="p-4 border-bottom border-white/5">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Dizin Ağacı</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-1 custom-scrollbar">
            <div className="space-y-1">
              <button 
                onClick={() => toggleFolder('root')}
                className="w-full flex items-center gap-2 px-2 py-1.5 hover:bg-white/5 rounded-lg text-xs text-slate-300 group"
              >
                {expandedFolders.includes('root') ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                <Folder className="w-4 h-4 text-amber-400 fill-amber-400/20" />
                <span className="font-bold">/</span>
              </button>
              
              {expandedFolders.includes('root') && (
                <div className="pl-4 space-y-1 animate-in slide-in-from-left-2 duration-200">
                  {['etc', 'logs', 'mail', 'public_ftp', 'public_html', 'ssl', 'tmp'].map(dir => (
                    <div key={dir} className="space-y-1">
                      <button 
                        onClick={() => dir === 'public_html' && toggleFolder('public_html')}
                        className={cn(
                          "w-full flex items-center gap-2 px-2 py-1.5 hover:bg-white/5 rounded-lg text-xs transition-all",
                          dir === 'public_html' ? "text-indigo-400" : "text-slate-400"
                        )}
                      >
                        {dir === 'public_html' ? (expandedFolders.includes('public_html') ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />) : <div className="w-3.5" />}
                        <Folder className={cn("w-3.5 h-3.5", dir === 'public_html' ? "text-indigo-400" : "text-amber-400/60")} />
                        <span>{dir}</span>
                      </button>
                      
                      {dir === 'public_html' && expandedFolders.includes('public_html') && (
                        <div className="pl-4 space-y-1">
                          {['cgi-bin', 'css', 'images', 'js'].map(sub => (
                            <button key={sub} className="w-full flex items-center gap-2 px-2 py-1.5 hover:bg-white/5 rounded-lg text-xs text-slate-500">
                              <div className="w-3.5" />
                              <Folder className="w-3.5 h-3.5 text-amber-400/40" />
                              <span>{sub}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Main Content Pane */}
        <div className="flex-1 flex flex-col bg-[#0f172a]">
          {/* Path Header */}
          <div className="p-3 bg-[#1e293b]/20 border-b border-white/5 flex items-center gap-4">
            <button className="flex items-center gap-2 px-3 py-1.5 bg-[#0f172a] hover:bg-slate-800 border border-white/5 rounded-lg text-[10px] font-bold text-slate-400 transition-all">
              <RefreshCcw className="w-3 h-3" /> Üst Dizine Çık
            </button>
            <div className="flex-1 relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600 text-xs font-bold">Yol:</span>
              <input 
                type="text" 
                value={`/${currentPath.join('/')}`}
                readOnly
                className="w-full bg-[#0f172a]/50 border border-white/5 rounded-lg py-1.5 pl-12 pr-4 text-xs text-slate-300 font-mono"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            <table className="w-full text-left border-collapse">
              <thead className="sticky top-0 bg-[#1e293b]/80 backdrop-blur-md z-10">
                <tr className="border-b border-white/10">
                  <th className="w-12 p-3 pl-6">
                    <input 
                      type="checkbox" 
                      checked={selectedItems.length === mockFiles.length}
                      onChange={() => setSelectedItems(selectedItems.length === mockFiles.length ? [] : mockFiles.map(f => f.id))}
                      className="rounded border-white/20 bg-white/5 accent-indigo-500"
                    />
                  </th>
                  <th className="p-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">İsim</th>
                  <th className="p-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">Boyut</th>
                  <th className="p-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">Değiştirilme</th>
                  <th className="p-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">Tür</th>
                  <th className="p-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">İzinler</th>
                  <th className="w-12 p-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {mockFiles.map((file) => (
                  <tr 
                    key={file.id}
                    onClick={() => setSelectedItems(prev => prev.includes(file.id) ? prev.filter(i => i !== file.id) : [...prev, file.id])}
                    className={cn(
                      "hover:bg-white/[0.03] transition-all group cursor-pointer",
                      selectedItems.includes(file.id) && "bg-indigo-500/10"
                    )}
                  >
                    <td className="p-3 pl-6" onClick={(e) => e.stopPropagation()}>
                      <input 
                        type="checkbox" 
                        checked={selectedItems.includes(file.id)}
                        onChange={() => {}} 
                        className="rounded border-white/20 bg-white/5 accent-indigo-500"
                      />
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        {file.type === 'folder' ? (
                          <Folder className="w-4 h-4 text-amber-400 fill-amber-400/20" />
                        ) : (
                          <File className="w-4 h-4 text-slate-400" />
                        )}
                        <span className="text-[13px] text-slate-200 font-medium group-hover:text-indigo-400 transition-colors">{file.name}</span>
                      </div>
                    </td>
                    <td className="p-3 text-[11px] text-slate-500 font-mono">{file.size || '--'}</td>
                    <td className="p-3 text-[11px] text-slate-500">{file.modified}</td>
                    <td className="p-3 text-[11px] text-slate-400 capitalize">{file.type === 'folder' ? 'Dizin' : file.name.split('.').pop() + ' Dosyası'}</td>
                    <td className="p-3 text-[11px] text-indigo-400/70 font-mono">{file.permissions}</td>
                    <td className="p-3">
                      <button className="p-1.5 opacity-0 group-hover:opacity-100 hover:bg-indigo-500/10 rounded-lg text-slate-400 hover:text-indigo-400 transition-all">
                        <Edit3 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* cPanel Footer */}
      <div className="bg-[#1e293b] rounded-b-3xl border border-white/10 p-3 flex justify-between items-center shadow-xl">
        <div className="flex gap-6 items-center">
          <div className="px-3 py-1 bg-[#0f172a] rounded-lg border border-white/5 text-[10px] font-bold text-slate-400">
            {mockFiles.length} Nesne Gösteriliyor
          </div>
          {selectedItems.length > 0 && (
            <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
              {selectedItems.length} Nesne Seçildi
            </div>
          )}
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-bold uppercase tracking-widest text-[9px]">Kota Kullanımı:</span>
            <div className="w-32 h-1.5 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
              <div className="h-full bg-indigo-500 rounded-full" style={{ width: '12%' }} />
            </div>
            <span className="text-[10px] font-mono text-slate-300">12%</span>
          </div>
          <div className="h-4 w-px bg-white/10" />
          <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/5 text-emerald-400 rounded-lg border border-emerald-500/10">
            <Shield className="w-3.5 h-3.5" />
            <span className="text-[9px] font-black uppercase">AES-256 Secured</span>
          </div>
        </div>
      </div>
    </div>
  );
};
