import React, { useState } from 'react';
import { 
  ArrowLeft, HelpCircle, ExternalLink, Eye, EyeOff, 
  Wrench, ChevronDown, Info, ShieldCheck, Mail,
  Settings2, HelpCircle as HelpIcon, Trash2,
  Lock, HardDrive, Ban, FolderPlus, Save,
  RefreshCw, Smartphone, Filter, MessageSquare,
  AlertTriangle
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ManageEmailAccountProps {
  email: string;
  project: Project;
  onBack: () => void;
  onCheckEmail: () => void;
  onConnectDevices: () => void;
}

export const ManageEmailAccount: React.FC<ManageEmailAccountProps> = ({ email, project, onBack, onCheckEmail, onConnectDevices }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [storageType, setStorageType] = useState<'fixed' | 'unlimited'>('fixed');
  const [storageSize, setStorageSize] = useState('512');
  const [receiving, setReceiving] = useState<'allow' | 'suspend'>('allow');
  const [sending, setSending] = useState<'allow' | 'suspend' | 'hold'>('allow');
  const [logging, setLogging] = useState<'allow' | 'suspend'>('allow');
  const [plusAddressing, setPlusAddressing] = useState<'auto' | 'manual'>('auto');

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-6xl mx-auto pb-20">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">E-Posta Hesapları</h1>
            <div className="flex items-center gap-2 text-xs mt-1">
              <button onClick={onBack} className="text-indigo-400 hover:underline">E-posta Hesaplarını Listele</button>
              <span className="text-slate-600">/</span>
              <span className="text-slate-400">E-posta Hesabını Yönet</span>
            </div>
          </div>
        </div>
        
        <div className="bg-indigo-600/10 border border-indigo-500/20 p-4 rounded-xl flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <p className="text-xs text-slate-300 leading-relaxed">
            Bu sayfayı e-posta hesaplarınızı yönetmek için kullanın. Daha fazla bilgi edinmek ister misiniz? Belgelerimizi <a href="#" className="text-indigo-400 hover:underline inline-flex items-center gap-1">okuyun <ExternalLink className="w-3 h-3" /></a>.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Management Form */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 shadow-xl overflow-hidden">
            <div className="p-4 bg-[#0f172a]/50 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest">E-POSTA HESABINI YÖNET</h2>
              <button className="flex items-center gap-1.5 px-3 py-1 bg-[#0f172a] hover:bg-slate-800 text-[10px] font-bold text-slate-400 border border-white/5 rounded-lg transition-all">
                Yardımı Göster/Gizle <HelpCircle className="w-3 h-3" />
              </button>
            </div>

            <div className="p-8 space-y-10">
              {/* Account Info */}
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">E-posta Hesabı</label>
                <div className="flex items-center justify-between">
                  <p className="text-lg font-bold text-white">{email}</p>
                  <button 
                    onClick={onCheckEmail}
                    className="flex items-center gap-2 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" /> E-postayı Kontrol Et
                  </button>
                </div>
              </div>

              {/* Security Section */}
              <div className="space-y-6 pt-6 border-t border-white/5">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
                  <Lock className="w-4 h-4 text-indigo-400" /> GÜVENLİK
                </h3>
                <div className="space-y-4">
                  <label className="text-xs font-bold text-slate-400">Yeni Şifre</label>
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <input 
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Şifreyi Girin"
                        className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all"
                      />
                      <button 
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <div className="flex bg-[#0f172a] border border-white/5 rounded-xl overflow-hidden">
                      <button className="px-4 py-3 text-xs font-bold text-slate-400 hover:bg-slate-800 transition-all border-r border-white/5">
                        Oluştur
                      </button>
                      <button className="px-2 py-3 text-slate-500 hover:text-white transition-all">
                        <ChevronDown className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="flex gap-1 h-1">
                    <div className="flex-1 bg-slate-800 rounded-full" />
                    <div className="flex-1 bg-slate-800 rounded-full" />
                    <div className="flex-1 bg-slate-800 rounded-full" />
                    <div className="flex-1 bg-slate-800 rounded-full" />
                  </div>
                </div>
              </div>

              {/* Storage Section */}
              <div className="space-y-6 pt-6 border-t border-white/5">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
                  <HardDrive className="w-4 h-4 text-indigo-400" /> STORAGE
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-400">Current Storage Usage</span>
                    <span className="text-xs font-bold text-white">79,8 KB / 512 MB 0,02%</span>
                  </div>
                  <div className="h-2 bg-[#0f172a] rounded-full overflow-hidden border border-white/5">
                    <div className="h-full bg-indigo-500 w-[1%] shadow-[0_0_10px_rgba(99,102,241,0.5)]" />
                  </div>
                  
                  <div className="space-y-3 pt-2">
                    <label className="flex items-center gap-2 text-xs font-bold text-slate-400">
                      Allocated Storage Space <HelpCircle className="w-3 h-3 text-indigo-400 cursor-help" />
                    </label>
                    <div className="flex items-center gap-8">
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <input 
                          type="radio" 
                          name="storage" 
                          checked={storageType === 'fixed'} 
                          onChange={() => setStorageType('fixed')}
                          className="peer sr-only" 
                        />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <div className="flex items-center">
                          <input 
                            type="text" 
                            value={storageSize}
                            onChange={(e) => setStorageSize(e.target.value)}
                            disabled={storageType !== 'fixed'}
                            className="w-20 bg-[#0f172a] border border-white/5 rounded-l-lg py-1.5 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500/50 disabled:opacity-50"
                          />
                          <select className="bg-[#0f172a] border border-l-0 border-white/5 rounded-r-lg py-1.5 px-2 text-xs text-slate-400 focus:outline-none">
                            <option>MB</option>
                            <option>GB</option>
                          </select>
                        </div>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <input 
                          type="radio" 
                          name="storage" 
                          checked={storageType === 'unlimited'} 
                          onChange={() => setStorageType('unlimited')}
                          className="peer sr-only" 
                        />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">Sınırsız</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Restrictions Section */}
              <div className="space-y-6 pt-6 border-t border-white/5">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
                  <Ban className="w-4 h-4 text-indigo-400" /> RESTRICTIONS
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-400">Receiving Incoming Mail</label>
                    <div className="flex items-center gap-6">
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="receiving" checked={receiving === 'allow'} onChange={() => setReceiving('allow')} className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400">Allow</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="receiving" checked={receiving === 'suspend'} onChange={() => setReceiving('suspend')} className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400">Askıya al</span>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-400">Sending Outgoing Email</label>
                    <div className="flex items-center gap-6">
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="sending" checked={sending === 'allow'} onChange={() => setSending('allow')} className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400">Allow</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="sending" checked={sending === 'suspend'} onChange={() => setSending('suspend')} className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400">Askıya al</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="sending" checked={sending === 'hold'} onChange={() => setSending('hold')} className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400">Hold</span>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-400">Logging In</label>
                    <div className="flex items-center gap-6">
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="logging" checked={logging === 'allow'} onChange={() => setLogging('allow')} className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400">Allow</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="logging" checked={logging === 'suspend'} onChange={() => setLogging('suspend')} className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400">Askıya al</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Plus Addressing Section */}
              <div className="space-y-6 pt-6 border-t border-white/5">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
                  <FolderPlus className="w-4 h-4 text-indigo-400" /> PLUS ADDRESSING
                </h3>
                <div className="space-y-3">
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-400">
                    Automatically Create Folders for Plus Addressing <HelpCircle className="w-3 h-3 text-indigo-400 cursor-help" />
                  </label>
                  <div className="flex items-center gap-8">
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input type="radio" name="plus" checked={plusAddressing === 'auto'} onChange={() => setPlusAddressing('auto')} className="peer sr-only" />
                      <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                      <span className="text-xs text-slate-400">Automatically Create Folders</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input type="radio" name="plus" checked={plusAddressing === 'manual'} onChange={() => setPlusAddressing('manual')} className="peer sr-only" />
                      <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                      <span className="text-xs text-slate-400">Do Not Automatically Create Folders</span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="pt-8 space-y-4">
                <label className="flex items-center gap-3 cursor-pointer group">
                  <input type="checkbox" className="rounded border-white/10 bg-[#0f172a] text-indigo-600" />
                  <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors italic">Stay on this page after I click Update Email Settings.</span>
                </label>

                <div className="flex items-center justify-between pt-4">
                  <button className="flex items-center gap-2 px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-600/20">
                    <Save className="w-4 h-4" /> Update Email Settings
                  </button>
                  <button onClick={onBack} className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-300 transition-colors">
                    <ArrowLeft className="w-4 h-4" /> Geri Dön
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Delete Account Section */}
          <div className="bg-rose-500/5 rounded-2xl border border-rose-500/20 p-8 space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-rose-500/10 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-rose-500" />
              </div>
              <h3 className="text-sm font-bold text-rose-500 uppercase tracking-widest">DELETE EMAIL ACCOUNT</h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Are you sure? When you delete an email account, we permanently delete <span className="font-bold text-rose-400">all</span> of the account's data.
            </p>
            <button className="flex items-center gap-2 px-6 py-2.5 bg-transparent hover:bg-rose-500/10 text-rose-500 border border-rose-500/30 rounded-xl text-xs font-bold transition-all">
              <Trash2 className="w-4 h-4" /> Delete Email Account
            </button>
          </div>
        </div>

        {/* Sidebar Actions */}
        <div className="space-y-6">
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl space-y-6">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest">I WANT TO ...</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center gap-3 p-3 bg-[#0f172a] hover:bg-slate-800 text-xs font-bold text-slate-400 hover:text-indigo-400 border border-white/5 rounded-xl transition-all group">
                <HardDrive className="w-4 h-4 text-indigo-500 group-hover:scale-110 transition-transform" /> Free up Email Storage
              </button>
              <button className="w-full flex items-center gap-3 p-3 bg-[#0f172a] hover:bg-slate-800 text-xs font-bold text-slate-400 hover:text-indigo-400 border border-white/5 rounded-xl transition-all group">
                <Filter className="w-4 h-4 text-indigo-500 group-hover:scale-110 transition-transform" /> Manage Email Filters
              </button>
              <button className="w-full flex items-center gap-3 p-3 bg-[#0f172a] hover:bg-slate-800 text-xs font-bold text-slate-400 hover:text-indigo-400 border border-white/5 rounded-xl transition-all group">
                <MessageSquare className="w-4 h-4 text-indigo-500 group-hover:scale-110 transition-transform" /> Send Automated Responses
              </button>
            </div>
          </div>

          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl space-y-6">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest">YAPILANDIR</h3>
            <button 
              onClick={onConnectDevices}
              className="w-full flex items-center gap-3 p-3 bg-[#0f172a] hover:bg-slate-800 text-xs font-bold text-slate-400 hover:text-indigo-400 border border-white/5 rounded-xl transition-all group"
            >
              <Smartphone className="w-4 h-4 text-indigo-500 group-hover:scale-110 transition-transform" /> Connect Devices
            </button>
          </div>

          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl space-y-6">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest">NEED HELP?</h3>
            <button className="w-full flex items-center gap-3 p-3 bg-[#0f172a] hover:bg-slate-800 text-xs font-bold text-slate-400 hover:text-indigo-400 border border-white/5 rounded-xl transition-all group">
              <ExternalLink className="w-4 h-4 text-indigo-500 group-hover:scale-110 transition-transform" /> About This Interface
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
