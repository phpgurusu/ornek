import React, { useState } from 'react';
import { 
  Shield, ShieldAlert, ShieldCheck, Lock, 
  Map as MapIcon, Globe, Users, Activity, 
  FileText, Plus, Search, Trash2, Edit3, 
  ChevronRight, ArrowLeft, Zap, AlertTriangle,
  Server, Cpu, Database, Eye, EyeOff, Info,
  RefreshCcw, MessageSquare, Mail, Bell
} from 'lucide-react';
import { Project } from '../../types';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, BarChart, Bar 
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SecurityManagementProps {
  project: Project;
  onBack: () => void;
}

type SecuritySection = 'overview' | 'monitor' | 'ip' | 'waf' | 'logs' | 'notifications';

const attackData = [
  { time: '00:00', count: 12 },
  { time: '04:00', count: 8 },
  { time: '08:00', count: 45 },
  { time: '12:00', count: 120 },
  { time: '16:00', count: 85 },
  { time: '20:00', count: 210 },
  { time: '23:59', count: 65 },
];

export const SecurityManagement: React.FC<SecurityManagementProps> = ({ project, onBack }) => {
  const [activeSection, setActiveSection] = useState<SecuritySection>('overview');
  const [wafStatus, setWafStatus] = useState(true);
  const [firewallStatus, setFirewallStatus] = useState(true);

  const stats = [
    { label: 'Tehdit Skoru', value: '12', max: '100', icon: ShieldAlert, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { label: 'Engellenen İstek', value: '1.242', icon: ShieldCheck, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
    { label: 'DDoS Atağı', value: 'Yok', icon: Zap, color: 'text-slate-500', bg: 'bg-white/5' },
    { label: 'Anomali', value: '3', icon: AlertTriangle, color: 'text-amber-500', bg: 'bg-amber-500/10' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
      {/* Header */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={activeSection === 'overview' ? onBack : () => setActiveSection('overview')}
              className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
                Siber Güvenlik Merkezi
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] uppercase tracking-widest rounded border border-emerald-500/20">
                  Korumalı
                </span>
              </h1>
              <p className="text-xs text-slate-500 mt-1">Gelişmiş tehdit algılama ve gerçek zamanlı savunma paneli</p>
            </div>
          </div>
        </div>

        <div className="flex bg-[#1e293b] rounded-2xl border border-white/5 p-1 w-fit overflow-x-auto max-w-full custom-scrollbar">
          {[
            { id: 'overview', label: 'Genel Durum', icon: Shield },
            { id: 'monitor', label: 'Saldırı Monitörü', icon: Activity },
            { id: 'ip', label: 'IP Yönetimi', icon: Globe },
            { id: 'waf', label: 'WAF Kuralları', icon: Server },
            { id: 'logs', label: 'Loglar', icon: FileText },
            { id: 'notifications', label: 'Bildirimler', icon: Bell },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id as SecuritySection)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap",
                activeSection === item.id 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
              )}
            >
              <item.icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {activeSection === 'overview' && (
        <>
          {/* Main Status Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div key={i} className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                   <div className={cn("p-2 rounded-xl border border-white/5", stat.bg)}>
                      <stat.icon className={cn("w-5 h-5", stat.color)} />
                   </div>
                   {stat.max && (
                     <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Skor</span>
                   )}
                </div>
                <div className="space-y-1">
                  <p className="text-2xl font-black text-white">{stat.value}{stat.max && <span className="text-sm text-slate-500">/{stat.max}</span>}</p>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* System Switches */}
            <div className="lg:col-span-1 space-y-6">
               <div className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl space-y-6">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Temel Güvenlik</h3>
                  <div className="space-y-6">
                     <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                           <div className={cn("w-2 h-2 rounded-full", wafStatus ? "bg-emerald-500" : "bg-slate-600")} />
                           <span className="text-sm font-bold text-slate-200">WAF Durumu</span>
                        </div>
                        <button 
                          onClick={() => setWafStatus(!wafStatus)}
                          className={cn(
                            "w-12 h-6 rounded-full relative transition-all duration-300",
                            wafStatus ? "bg-indigo-600" : "bg-slate-700"
                          )}
                        >
                          <div className={cn(
                            "absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300",
                            wafStatus ? "left-7" : "left-1"
                          )} />
                        </button>
                     </div>
                     <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                           <div className={cn("w-2 h-2 rounded-full", firewallStatus ? "bg-emerald-500" : "bg-slate-600")} />
                           <span className="text-sm font-bold text-slate-200">Firewall</span>
                        </div>
                        <button 
                          onClick={() => setFirewallStatus(!firewallStatus)}
                          className={cn(
                            "w-12 h-6 rounded-full relative transition-all duration-300",
                            firewallStatus ? "bg-indigo-600" : "bg-slate-700"
                          )}
                        >
                          <div className={cn(
                            "absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300",
                            firewallStatus ? "left-7" : "left-1"
                          )} />
                        </button>
                     </div>
                     <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                           <div className="w-2 h-2 rounded-full bg-emerald-500" />
                           <span className="text-sm font-bold text-slate-200">SSL Durumu</span>
                        </div>
                        <div className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-black uppercase rounded border border-emerald-500/20">
                           Valid
                        </div>
                     </div>
                  </div>
               </div>
               
               <div className="bg-[#1e293b]/50 p-6 rounded-3xl border border-white/5 space-y-4">
                  <div className="flex items-center gap-3 text-amber-500">
                     <AlertTriangle className="w-5 h-5" />
                     <h3 className="text-xs font-bold uppercase tracking-widest">Son Kritik Olay</h3>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed italic">
                    "SQL Injection girişimi engellendi. IP: 192.168.1.1 (Rusya) - Bugün 14:22"
                  </p>
               </div>
            </div>

            {/* Attack Graph Early Preview */}
            <div className="lg:col-span-2 bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl flex flex-col">
               <div className="flex items-center justify-between mb-8 px-2">
                  <div className="space-y-1">
                     <h3 className="text-sm font-bold text-white uppercase tracking-wider">Son 24 Saat Saldırı Grafiği</h3>
                     <p className="text-[10px] text-slate-500 font-medium">Tespit edilen ve engellenen tehditlerin zaman aşımı</p>
                  </div>
                  <div className="flex gap-2">
                     <button className="px-3 py-1 bg-[#0f172a] text-[10px] font-bold text-slate-400 rounded-lg border border-white/5">Gündüz</button>
                     <button className="px-3 py-1 bg-indigo-600 text-[10px] font-bold text-white rounded-lg shadow-lg shadow-indigo-600/20">Gece</button>
                  </div>
               </div>
               <div className="flex-1 h-[240px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={attackData}>
                      <defs>
                        <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                      <XAxis dataKey="time" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '12px' }}
                        itemStyle={{ color: '#fff', fontSize: '10px' }}
                      />
                      <Area type="monotone" dataKey="count" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorCount)" />
                    </AreaChart>
                  </ResponsiveContainer>
               </div>
            </div>
          </div>
        </>
      )}

      {activeSection === 'monitor' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Live Attack Map Placeholder */}
              <div className="lg:col-span-2 bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-2xl relative overflow-hidden min-h-[400px]">
                 <div className="absolute inset-0 opacity-20 pointer-events-none">
                    <Globe className="w-full h-full text-indigo-500 scale-150" />
                 </div>
                 <div className="relative z-10 space-y-8">
                    <div className="flex items-center justify-between">
                       <h3 className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-3">
                          <Activity className="w-5 h-5 text-indigo-400 animate-pulse" />
                          Anlık Saldırı Haritası
                       </h3>
                       <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
                             <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                             <span className="text-[10px] font-black uppercase">Canlı</span>
                          </div>
                       </div>
                    </div>
                    {/* Simulated points / connections could go here */}
                    <div className="grid place-content-center h-[300px]">
                       <div className="text-center space-y-4">
                          <div className="relative">
                             <div className="w-24 h-24 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin mx-auto" />
                             <MapIcon className="absolute inset-0 w-8 h-8 text-indigo-400 m-auto" />
                          </div>
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Global Tehdit Verileri taranıyor...</p>
                       </div>
                    </div>
                 </div>
              </div>

              {/* Blocked IPs List */}
              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-2xl space-y-6">
                 <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white uppercase tracking-widest">Engellenen IP Listesi</h3>
                    <button className="text-[10px] font-bold text-rose-500 hover:text-rose-400 transition-colors uppercase">Hepsini Kaldır</button>
                 </div>
                 <div className="space-y-3">
                    {[
                      { ip: '192.168.1.45', country: 'RU', risk: 'High' },
                      { ip: '45.12.8.99', country: 'CN', risk: 'Critical' },
                      { ip: '102.44.11.2', country: 'NL', risk: 'Medium' },
                      { ip: '185.11.0.3', country: 'UA', risk: 'High' },
                      { ip: '91.88.7.4', country: 'US', risk: 'Low' },
                    ].map((block) => (
                      <div key={block.ip} className="flex items-center justify-between p-3 bg-[#0f172a]/50 rounded-2xl border border-white/5 group hover:border-rose-500/30 transition-all">
                        <div className="flex items-center gap-3">
                           <div className="w-8 h-6 bg-white/5 rounded flex items-center justify-center text-[10px] font-bold text-slate-400">{block.country}</div>
                           <div className="space-y-0.5">
                              <p className="text-xs font-mono text-slate-300 font-bold tracking-tight">{block.ip}</p>
                              <p className={cn(
                                "text-[9px] font-black uppercase tracking-widest",
                                block.risk === 'Critical' ? "text-rose-500" : block.risk === 'High' ? "text-orange-500" : "text-amber-500"
                              )}>{block.risk} Risk</p>
                           </div>
                        </div>
                        <button className="p-2 opacity-0 group-hover:opacity-100 hover:bg-white/10 rounded-lg text-slate-500 transition-all">
                           <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeSection === 'ip' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="flex gap-4">
              <button className="flex-1 p-8 bg-[#1e293b] rounded-3xl border border-white/5 shadow-xl hover:bg-slate-800 transition-all group flex items-start gap-6">
                 <div className="p-4 bg-rose-500/10 rounded-2xl group-hover:bg-rose-500 group-hover:text-white transition-all">
                    <ShieldAlert className="w-8 h-8 text-rose-500 group-hover:text-white" />
                 </div>
                 <div className="space-y-1 text-left">
                    <h4 className="text-lg font-bold text-white">Kara Liste (Blacklist)</h4>
                    <p className="text-xs text-slate-500">Belirli IP veya IP bloklarının erişimini sonsuza kadar engelleyin.</p>
                 </div>
              </button>
              <button className="flex-1 p-8 bg-[#1e293b] rounded-3xl border border-white/5 shadow-xl hover:bg-slate-800 transition-all group flex items-start gap-6">
                 <div className="p-4 bg-emerald-500/10 rounded-2xl group-hover:bg-emerald-500 group-hover:text-white transition-all">
                    <ShieldCheck className="w-8 h-8 text-emerald-500 group-hover:text-white" />
                 </div>
                 <div className="space-y-1 text-left">
                    <h4 className="text-lg font-bold text-white">Beyaz Liste (Whitelist)</h4>
                    <p className="text-xs text-slate-500">Güvenilir IP adreslerine limit ve kontrolden muaf erişim sağlayın.</p>
                 </div>
              </button>
           </div>

           <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-2xl">
              <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
                 <h3 className="text-sm font-bold text-white uppercase tracking-widest">Gelişmiş Filtreleme Kuralları</h3>
                 <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10px] font-bold transition-all shadow-lg shadow-indigo-600/20 flex items-center gap-2">
                    <Plus className="w-3 h-3" /> Kural Ekle
                 </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/5">
                 {[
                   { title: 'Ülke Bazlı Engelleme', desc: 'Sadece Türkiye dışındaki tüm trafiği engelle', icon: Globe, status: 'Aktif' },
                   { title: 'Rate Limiting', desc: 'Aynı IP\'den saniyede max 20 istek', icon: Zap, status: 'Aktif' },
                   { title: 'User-Agent Filtresi', desc: 'Bilinmeyen botları ve kazıyıcıları engelle', icon: Users, status: 'Aktif' },
                   { title: 'Referrer Kontrolü', desc: 'Başka sitelerden dosya çalınmasını önle', icon: ExternalLink, status: 'Pasif' },
                 ].map((rule) => (
                   <div key={rule.title} className="p-8 bg-[#1e293b] flex items-center justify-between group">
                      <div className="flex items-center gap-6">
                         <div className="p-3 bg-[#0f172a] rounded-2xl border border-white/5 group-hover:bg-indigo-500/10 transition-all">
                            <rule.icon className="w-6 h-6 text-indigo-400" />
                         </div>
                         <div className="space-y-1">
                            <h5 className="font-bold text-slate-200">{rule.title}</h5>
                            <p className="text-xs text-slate-500">{rule.desc}</p>
                         </div>
                      </div>
                      <div className={cn(
                        "px-3 py-1 rounded-lg text-[10px] font-black uppercase border",
                        rule.status === 'Aktif' ? "text-emerald-400 border-emerald-500/20 bg-emerald-500/10" : "text-slate-500 border-white/5 bg-white/5"
                      )}>
                         {rule.status}
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {activeSection === 'waf' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl p-8 space-y-8">
              <div className="flex items-center justify-between">
                 <div>
                    <h3 className="text-lg font-bold text-white tracking-tight">WAF (Web Application Firewall) Kuralları</h3>
                    <p className="text-xs text-slate-500 mt-1">Uygulama katmanındaki saldırıları otomatik engelleyin</p>
                 </div>
                 <button className="px-6 py-2.5 bg-[#0f172a] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/10 text-xs font-bold transition-all flex items-center gap-2">
                    <Edit3 className="w-4 h-4" /> Özel Kural Yaz
                 </button>
              </div>

              <div className="space-y-4">
                 {[
                   { name: 'SQL Injection Koruması', desc: 'POST/GET parametrelerindeki SQL anahtar kelimelerini filtrele', severity: 'Critical' },
                   { name: 'XSS (Cross-Site Scripting)', desc: 'İstemci tarafı script enjeksiyonlarını engelle', severity: 'High' },
                   { name: 'CSRF Protection Header', desc: 'Sahte istekleri önlemek için header kontrolü yapar', severity: 'Medium' },
                   { name: 'Local File Inclusion (LFI)', desc: 'Sistem dosyalarına erişim denemelerini tespit et', severity: 'Critical' },
                   { name: 'WP-Security Hardening', desc: 'WordPress spesifik saldırı vektörlerini kapat', severity: 'Low' },
                 ].map((rule) => (
                   <div key={rule.name} className="flex items-center justify-between p-6 bg-[#0f172a]/50 rounded-3xl border border-white/5 group hover:bg-[#0f172a] transition-all">
                      <div className="flex items-center gap-6">
                         <div className={cn(
                           "p-4 rounded-2xl border",
                           rule.severity === 'Critical' ? "bg-rose-500/10 border-rose-500/20" : rule.severity === 'High' ? "bg-orange-500/10 border-orange-500/20" : "bg-indigo-500/10 border-indigo-500/20"
                         )}>
                            <Shield className={cn(
                              "w-6 h-6",
                              rule.severity === 'Critical' ? "text-rose-500" : rule.severity === 'High' ? "text-orange-500" : "text-indigo-400"
                            )} />
                         </div>
                         <div className="space-y-1">
                            <h5 className="font-bold text-slate-200 group-hover:text-white transition-colors">{rule.name}</h5>
                            <p className="text-xs text-slate-500">{rule.desc}</p>
                         </div>
                      </div>
                      <div className="flex items-center gap-6">
                         <div className="text-right">
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Önem</p>
                            <p className={cn(
                              "text-sm font-bold uppercase",
                              rule.severity === 'Critical' ? "text-rose-500" : rule.severity === 'High' ? "text-orange-500" : "text-indigo-400"
                            )}>{rule.severity}</p>
                         </div>
                         <button className="px-6 py-2 bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">
                            Aktif
                         </button>
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {activeSection === 'logs' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="bg-[#1e293b] rounded-3xl border border-white/5 overflow-hidden shadow-2xl flex flex-col">
              <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
                 <div className="flex items-center gap-4">
                    <h3 className="text-sm font-bold text-white uppercase tracking-widest">Güvenlik Logları</h3>
                    <div className="flex bg-[#0f172a] rounded-lg border border-white/5 p-1">
                       <button className="px-3 py-1 bg-white/5 text-white rounded-md text-[10px] font-bold">Tümü</button>
                       <button className="px-3 py-1 text-slate-500 text-[10px] font-bold hover:text-slate-300">Sadece Hatalar</button>
                    </div>
                 </div>
                 <div className="flex gap-2">
                    <button className="p-2 text-slate-500 hover:text-white hover:bg-white/5 rounded-xl transition-all">
                       <Search className="w-4 h-4" />
                    </button>
                    <button className="px-4 py-2 bg-indigo-600/10 text-indigo-400 rounded-xl text-[10px] font-bold border border-indigo-500/20 transition-all flex items-center gap-2">
                       <RefreshCcw className="w-3 h-3" /> Yenile
                    </button>
                 </div>
              </div>

              <div className="divide-y divide-white/5 max-h-[600px] overflow-y-auto custom-scrollbar">
                 {[
                   { type: 'SQL_INJECTION', ip: '45.88.22.11', time: 'Bugün 14:22', status: 'Blocked', icon: ShieldAlert, color: 'text-rose-500' },
                   { type: 'FAILED_LOGIN', ip: '185.22.0.4', time: 'Bugün 14:15', status: 'Denied', icon: Lock, color: 'text-amber-500' },
                   { type: 'BRUTE_FORCE', ip: '185.22.0.4', time: 'Bugün 14:12', status: 'Blocked', icon: Zap, color: 'text-rose-500' },
                   { type: 'WP_LOGIN_ATTEMPT', ip: '91.8.7.2', time: 'Bugün 13:45', status: 'Filtered', icon: Users, color: 'text-indigo-400' },
                   { type: 'SUSPICIOUS_PAYLOAD', ip: '12.44.8.9', time: 'Dün 22:10', status: 'Logged', icon: Info, color: 'text-slate-500' },
                   { type: 'COUNTRY_BLOCK', ip: '109.11.22.33', time: 'Dün 18:30', status: 'Blocked', icon: Globe, color: 'text-rose-500' },
                 ].map((log, i) => (
                   <div key={i} className="p-4 hover:bg-white/[0.02] flex items-center justify-between group transition-all">
                      <div className="flex items-center gap-6">
                         <div className={cn("p-2.5 rounded-xl border border-white/5 bg-[#0f172a]", log.color === 'text-rose-500' ? "bg-rose-500/5 border-rose-500/10" : "")}>
                            <log.icon className={cn("w-5 h-5", log.color)} />
                         </div>
                         <div className="space-y-1">
                            <h6 className="text-[11px] font-black text-white tracking-widest uppercase">{log.type}</h6>
                            <div className="flex items-center gap-3 text-[10px] font-medium text-slate-500">
                               <span className="font-mono text-slate-300">{log.ip}</span>
                               <span className="w-1 h-1 rounded-full bg-white/10" />
                               <span>{log.time}</span>
                            </div>
                         </div>
                      </div>
                      <div className="flex items-center gap-8">
                         <span className={cn(
                           "text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border",
                           log.status === 'Blocked' ? "text-rose-500 border-rose-500/20 bg-rose-500/5" : "text-slate-500 border-white/5 bg-white/5"
                         )}>{log.status}</span>
                         <button className="p-2 opacity-0 group-hover:opacity-100 hover:bg-white/5 rounded-xl text-slate-500 transition-all">
                            <ChevronRight className="w-4 h-4" />
                         </button>
                      </div>
                   </div>
                 ))}
              </div>

              <div className="p-6 bg-[#0f172a]/20 border-t border-white/5 flex justify-between items-center">
                 <p className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">Son 48 saatlik log verisi gösteriliyor</p>
                 <button className="px-6 py-2 bg-indigo-600/10 text-indigo-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-indigo-500/20 hover:bg-indigo-600 hover:text-white transition-all shadow-lg active:scale-95">
                    Raporu Dışa Aktar (.PDF)
                 </button>
              </div>
           </div>
        </div>
      )}
      {activeSection === 'notifications' && (
        <div className="space-y-8 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Email Notifications */}
              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-2xl space-y-8">
                 <div className="flex items-center gap-4">
                    <div className="p-4 bg-indigo-600/10 rounded-2xl border border-indigo-500/20">
                       <Mail className="w-8 h-8 text-indigo-400" />
                    </div>
                    <div>
                       <h3 className="text-lg font-bold text-white tracking-tight">E-posta Bildirimleri</h3>
                       <p className="text-xs text-slate-500 mt-1">Önemli olayları e-posta ile alın</p>
                    </div>
                 </div>

                 <div className="space-y-6">
                    {[
                      { id: 'email-critical', label: 'Kritik Tehditler', desc: 'Sisteme yönelik kritik saldırı ve DDoS tespitleri', default: true },
                      { id: 'email-login', label: 'Yeni Giriş Bildirimi', desc: 'Yeni bir IP adresinden yapılan başarılı girişler', default: false },
                      { id: 'email-waf', label: 'WAF Engellemeleri', desc: 'Günlük WAF engelleme raporu', default: true },
                    ].map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5 group hover:border-indigo-500/30 transition-all">
                         <div className="space-y-1">
                            <p className="text-sm font-bold text-slate-200">{item.label}</p>
                            <p className="text-[10px] text-slate-500">{item.desc}</p>
                         </div>
                         <button 
                           className={cn(
                             "w-12 h-6 rounded-full relative transition-all duration-300",
                             item.default ? "bg-indigo-600" : "bg-slate-700"
                           )}
                         >
                           <div className={cn(
                             "absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300",
                             item.default ? "left-7" : "left-1"
                           )} />
                         </button>
                      </div>
                    ))}
                 </div>

                 <div className="pt-6 border-t border-white/5 space-y-4">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Bildirim Gönderilecek Adres</label>
                    <div className="relative group">
                       <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                       <input 
                         type="email" 
                         placeholder="admin@example.com"
                         className="w-full bg-[#0f172a] border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all"
                         defaultValue={project.url.includes('seraiph') ? 'admin@seraiph.net' : 'admin@domain.com'}
                       />
                    </div>
                 </div>
              </div>

              {/* SMS Notifications */}
              <div className="bg-[#1e293b] p-8 rounded-3xl border border-white/5 shadow-2xl space-y-8">
                 <div className="flex items-center gap-4">
                    <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                       <MessageSquare className="w-8 h-8 text-emerald-400" />
                    </div>
                    <div>
                       <h3 className="text-lg font-bold text-white tracking-tight">SMS Bildirimleri</h3>
                       <p className="text-xs text-slate-500 mt-1">Anlık uyarıları cebinize alın</p>
                    </div>
                 </div>

                 <div className="space-y-6">
                    {[
                      { id: 'sms-ddos', label: 'DDoS Atağı Uyarısı', desc: 'Yüksek trafik ve DDoS tespiti durumunda SMS', default: true },
                      { id: 'sms-server', label: 'Sunucu Kapalılık', desc: 'Sunucunun erişilemez olduğu durumlarda bildirim', default: true },
                      { id: 'sms-brute', label: 'Brute Force Saldırısı', desc: 'Sürekli başarısız giriş denemelerinde uyarı', default: false },
                    ].map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5 group hover:border-emerald-500/30 transition-all">
                         <div className="space-y-1">
                            <p className="text-sm font-bold text-slate-200">{item.label}</p>
                            <p className="text-[10px] text-slate-500">{item.desc}</p>
                         </div>
                         <button 
                           className={cn(
                             "w-12 h-6 rounded-full relative transition-all duration-300",
                             item.default ? "bg-emerald-500" : "bg-slate-700"
                           )}
                         >
                           <div className={cn(
                             "absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300",
                             item.default ? "left-7" : "left-1"
                           )} />
                         </button>
                      </div>
                    ))}
                 </div>

                 <div className="pt-6 border-t border-white/5 space-y-4">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Telefon Numarası</label>
                    <div className="relative group">
                       <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pr-3 border-r border-white/10">
                          <span className="text-[10px] font-black text-slate-400">+90</span>
                       </div>
                       <input 
                         type="tel" 
                         placeholder="5XX XXX XX XX"
                         className="w-full bg-[#0f172a] border border-white/5 rounded-2xl py-4 pl-16 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500/50 transition-all"
                       />
                    </div>
                    <p className="text-[9px] text-slate-500 px-1">* SMS bildirimleri operatör tarifenize göre ek ücrete tabi olabilir.</p>
                 </div>
              </div>
           </div>

           <div className="flex justify-end">
              <button className="px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold shadow-xl shadow-indigo-600/20 active:scale-95 transition-all">
                 Bildirim Ayarlarını Kaydet
              </button>
           </div>
        </div>
      )}
    </div>
  );
};
function ExternalLink(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M15 3h6v6" />
      <path d="M10 14 21 3" />
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
    </svg>
  )
}
