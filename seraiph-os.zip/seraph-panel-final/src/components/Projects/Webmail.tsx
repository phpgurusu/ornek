import React, { useState } from 'react';
import { 
  ArrowLeft, Mail, Settings, Shield, Globe, 
  ExternalLink, Smartphone, Clock, CheckCircle2,
  AlertCircle, ChevronRight, Layout, Inbox,
  Send, Trash, Archive, Star, AlertTriangle,
  MessageSquare, Filter, ArrowRight, Lock, 
  User, ShieldAlert, UserCheck, HardDrive, Activity,
  ChevronDown
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface WebmailProps {
  email: string;
  project: Project;
  onBack: () => void;
  onOpenMail: () => void;
  onConnectDevices: () => void;
}

export const Webmail: React.FC<WebmailProps> = ({ email, project, onBack, onOpenMail, onConnectDevices }) => {
  const [autoOpen, setAutoOpen] = useState(true);

  const sections = [
    {
      title: 'Manage Your Inbox',
      modules: [
        { title: 'Autoreponders', desc: 'Are you going on vacation? Use this feature to configure your automated emails.', icon: MessageSquare, color: 'text-blue-400' },
        { title: 'Email Filters', desc: 'Create and manage email filters for your main email account.', icon: Filter, color: 'text-indigo-400' },
        { title: 'Forwarders', desc: 'Automatically send a copy of any incoming email from this email address to another.', icon: ArrowRight, color: 'text-orange-400' },
      ]
    },
    {
      title: 'Edit Your Settings',
      modules: [
        { title: 'Password & Security', desc: 'Update your webmail password.', icon: Lock, color: 'text-slate-400' },
        { title: 'Contact Information', desc: 'Set up a different email address to receive account notifications.', icon: User, color: 'text-blue-500' },
        { title: 'Account Preferences', desc: 'Change your Webmail account settings.', icon: Settings, color: 'text-indigo-500' },
      ]
    },
    {
      title: 'Fight Spam',
      modules: [
        { title: 'Spam Filters', desc: 'Filter unwanted spam email before it reaches your inbox.', icon: ShieldAlert, color: 'text-red-400' },
        { title: 'BoxTrapper', desc: 'Protect your inbox from spam.', icon: UserCheck, color: 'text-blue-600' },
      ]
    },
    {
      title: 'Other Webmail Features',
      modules: [
        { title: 'Configure Mail Client', desc: 'Set up your email account on any device.', icon: Smartphone, color: 'text-emerald-400', onClick: onConnectDevices },
        { title: 'Manage Disk Usage', desc: 'Delete old messages from your mailbox. Recover disk space.', icon: HardDrive, color: 'text-amber-400' },
        { title: 'Track Delivery', desc: 'Review an email\'s delivery route.', icon: Activity, color: 'text-rose-400' },
      ]
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-6xl mx-auto pb-20">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">Webmail</h1>
            <p className="text-xs text-slate-500 mt-1">{email}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-[10px] font-bold uppercase tracking-wider flex items-center gap-2">
            <Shield className="w-3 h-3" /> Güvenli Bağlantı
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Selection Area */}
        <div className="lg:col-span-2 space-y-8">
          {/* Seraiph Mail Hero */}
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl overflow-hidden">
            <div className="p-8 space-y-8">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-xl shadow-indigo-600/20">
                    <Mail className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Seraiph Mail</h2>
                    <p className="text-xs text-slate-500">Modern, hızlı ve güvenli webmail istemcisi</p>
                  </div>
                </div>
                <button 
                  onClick={onOpenMail}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-600/20 flex items-center gap-2"
                >
                  Aç <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 bg-[#0f172a]/50 rounded-2xl border border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                    <Clock className="w-4 h-4 text-indigo-400" />
                  </div>
                  <span className="text-xs text-slate-300">Giriş yaptığımda gelen kutumu otomatik olarak aç</span>
                </div>
                <button 
                  onClick={() => setAutoOpen(!autoOpen)}
                  className={cn(
                    "w-12 h-6 rounded-full transition-all relative",
                    autoOpen ? "bg-indigo-600" : "bg-slate-700"
                  )}
                >
                  <div className={cn(
                    "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                    autoOpen ? "right-1" : "left-1"
                  )} />
                </button>
              </div>
            </div>
          </div>

          {/* Modules Grid */}
          <div className="space-y-10">
            {sections.map((section, i) => (
              <div key={i} className="space-y-4">
                <h3 className="text-sm font-bold text-white/70 uppercase tracking-widest pl-2 border-l-2 border-indigo-500">
                  {section.title}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {section.modules.map((module, j) => (
                    <button 
                      key={j}
                      onClick={module.onClick}
                      className="bg-[#1e293b] p-5 rounded-2xl border border-white/5 hover:border-indigo-500/30 transition-all group text-left flex gap-4 shadow-lg"
                    >
                      <div className={cn(
                        "p-3 rounded-xl bg-[#0f172a] border border-white/5 h-fit shrink-0",
                        module.color
                      )}>
                        <module.icon className="w-5 h-5" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors">{module.title}</h4>
                        <p className="text-[11px] text-slate-500 leading-relaxed">{module.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <div className="bg-[#1e293b] rounded-3xl border border-white/5 p-6 shadow-xl space-y-6 sticky top-24">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest">HESAP ÖZETİ</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">Depolama</span>
                <span className="text-xs font-bold text-white">79.8 KB / 512 MB</span>
              </div>
              <div className="h-1.5 bg-[#0f172a] rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-[1%]" />
              </div>
              <div className="pt-4 space-y-3">
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold uppercase tracking-widest">
                  <span>Son Giriş</span>
                  <span className="text-slate-400">Bugün, 10:30</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold uppercase tracking-widest">
                  <span>IP Adresi</span>
                  <span className="text-slate-400">192.168.1.1</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-white/5">
              <div className="bg-indigo-600/10 border border-indigo-500/20 rounded-2xl p-5 space-y-4">
                <div className="w-10 h-10 bg-indigo-500/20 rounded-xl flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-indigo-400" />
                </div>
                <h3 className="text-sm font-bold text-white">Mobil Cihaz Bağla</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  E-postalarınızı telefonunuzda kontrol etmek için QR kodu tarayın veya ayarları e-posta ile gönderin.
                </p>
                <button className="w-full py-2.5 bg-[#0f172a] hover:bg-slate-800 text-xs font-bold text-white rounded-xl border border-white/5 transition-all">
                  Talimatları Gönder
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
