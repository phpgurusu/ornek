import React, { useState } from 'react';
import { 
  ArrowLeft, Smartphone, Mail, Globe, Shield, 
  ChevronDown, ChevronUp, Send, Info, ExternalLink,
  CheckCircle2, Monitor, Laptop, Tablet, Apple,
  Zap, Settings
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ConnectDevicesProps {
  email: string;
  project: Project;
  onBack: () => void;
}

export const ConnectDevices: React.FC<ConnectDevicesProps> = ({ email, project, onBack }) => {
  const [showNonSSL, setShowNonSSL] = useState(false);
  const [instructionEmail, setInstructionEmail] = useState('');

  const autoScripts = [
    { 
      app: 'Windows Live Mail®', 
      protocols: [
        { name: 'SSL/TLS üzerinden IMAP', link: '#' },
        { name: 'SSL/TLS üzerinden POP3', link: '#' },
        { name: 'IMAP', link: '#' },
        { name: 'POP3 (Postane İletişim Kuralı v3)', link: '#' }
      ]
    },
    { 
      app: 'iOS for iPhone/iPad/iPod and MacOS® Mail.app®', 
      protocols: [
        { name: 'SSL/TLS üzerinden IMAP', link: '#' },
        { name: 'IMAP', link: '#' }
      ]
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto pb-20">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={onBack}
          className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-white">“{email}” İçin Posta İstemcisi Kurun</h1>
          <p className="text-xs text-slate-500 mt-1">Cihazlarınızı e-posta hesabınıza bağlayın</p>
        </div>
      </div>

      <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl">
        <div className="flex gap-4 items-start">
          <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 shrink-0">
            <Info className="w-6 h-6 text-indigo-400" />
          </div>
          <p className="text-sm text-slate-300 leading-relaxed">
            “iOS for iPhone/iPad/iPod and MacOS® Mail.app®” gibi bir masaüstü e-posta uygulamasından bir e-posta hesabına erişirken, e-mail uygulaması posta hesabınız hakkında özel bilgiler gerektirecektir. E-posta yapılandırmanızın otomatik yapılandırılmasını denemek için aşağıdaki otomatik yapılandırma seçeneklerini kullanabilirsiniz. Mevcut seçenekler uygulamanız ile uyumlu değilse <span className="font-bold text-indigo-400">Elle Ayarlar</span> bilgilerini kullanmanız gerekecektir.
          </p>
        </div>
      </div>

      {/* Automatic Configuration */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-400" /> Mail Client Automatic Configuration Scripts
        </h2>
        <p className="text-xs text-slate-500">Listed below are the available mail client automatic configuration scripts. Select the script for your mail client and operating system.</p>
        
        <div className="bg-[#1e293b] rounded-2xl border border-white/5 overflow-hidden shadow-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#0f172a]/50 border-b border-white/5">
                <th className="px-6 py-4 text-[11px] font-bold text-slate-500 uppercase tracking-widest">Uygulama</th>
                <th className="px-6 py-4 text-[11px] font-bold text-slate-500 uppercase tracking-widest">Protokoller</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {autoScripts.map((script, i) => (
                <tr key={i} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {script.app.includes('iOS') ? <Apple className="w-4 h-4 text-slate-400" /> : <Monitor className="w-4 h-4 text-slate-400" />}
                      <span className="text-sm font-medium text-slate-200">{script.app}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-x-4 gap-y-2">
                      {script.protocols.map((proto, j) => (
                        <a 
                          key={j} 
                          href={proto.link}
                          className="text-xs font-bold text-indigo-400 hover:text-indigo-300 hover:underline transition-colors"
                        >
                          {proto.name}
                        </a>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Settings */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-indigo-400" /> Mail Client Manual Settings
        </h2>
        <p className="text-xs text-slate-500">If you do not see an auto-configuration script for your client in the list above, you can manually configure your mail client using the settings below. We recommend that you use <span className="font-bold text-slate-300">IMAP</span> and <span className="font-bold text-slate-300">SMTP</span> for your email account rather than ActiveSync unless you are on Android and need calendar and contacts support or push updates.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* SSL/TLS Settings */}
          <div className="bg-[#1e293b] rounded-2xl border border-indigo-500/30 overflow-hidden shadow-2xl shadow-indigo-500/5">
            <div className="px-6 py-4 bg-indigo-600 flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Shield className="w-4 h-4" /> Secure SSL/TLS Settings (Önerilir)
              </h3>
            </div>
            <div className="p-0">
              <div className="grid grid-cols-3 border-b border-white/5">
                <div className="px-6 py-4 bg-[#0f172a]/30 text-xs font-bold text-slate-500 border-r border-white/5">Kullanıcı adı:</div>
                <div className="px-6 py-4 col-span-2 text-sm text-slate-200 font-mono">{email}</div>
              </div>
              <div className="grid grid-cols-3 border-b border-white/5">
                <div className="px-6 py-4 bg-[#0f172a]/30 text-xs font-bold text-slate-500 border-r border-white/5">Şifre:</div>
                <div className="px-6 py-4 col-span-2 text-sm text-slate-400 italic">E-posta hesabının şifresini kullanın.</div>
              </div>
              <div className="grid grid-cols-3 border-b border-white/5">
                <div className="px-6 py-4 bg-[#0f172a]/30 text-xs font-bold text-slate-500 border-r border-white/5">Gelen Posta Sunucusu:</div>
                <div className="px-6 py-4 col-span-2 space-y-1">
                  <p className="text-sm text-slate-200 font-mono">cp13.servername.co</p>
                  <div className="flex gap-4 text-[10px] font-bold">
                    <span className="text-indigo-400 uppercase">IMAP Port: 993</span>
                    <span className="text-emerald-400 uppercase">POP3 Port: 995</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 border-b border-white/5">
                <div className="px-6 py-4 bg-[#0f172a]/30 text-xs font-bold text-slate-500 border-r border-white/5">Giden Sunucu:</div>
                <div className="px-6 py-4 col-span-2 space-y-1">
                  <p className="text-sm text-slate-200 font-mono">cp13.servername.co</p>
                  <p className="text-[10px] font-bold text-indigo-400 uppercase">SMTP Port: 465</p>
                </div>
              </div>
              <div className="px-6 py-4 bg-[#0f172a]/10">
                <p className="text-[10px] text-slate-500 italic">IMAP, POP3 ve SMTP requires authentication.</p>
              </div>
            </div>
          </div>

          {/* Non-SSL Settings (Hidden by default) */}
          <div className="space-y-4">
            <button 
              onClick={() => setShowNonSSL(!showNonSSL)}
              className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white transition-colors group"
            >
              {showNonSSL ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              Show Non SSL/TLS Settings
            </button>

            {showNonSSL && (
              <div className="bg-[#1e293b] rounded-2xl border border-white/10 overflow-hidden shadow-xl animate-in slide-in-from-top-2 duration-300">
                <div className="px-6 py-4 bg-slate-700">
                  <h3 className="text-sm font-bold text-white">Non-SSL Settings (NOT Recommended)</h3>
                </div>
                <div className="p-0">
                  <div className="grid grid-cols-3 border-b border-white/5">
                    <div className="px-6 py-4 bg-[#0f172a]/30 text-xs font-bold text-slate-500 border-r border-white/5">Kullanıcı adı:</div>
                    <div className="px-6 py-4 col-span-2 text-sm text-slate-200 font-mono">{email}</div>
                  </div>
                  <div className="grid grid-cols-3 border-b border-white/5">
                    <div className="px-6 py-4 bg-[#0f172a]/30 text-xs font-bold text-slate-500 border-r border-white/5">Gelen Sunucu:</div>
                    <div className="px-6 py-4 col-span-2 space-y-1">
                      <p className="text-sm text-slate-200 font-mono">mail.{project.url.split('//')[1]}</p>
                      <div className="flex gap-4 text-[10px] font-bold">
                        <span className="text-slate-400 uppercase">IMAP Port: 143</span>
                        <span className="text-slate-400 uppercase">POP3 Port: 110</span>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 border-b border-white/5">
                    <div className="px-6 py-4 bg-[#0f172a]/30 text-xs font-bold text-slate-500 border-r border-white/5">Giden Sunucu:</div>
                    <div className="px-6 py-4 col-span-2 space-y-1">
                      <p className="text-sm text-slate-200 font-mono">mail.{project.url.split('//')[1]}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">SMTP Port: 25</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Email Instructions */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Mail className="w-5 h-5 text-emerald-400" /> Email Instructions
        </h2>
        <p className="text-xs text-slate-500">Send configuration information for “{email}” to the following email address:</p>
        
        <div className="flex gap-3 max-w-md">
          <input 
            type="email" 
            value={instructionEmail}
            onChange={(e) => setInstructionEmail(e.target.value)}
            placeholder="Email adresi girin"
            className="flex-1 bg-[#0f172a] border border-white/5 rounded-xl py-2.5 px-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all"
          />
          <button className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all flex items-center gap-2">
            <Send className="w-4 h-4" /> Gönder
          </button>
        </div>
      </div>

      {/* Notes */}
      <div className="space-y-4 pt-8 border-t border-white/5">
        <h3 className="text-sm font-bold text-slate-300 uppercase tracking-widest">Notlar:</h3>
        <ul className="space-y-3">
          {[
            'IMAP e-posta erişimi sunucu ile posta uygulamanız arasındaki koordinasyonu sağlar. Okunmuş/silinmiş/yanıtlanmış mesajlar hem sunucuda hem de posta uygulamasında şekilde gösterilecektir.',
            'POP3, sunucu ile koordineli değil. Posta uygulamasında okunmuş/silinmiş/yanıtlanmış olarak işaretlenen mesajlar sunucudaki gibi gösterilmeyecek. Bu, POP3 ile gelecekteki posta indirmelerinin tüm mesajları okunmamış olarak göstereceği anlamına gelir.',
            'Giden posta SMTP kullanılarak gönderildi.',
            'SSL/TLS üzerinden POP3 ya da SSL/TLS üzerinden IMAP kullanılmasını öneririz zira uzak posta sunucusu ile etkileşimlerinizde daha fazla güvenlik sağlar.'
          ].map((note, i) => (
            <li key={i} className="flex gap-3 text-xs text-slate-400 leading-relaxed">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
              {note}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
