import React, { useState } from 'react';
import { 
  ArrowLeft, Layout, Server, Database, Globe, 
  Cpu, Zap, Code, Shield, Save, Check,
  Layers, HardDrive, Box
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface AddProjectProps {
  onBack: () => void;
  onAdd: (project: Partial<Project>) => void;
}

export const AddProject: React.FC<AddProjectProps> = ({ onBack, onAdd }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    domain: '',
    frontend: '',
    backendMode: 'single' as 'single' | 'multiple',
    backends: [] as string[],
    database: '',
    secondaryDb: '',
    environment: 'production'
  });

  const frontendOptions = [
    { id: 'react', name: 'React', icon: Layout, desc: 'Single Page Application' },
    { id: 'nextjs', name: 'Next.js', icon: Globe, desc: 'Server Side Rendering' },
  ];

  const backendOptions = [
    { id: 'python', name: 'Python (FastAPI)', icon: Code, desc: 'High performance API' },
    { id: 'go', name: 'Go (Fiber)', icon: Cpu, desc: 'Ultra-fast microservices' },
    { id: 'php', name: 'PHP (Laravel)', icon: Box, desc: 'Robust enterprise applications' },
    { id: 'php-vanilla', name: 'PHP (Vanilla)', icon: Code, desc: 'Native PHP application' },
  ];

  const databaseOptions = [
    { id: 'mysql', name: 'MySQL', icon: Database, desc: 'Relational Database' },
    { id: 'postgresql', name: 'PostgreSQL', icon: Database, desc: 'Advanced Relational DB' },
    { id: 'mssql', name: 'Microsoft SQL Server', icon: Database, desc: 'Enterprise Relational DB' },
    { id: 'mongodb', name: 'MongoDB', icon: HardDrive, desc: 'NoSQL Document Database' },
  ];

  const secondaryDbOptions = [
    { id: 'redis', name: 'Redis', icon: Zap, desc: 'Cache & Message Broker' },
    { id: 'none', name: 'None', icon: Box, desc: 'No second database' },
  ];

  const handleComplete = () => {
    onAdd({
      name: formData.name,
      url: `https://${formData.domain}`,
      status: 'deploying',
      dockerId: `${formData.name.toLowerCase().replace(/\s+/g, '-')}-01`,
      stack: {
        frontend: formData.frontend,
        backends: formData.backends,
        database: formData.database,
        secondaryDb: formData.secondaryDb
      }
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={onBack}
          className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-white">Yeni Proje Oluştur</h1>
          <p className="text-xs text-slate-500 mt-1">Saniyeler içinde yeni bir uygulama ve altyapı yayına alın</p>
        </div>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-4 bg-[#1e293b] p-4 rounded-2xl border border-white/5 overflow-x-auto no-scrollbar">
        {[1, 2, 3, 4].map((s) => (
          <React.Fragment key={s}>
            <div className={cn(
              "flex items-center gap-3 shrink-0 px-4 py-2 rounded-xl transition-all",
              step === s ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : 
              step > s ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" :
              "text-slate-500 border border-white/5"
            )}>
              <div className={cn(
                "w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold",
                step === s ? "bg-white/20" : step > s ? "bg-emerald-500/20" : "bg-slate-800"
              )}>
                {step > s ? <Check className="w-4 h-4" /> : s}
              </div>
              <span className="text-xs font-bold whitespace-nowrap uppercase tracking-widest">
                {s === 1 ? 'Kimlik' : s === 2 ? 'Frontend/Backend' : s === 3 ? 'Veritabanı' : 'Özet'}
              </span>
            </div>
            {s < 4 && <div className="w-8 h-px bg-slate-800 shrink-0" />}
          </React.Fragment>
        ))}
      </div>

      {/* Step Content */}
      <div className="bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl overflow-hidden min-h-[400px]">
        {step === 1 && (
          <div className="p-8 space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <Box className="w-5 h-5 text-indigo-400" />
                <h2 className="text-lg font-bold text-white">Proje Bilgileri</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-2">Proje Adı</label>
                  <input 
                    type="text" 
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Örn: Seraiph CRM"
                    className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all font-medium"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-2">Domain Adı</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 text-sm">https://</span>
                    <input 
                      type="text" 
                      value={formData.domain}
                      onChange={(e) => setFormData({ ...formData, domain: e.target.value })}
                      placeholder="proje-adi.seraiph.os"
                      className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-3 pl-16 pr-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all font-medium"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-indigo-500/5 border border-indigo-500/10 rounded-2xl p-6 flex gap-4">
              <Info className="w-5 h-5 text-indigo-400 shrink-0" />
              <p className="text-xs text-slate-400 leading-relaxed">
                Domain adınız otomatik olarak SSL sertifikası ile yapılandırılacaktır. Seraiph OS altyapısı bu ismi tüm ağ servislerinde benzersiz kimlik olarak kullanır.
              </p>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="p-8 space-y-10 animate-in fade-in slide-in-from-right-4 duration-300">
            {/* Frontend Selection */}
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <Layout className="w-5 h-5 text-indigo-400" />
                <h2 className="text-lg font-bold text-white">Frontend Bileşeni</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {frontendOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setFormData({ ...formData, frontend: opt.id })}
                    className={cn(
                      "p-5 rounded-2xl border transition-all text-left group relative overflow-hidden",
                      formData.frontend === opt.id 
                        ? "bg-indigo-600/10 border-indigo-500 shadow-lg shadow-indigo-500/10" 
                        : "bg-[#0f172a]/50 border-white/5 hover:border-white/10"
                    )}
                  >
                    <div className="flex items-center gap-4 relative z-10">
                      <div className={cn(
                        "p-3 rounded-xl border transition-all",
                        formData.frontend === opt.id ? "bg-indigo-500 text-white" : "bg-slate-800 text-slate-400"
                      )}>
                        <opt.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">{opt.name}</h3>
                        <p className="text-xs text-slate-500 mt-0.5">{opt.desc}</p>
                      </div>
                    </div>
                    {formData.frontend === opt.id && (
                      <div className="absolute top-2 right-2">
                        <Check className="w-4 h-4 text-indigo-400" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Backend Selection */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Server className="w-5 h-5 text-indigo-400" />
                  <h2 className="text-lg font-bold text-white">Backend Bileşeni</h2>
                </div>
                {/* Single/Multiple Selection */}
                <div className="flex bg-[#0f172a] p-1 rounded-xl border border-white/5">
                  <button
                    onClick={() => setFormData({ ...formData, backendMode: 'single', backends: formData.backends.slice(0, 1) })}
                    className={cn(
                      "px-4 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                      formData.backendMode === 'single' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    Tekli Backend
                  </button>
                  <button
                    onClick={() => setFormData({ ...formData, backendMode: 'multiple' })}
                    className={cn(
                      "px-4 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                      formData.backendMode === 'multiple' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    Çoklu Backend
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {backendOptions.map((opt) => {
                  const isSelected = formData.backends.includes(opt.id);
                  return (
                    <button
                      key={opt.id}
                      onClick={() => {
                        if (formData.backendMode === 'single') {
                          setFormData({ ...formData, backends: [opt.id] });
                        } else {
                          const newBackends = isSelected 
                            ? formData.backends.filter(id => id !== opt.id)
                            : [...formData.backends, opt.id];
                          setFormData({ ...formData, backends: newBackends });
                        }
                      }}
                      className={cn(
                        "p-5 rounded-2xl border transition-all text-left group relative overflow-hidden",
                        isSelected 
                          ? "bg-indigo-600/10 border-indigo-500 shadow-lg shadow-indigo-500/10" 
                          : "bg-[#0f172a]/50 border-white/5 hover:border-white/10"
                      )}
                    >
                      <div className="flex items-center gap-4 relative z-10">
                        <div className={cn(
                          "p-3 rounded-xl border transition-all",
                          isSelected ? "bg-indigo-500 text-white" : "bg-slate-800 text-slate-400"
                        )}>
                          <opt.icon className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="text-sm font-bold text-white">{opt.name}</h3>
                          <p className="text-xs text-slate-500 mt-0.5">{opt.desc}</p>
                        </div>
                      </div>
                      {isSelected && (
                        <div className="absolute top-2 right-2">
                          <Check className="w-4 h-4 text-indigo-400" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="p-8 space-y-10 animate-in fade-in slide-in-from-right-4 duration-300">
            {/* Primary DB Selection */}
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <Database className="w-5 h-5 text-indigo-400" />
                <h2 className="text-lg font-bold text-white">Ana Veritabanı</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {databaseOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setFormData({ ...formData, database: opt.id })}
                    className={cn(
                      "p-5 rounded-2xl border transition-all text-left group relative overflow-hidden",
                      formData.database === opt.id 
                        ? "bg-indigo-600/10 border-indigo-500 shadow-lg shadow-indigo-500/10" 
                        : "bg-[#0f172a]/50 border-white/5 hover:border-white/10"
                    )}
                  >
                    <div className="flex items-center gap-4 relative z-10">
                      <div className={cn(
                        "p-3 rounded-xl border transition-all",
                        formData.database === opt.id ? "bg-indigo-500 text-white" : "bg-slate-800 text-slate-400"
                      )}>
                        <opt.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">{opt.name}</h3>
                        <p className="text-xs text-slate-500 mt-0.5">{opt.desc}</p>
                      </div>
                    </div>
                    {formData.database === opt.id && (
                      <div className="absolute top-2 right-2">
                        <Check className="w-4 h-4 text-indigo-400" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Secondary DB Selection */}
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <Zap className="w-5 h-5 text-indigo-400" />
                <h2 className="text-lg font-bold text-white">İkinci Veritabanı (Redis vb.)</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {secondaryDbOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setFormData({ ...formData, secondaryDb: opt.id })}
                    className={cn(
                      "p-5 rounded-2xl border transition-all text-left group relative overflow-hidden",
                      formData.secondaryDb === opt.id 
                        ? "bg-indigo-600/10 border-indigo-500 shadow-lg shadow-indigo-500/10" 
                        : "bg-[#0f172a]/50 border-white/5 hover:border-white/10"
                    )}
                  >
                    <div className="flex items-center gap-4 relative z-10">
                      <div className={cn(
                        "p-3 rounded-xl border transition-all",
                        formData.secondaryDb === opt.id ? "bg-indigo-500 text-white" : "bg-slate-800 text-slate-400"
                      )}>
                        <opt.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">{opt.name}</h3>
                        <p className="text-xs text-slate-500 mt-0.5">{opt.desc}</p>
                      </div>
                    </div>
                    {formData.secondaryDb === opt.id && (
                      <div className="absolute top-2 right-2">
                        <Check className="w-4 h-4 text-indigo-400" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="p-8 space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="flex items-center gap-3">
              <Save className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-white">Proje Özet Yapılandırması</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#0f172a]/50 border border-white/5 p-6 rounded-2xl space-y-4">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Altyapı & Kimlik</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Proje Adı</span>
                    <span className="text-white font-medium">{formData.name}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Public URL</span>
                    <span className="text-indigo-400 font-medium">https://{formData.domain}</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#0f172a]/50 border border-white/5 p-6 rounded-2xl space-y-4">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Yazılım Yığını</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Frontend</span>
                    <span className="text-white font-medium capitalize">{formData.frontend}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Backend</span>
                    <span className="text-white font-medium capitalize">
                      {formData.backends.length > 0 ? (
                        formData.backends.join(', ')
                      ) : 'Seçilmedi'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-[#0f172a]/50 border border-white/5 p-6 rounded-2xl space-y-4 md:col-span-2">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Veri Katmanları</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Ana DB</span>
                    <span className="text-white font-medium capitalize">{formData.database}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">İkinci DB</span>
                    <span className="text-white font-medium capitalize">{formData.secondaryDb || 'Yok'}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-3">
              <Shield className="w-5 h-5 text-emerald-500" />
              <p className="text-xs text-slate-300">
                Tüm bileşenler Docker containerları içinde izole edilecek ve aralarındaki bağlantılar güvenli ağ üzerinden otomatik kurulacaktır.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Footer Controls */}
      <div className="flex items-center justify-between pt-4">
        <button 
          onClick={() => step > 1 ? setStep(step - 1) : onBack()}
          className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-sm font-bold transition-all border border-white/5"
        >
          {step === 1 ? 'İptal' : 'Geri Dön'}
        </button>
        <button 
          onClick={() => {
            if (step < 4) setStep(step + 1);
            else handleComplete();
          }}
          disabled={step === 1 && !formData.name}
          className="px-8 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-600/20 flex items-center gap-2"
        >
          {step === 4 ? 'Projeyi Dağıt (Deploy)' : 'Devam Et'}
          {step === 4 ? <Layers className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};

// Internal components icons
const Info = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
);

const ArrowRight = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
);
