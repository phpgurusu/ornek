import React, { useState } from 'react';
import { 
  Settings, Key, Globe, Database, 
  Terminal, Shield, FileText, Plus,
  Trash2, Copy, Check, Save, ArrowLeft,
  Info, AlertCircle, Eye, EyeOff, Lock
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ConfigManagementProps {
  project: Project;
  onBack: () => void;
}

export const ConfigManagement: React.FC<ConfigManagementProps> = ({ project, onBack }) => {
  const [activeTab, setActiveTab] = useState<'env' | 'system'>('env');
  const [showValues, setShowValues] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [envVars, setEnvVars] = useState([
    { id: '1', key: 'DATABASE_URL', value: 'postgresql://seraiph:pass@cluster:5432/main', type: 'Database' },
    { id: '2', key: 'REDIS_HOST', value: '127.0.0.1', type: 'Cache' },
    { id: '3', key: 'API_SECRET_KEY', value: 'sk_live_51M3v0TJSx1...', type: 'Secret' },
    { id: '4', key: 'PORT', value: '3000', type: 'System' },
    { id: '5', key: 'NODE_ENV', value: 'production', type: 'System' },
    { id: '6', key: 'GEMINI_API_KEY', value: 'AIzaSyBw...', type: 'AI' },
  ]);

  const [systemConfig, setSystemConfig] = useState(`{
  "project": {
    "name": "Seraiph Web App",
    "version": "1.0.4",
    "region": "europe-west1"
  },
  "build": {
    "engine": "docker",
    "base_image": "node:18-alpine",
    "optimize": true
  },
  "security": {
    "waf": true,
    "ddos_protection": "enterprise",
    "ssl": "auto-renew"
  }
}`);

  const toggleVisibility = (id: string) => {
    setShowValues(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
              Configuration Management
              <Settings className="w-5 h-5 text-slate-400" />
            </h1>
            <p className="text-xs text-slate-500 mt-1">Environment değişkenleri ve sistem yapılandırma ayarları</p>
          </div>
        </div>
        <div className="flex bg-[#1e293b] rounded-2xl border border-white/5 p-1">
          {[
            { id: 'env', label: 'Variables', icon: Key },
            { id: 'system', label: 'System JSON', icon: FileText },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap",
                activeTab === tab.id 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
              )}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'env' && (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
           {/* Info Box */}
           <div className="bg-indigo-600/10 p-6 rounded-3xl border border-indigo-500/20 flex gap-4 items-start">
              <div className="p-2 bg-indigo-600/20 rounded-xl">
                 <Shield className="w-5 h-5 text-indigo-400" />
              </div>
              <div className="space-y-1">
                 <h4 className="text-sm font-bold text-indigo-300 uppercase tracking-widest">Güvenlik Hatırlatması</h4>
                 <p className="text-xs text-indigo-400/80 leading-relaxed">
                    Environment değişkenleri sunucu tarafında güvenli bir şekilde saklanır. "Secret" olarak işaretlenen değişkenler client-side kodunda asla görünmez.
                 </p>
              </div>
           </div>

           {/* Env Vars Editor */}
           <div className="bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl overflow-hidden">
              <div className="p-6 border-b border-white/5 bg-[#0f172a]/20 flex items-center justify-between">
                 <h3 className="text-sm font-bold text-white uppercase tracking-widest">Environment Variables</h3>
                 <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all">
                    <Plus className="w-4 h-4" /> Add Variable
                 </button>
              </div>
              
              <div className="divide-y divide-white/5">
                 {envVars.map((v) => (
                   <div key={v.id} className="p-6 hover:bg-white/[0.02] transition-colors group">
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                         <div className="md:col-span-4">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Variable Name</span>
                            <div className="flex items-center gap-3">
                               <p className="text-sm font-mono font-bold text-white uppercase">{v.key}</p>
                               <span className="px-2 py-0.5 bg-white/5 text-slate-500 text-[9px] font-bold rounded border border-white/10 uppercase">{v.type}</span>
                            </div>
                         </div>
                         <div className="md:col-span-6 relative group/val">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Value</span>
                            <div className="flex items-center gap-2">
                               <div className="flex-1 p-2.5 bg-[#0f172a] rounded-xl border border-white/5 font-mono text-xs text-slate-400 overflow-hidden text-ellipsis whitespace-nowrap">
                                  {v.type === 'Secret' && !showValues[v.id] ? '••••••••••••••••' : v.value}
                               </div>
                               <div className="flex gap-1">
                                  {v.type === 'Secret' && (
                                    <button 
                                      onClick={() => toggleVisibility(v.id)}
                                      className="p-2 hover:bg-white/5 rounded-lg text-slate-500 hover:text-white transition-all"
                                    >
                                       {showValues[v.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                    </button>
                                  )}
                                  <button 
                                    onClick={() => copyToClipboard(v.value, v.id)}
                                    className="p-2 hover:bg-white/5 rounded-lg text-slate-500 hover:text-white transition-all"
                                  >
                                     {copiedId === v.id ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                                  </button>
                               </div>
                            </div>
                         </div>
                         <div className="md:col-span-2 flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all">
                               <Lock className="w-4 h-4" />
                            </button>
                            <button className="p-2 bg-rose-500/5 hover:bg-rose-500/10 text-rose-500 rounded-xl border border-rose-500/10 transition-all">
                               <Trash2 className="w-4 h-4" />
                            </button>
                         </div>
                      </div>
                   </div>
                 ))}
              </div>

              <div className="p-6 bg-[#0f172a]/20 border-t border-white/5 flex items-center justify-between">
                 <p className="text-[10px] font-medium text-slate-500 uppercase tracking-widest">Total Variables: {envVars.length}</p>
                 <button className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 text-[10px] font-black uppercase tracking-widest transition-all">
                    Apply Changes & Restart <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
                 </button>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'system' && (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
           <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              {/* Sidebar Help */}
              <div className="lg:col-span-1 space-y-6">
                 <div className="bg-[#1e293b] p-6 rounded-3xl border border-white/5 shadow-xl space-y-4">
                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Yapılandırma Kılavuzu</h3>
                    <div className="space-y-4">
                       <div className="flex gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                          <p className="text-[10px] text-slate-400 leading-relaxed font-medium">JSON formatında geçerli bir şema kullanın.</p>
                       </div>
                       <div className="flex gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                          <p className="text-[10px] text-slate-400 leading-relaxed font-medium">Build engine değişiklikleri yeni redeploy gerektirir.</p>
                       </div>
                    </div>
                 </div>
                 
                 <div className="bg-amber-500/5 p-6 rounded-3xl border border-amber-500/10 flex gap-4">
                    <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />
                    <p className="text-[9px] font-bold text-amber-500 leading-normal uppercase tracking-widest">
                       Hatalı yapılandırma uygulamanın çökmesine neden olabilir.
                    </p>
                 </div>
              </div>

              {/* Editor Area */}
              <div className="lg:col-span-3 bg-[#1e293b] rounded-3xl border border-white/5 shadow-2xl overflow-hidden flex flex-col">
                 <div className="p-4 bg-[#0f172a] border-b border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <Terminal className="w-4 h-4 text-emerald-400" />
                       <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">config.json</span>
                    </div>
                    <div className="flex items-center gap-4">
                       <button className="flex items-center gap-2 text-rose-500 text-[10px] font-black uppercase tracking-widest hover:bg-rose-500/5 px-3 py-1 rounded-lg transition-all">
                          Discard
                       </button>
                       <button className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-xl shadow-lg shadow-emerald-600/20 transition-all">
                          <Save className="w-3.5 h-3.5" /> Save Config
                       </button>
                    </div>
                 </div>
                 <div className="flex-1 p-6 font-mono text-xs leading-relaxed text-indigo-400 min-h-[500px]">
                    <textarea 
                       value={systemConfig}
                       onChange={(e) => setSystemConfig(e.target.value)}
                       className="w-full h-full bg-transparent border-none outline-none resize-none custom-scrollbar"
                       spellCheck={false}
                    />
                 </div>
                 <div className="px-6 py-3 bg-[#0f172a]/50 border-t border-white/5 flex items-center justify-between text-[9px] font-bold text-slate-500 uppercase tracking-widest">
                    <span>Spaces: 2</span>
                    <span>Valid JSON</span>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
