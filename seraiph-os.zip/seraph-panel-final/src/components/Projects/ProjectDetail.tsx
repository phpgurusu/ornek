import React from 'react';
import { ArrowLeft, Box, Globe, Terminal, Database, Activity, Shield, Cpu, HardDrive, RefreshCw, Play, Square, Settings, Mail, Folder, Code, Lock, ChevronRight } from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ProjectDetailProps {
  project: Project;
  onBack: () => void;
  onSubViewChange: (view: string) => void;
  setActiveTab: (tab: string) => void;
}

export const ProjectDetail: React.FC<ProjectDetailProps> = ({ project, onBack, onSubViewChange, setActiveTab }) => {
  const managementCards = [
    { id: 'setup', title: 'Setup Yönetimi', icon: Play, color: 'text-orange-400', status: 'Bileşen Kurulumu' },
    { id: 'email', title: 'Eposta Yönetimi', icon: Mail, color: 'text-blue-400', status: '3 Active Accounts' },
    { id: 'database', title: 'Veritabanı Yönetimi', icon: Database, color: 'text-emerald-400', status: 'MySQL 8.0 Running' },
    { id: 'files', title: 'Dosya Yönetimi', icon: Folder, color: 'text-amber-400', status: '1.2GB Used' },
    { id: 'domain', title: 'Domain Yönetimi', icon: Globe, color: 'text-indigo-400', status: 'Primary: ' + project.url },
    { id: 'security', title: 'Siber Güvenlik', icon: Shield, color: 'text-red-400', status: 'WAF Active' },
    { id: 'software', title: 'Yazılım Yönetimi', icon: Code, color: 'text-purple-400', status: 'Node.js v18.16.0' },
    { id: 'certificates', title: 'Sertifika Yönetimi', icon: Lock, color: 'text-cyan-400', status: 'SSL Valid (240 days)' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-white">{project.name}</h1>
              <div className={cn(
                "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
                project.status === 'online' ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" : "bg-red-500/10 text-red-500 border border-red-500/20"
              )}>
                {project.status}
              </div>
            </div>
            <p className="text-xs text-slate-500 font-mono mt-1">{project.dockerId} • {project.url}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => onSubViewChange('redeploy')}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" /> Redeploy
          </button>
          <button 
            onClick={() => onSubViewChange('config')}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 border border-white/5"
          >
            <Settings className="w-4 h-4" /> Config
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'CPU Usage', value: '12.4%', icon: Cpu, color: 'text-indigo-400' },
          { label: 'Memory', value: '512MB / 2GB', icon: HardDrive, color: 'text-emerald-400' },
          { label: 'Network In', value: '1.2 MB/s', icon: Globe, color: 'text-amber-400' },
          { label: 'Uptime', value: '14d 2h 5m', icon: Activity, color: 'text-blue-400' },
        ].map((stat, i) => (
          <div key={i} className="bg-[#1e293b] p-6 rounded-2xl border border-white/5 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className={cn("p-2 rounded-lg bg-[#0f172a] border border-white/5", stat.color)}>
                <stat.icon className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{stat.label}</span>
            </div>
            <p className="text-xl font-bold text-white">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Management Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {managementCards.map((card, i) => (
          <button 
            key={i}
            onClick={() => onSubViewChange(card.id)}
            className="bg-[#1e293b] p-4 rounded-xl border border-white/5 hover:border-indigo-500/30 transition-all group text-left flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <div className={cn("p-2.5 rounded-lg bg-[#0f172a] border border-white/5 group-hover:scale-110 transition-transform", card.color)}>
                <card.icon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-200">{card.title}</h3>
                <p className="text-[10px] text-slate-500 font-medium mt-0.5">{card.status}</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-indigo-400 transition-colors" />
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Logs / Console */}
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 overflow-hidden shadow-xl">
            <div className="p-4 border-b border-white/5 bg-[#0f172a]/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-400" />
                <h2 className="font-medium text-slate-200">Container Logs</h2>
              </div>
              <div className="flex gap-2">
                <button className="p-1.5 text-slate-500 hover:text-white transition-colors"><RefreshCw className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="p-4 h-80 overflow-y-auto font-mono text-xs bg-[#0f172a]/50 space-y-1">
              <p className="text-slate-500">[2026-03-08 19:33:24] INFO: Starting application...</p>
              <p className="text-slate-500">[2026-03-08 19:33:25] INFO: Database connection established.</p>
              <p className="text-emerald-500">[2026-03-08 19:33:26] SUCCESS: Server running on port 3000</p>
              <p className="text-slate-300">[2026-03-08 19:35:12] GET /api/v1/users - 200 OK</p>
              <p className="text-slate-300">[2026-03-08 19:36:45] GET /api/v1/projects - 200 OK</p>
              <p className="text-amber-500">[2026-03-08 19:38:22] WARN: Memory usage exceeding 75% threshold</p>
              <p className="text-slate-300">[2026-03-08 19:40:01] POST /api/v1/auth/login - 200 OK</p>
            </div>
          </div>

          {/* Deployment History */}
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 overflow-hidden shadow-xl">
            <div className="p-4 border-b border-white/5 bg-[#0f172a]/50">
              <h2 className="font-medium text-slate-200">Deployment History</h2>
            </div>
            <div className="divide-y divide-white/5">
              {[
                { version: 'v2.4.1', date: '2 hours ago', status: 'Success', author: 'Sinan B.' },
                { version: 'v2.4.0', date: '1 day ago', status: 'Success', author: 'Sinan B.' },
                { version: 'v2.3.9', date: '3 days ago', status: 'Failed', author: 'System' },
              ].map((deploy, i) => (
                <div key={i} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      deploy.status === 'Success' ? "bg-emerald-500" : "bg-red-500"
                    )} />
                    <div>
                      <p className="text-sm font-medium text-slate-200">{deploy.version}</p>
                      <p className="text-xs text-slate-500">{deploy.date} by {deploy.author}</p>
                    </div>
                  </div>
                  <span className={cn(
                    "text-[10px] font-bold uppercase tracking-wider",
                    deploy.status === 'Success' ? "text-emerald-500" : "text-red-500"
                  )}>
                    {deploy.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl">
            <h3 className="text-sm font-bold text-slate-200 uppercase tracking-widest mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center gap-3 px-4 py-3 bg-[#0f172a] hover:bg-indigo-600/10 text-slate-300 hover:text-indigo-400 border border-white/5 rounded-xl transition-all">
                <Play className="w-4 h-4" /> Start Container
              </button>
              <button className="w-full flex items-center gap-3 px-4 py-3 bg-[#0f172a] hover:bg-red-600/10 text-slate-300 hover:text-red-400 border border-white/5 rounded-xl transition-all">
                <Square className="w-4 h-4" /> Stop Container
              </button>
              <button className="w-full flex items-center gap-3 px-4 py-3 bg-[#0f172a] hover:bg-indigo-600/10 text-slate-300 hover:text-indigo-400 border border-white/5 rounded-xl transition-all">
                <Database className="w-4 h-4" /> Backup Database
              </button>
              <button 
                onClick={() => setActiveTab('terminal')}
                className="w-full flex items-center gap-3 px-4 py-3 bg-[#0f172a] hover:bg-emerald-600/10 text-slate-300 hover:text-emerald-400 border border-white/5 rounded-xl transition-all"
              >
                <Terminal className="w-4 h-4" /> SSH Start
              </button>
            </div>
          </div>

          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl">
            <h3 className="text-sm font-bold text-slate-200 uppercase tracking-widest mb-4">Environment</h3>
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Node Version</p>
                <p className="text-sm text-slate-300 font-mono">v18.16.0</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Docker Image</p>
                <p className="text-sm text-slate-300 font-mono">seraiph/node-app:latest</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Internal IP</p>
                <p className="text-sm text-slate-300 font-mono">172.17.0.5</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
