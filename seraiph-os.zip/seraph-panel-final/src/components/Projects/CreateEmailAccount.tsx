import React, { useState } from 'react';
import { 
  ArrowLeft, HelpCircle, ExternalLink, Eye, EyeOff, 
  Wrench, ChevronDown, Info, ShieldCheck, Mail,
  Settings2, HelpCircle as HelpIcon
} from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface CreateEmailAccountProps {
  project: Project;
  onBack: () => void;
}

export const CreateEmailAccount: React.FC<CreateEmailAccountProps> = ({ project, onBack }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [storageType, setStorageType] = useState<'fixed' | 'unlimited'>('fixed');
  const [storageSize, setStorageSize] = useState('2048');

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 bg-[#1e293b] hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">E-Posta Hesapları</h1>
            <div className="flex items-center gap-2 text-xs mt-1">
              <button onClick={onBack} className="text-indigo-400 hover:underline">E-posta Hesaplarını Listele</button>
              <span className="text-slate-600">/</span>
              <span className="text-slate-400">E-posta Hesabı Oluştur</span>
            </div>
          </div>
        </div>
        
        <div className="bg-indigo-600/10 border border-indigo-500/20 p-4 rounded-xl flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <p className="text-xs text-slate-300 leading-relaxed">
            Bu sayfayı kullanarak cPanel hesabınızdaki herhangi bir alan adı için yeni e-posta adresleri oluşturabilirsiniz. Daha fazla bilgi edinmek ister misiniz? Belgelerimizi <a href="#" className="text-indigo-400 hover:underline inline-flex items-center gap-1">okuyun <ExternalLink className="w-3 h-3" /></a>.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 shadow-xl overflow-hidden">
            <div className="p-4 bg-[#0f172a]/50 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest">E-POSTA HESABI OLUŞTUR</h2>
              <button className="flex items-center gap-1.5 px-3 py-1 bg-[#0f172a] hover:bg-slate-800 text-[10px] font-bold text-slate-400 border border-white/5 rounded-lg transition-all">
                Yardımı Göster/Gizle <HelpCircle className="w-3 h-3" />
              </button>
            </div>

            <div className="p-8 space-y-8">
              {/* Domain Selection */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-300">
                  Etki Alanı <HelpCircle className="w-3 h-3 text-indigo-400 cursor-help" />
                </label>
                <div className="relative">
                  <select className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-3 px-4 text-sm text-slate-200 appearance-none focus:outline-none focus:border-indigo-500/50 transition-all">
                    <option>{project.url.replace('https://', '')}</option>
                    <option>subdomain.{project.url.replace('https://', '')}</option>
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
                </div>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  Alan adınız mı eksik? Alan <span className="italic">adınız mı eksik?</span> bölümüne bakarak nasıl oluşturabileceğinizi öğrenin.
                </p>
              </div>

              {/* Username */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-300">
                  Kullanıcı adı <HelpCircle className="w-3 h-3 text-indigo-400 cursor-help" />
                </label>
                <div className="flex items-center">
                  <input 
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="E-posta adresinizin kullanıcı adını buraya girin."
                    className="flex-1 bg-[#0f172a] border border-white/5 rounded-l-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all"
                  />
                  <div className="bg-[#0f172a] border border-l-0 border-white/5 rounded-r-xl py-3 px-4 text-sm text-slate-500">
                    @
                  </div>
                </div>
                <button className="text-[10px] text-indigo-400 hover:underline font-medium">Alan adı mı eksik?</button>
              </div>

              {/* Password Section */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-300">Şifre</label>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className="relative flex items-center justify-center">
                      <input type="radio" name="pass-type" defaultChecked className="peer sr-only" />
                      <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                    </div>
                    <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">Şimdi şifre belirleyin.</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className="relative flex items-center justify-center">
                      <input type="radio" name="pass-type" className="peer sr-only" />
                      <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                    </div>
                    <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">Giriş bağlantısını alternatif e-posta adresine gönderin.</span>
                  </label>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input 
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Şifreyi Girin"
                      className="w-full bg-[#0f172a] border border-white/5 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all"
                    />
                    <button 
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="flex bg-[#0f172a] border border-white/5 rounded-xl overflow-hidden">
                    <button className="px-4 py-3 text-xs font-bold text-slate-400 hover:bg-slate-800 transition-all border-r border-white/5">
                      Oluştur
                    </button>
                    <button className="px-2 py-3 text-slate-500 hover:text-white transition-all">
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Strength Indicator */}
                <div className="flex gap-1 h-1">
                  <div className="flex-1 bg-emerald-500 rounded-full" />
                  <div className="flex-1 bg-emerald-500 rounded-full" />
                  <div className="flex-1 bg-emerald-500 rounded-full" />
                  <div className="flex-1 bg-slate-800 rounded-full" />
                </div>
              </div>

              {/* Optional Settings */}
              <div className="pt-6 border-t border-white/5 space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-300">İsteğe Bağlı Ayarlar</h3>
                  <button className="flex items-center gap-1.5 px-3 py-1 bg-[#0f172a] hover:bg-slate-800 text-[10px] font-bold text-slate-400 border border-white/5 rounded-lg transition-all">
                    <Settings2 className="w-3 h-3" /> Ayarları Düzenle
                  </button>
                </div>

                <div className="space-y-4 pl-4 border-l-2 border-indigo-500/20">
                  <div className="space-y-3">
                    <label className="flex items-center gap-2 text-[11px] font-bold text-slate-400">
                      Depolama Alanı <HelpCircle className="w-3 h-3 text-indigo-400 cursor-help" />
                    </label>
                    <div className="flex items-center gap-6">
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <input 
                          type="radio" 
                          name="storage" 
                          checked={storageType === 'fixed'} 
                          onChange={() => setStorageType('fixed')}
                          className="peer sr-only" 
                        />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <div className="flex items-center">
                          <input 
                            type="text" 
                            value={storageSize}
                            onChange={(e) => setStorageSize(e.target.value)}
                            disabled={storageType !== 'fixed'}
                            className="w-20 bg-[#0f172a] border border-white/5 rounded-l-lg py-1.5 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500/50 disabled:opacity-50"
                          />
                          <select className="bg-[#0f172a] border border-l-0 border-white/5 rounded-r-lg py-1.5 px-2 text-xs text-slate-400 focus:outline-none">
                            <option>MB</option>
                            <option>GB</option>
                          </select>
                        </div>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <input 
                          type="radio" 
                          name="storage" 
                          checked={storageType === 'unlimited'} 
                          onChange={() => setStorageType('unlimited')}
                          className="peer sr-only" 
                        />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">Sınırsız</span>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="flex items-center gap-2 text-[11px] font-bold text-slate-400">
                      Plus adresleme için otomatik olarak klasör oluştur <HelpCircle className="w-3 h-3 text-indigo-400 cursor-help" />
                    </label>
                    <div className="space-y-2">
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <input type="radio" name="folder-auto" defaultChecked className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">Klasörleri Otomatik Olarak Oluştur</span>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <input type="radio" name="folder-auto" className="peer sr-only" />
                        <div className="w-4 h-4 rounded-full border border-white/20 peer-checked:border-indigo-500 peer-checked:border-4 transition-all" />
                        <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">Klasörleri otomatik olarak oluşturma</span>
                      </label>
                    </div>
                  </div>

                  <label className="flex items-center gap-3 cursor-pointer group pt-2">
                    <input type="checkbox" defaultChecked className="rounded border-white/10 bg-[#0f172a] text-indigo-600" />
                    <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">Bir e-posta istemcisi kurmak için talimatlar içeren bir hoş geldiniz e-postası gönderin.</span>
                  </label>
                </div>
              </div>

              <div className="pt-6 space-y-4">
                <label className="flex items-center gap-3 cursor-pointer group">
                  <input type="checkbox" className="rounded border-white/10 bg-[#0f172a] text-indigo-600" />
                  <span className="text-xs text-slate-400 group-hover:text-slate-200 transition-colors">"Oluştur" butonuna tıkladıktan sonra lütfen bu sayfada kalın.</span>
                </label>

                <div className="flex items-center justify-between pt-4">
                  <button className="flex items-center gap-2 px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-600/20">
                    <Mail className="w-4 h-4" /> Oluştur
                  </button>
                  <button onClick={onBack} className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-300 transition-colors">
                    <ArrowLeft className="w-4 h-4" /> Geri Dön
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Stats Bar */}
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl flex items-center justify-around">
            <div className="text-center">
              <p className="text-2xl font-bold text-white">∞</p>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Mevcut</p>
            </div>
            <div className="w-px h-10 bg-white/5" />
            <div className="text-center">
              <p className="text-2xl font-bold text-white">0</p>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Kullanıldı</p>
            </div>
          </div>

          {/* Missing Domain Info */}
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest">ALAN ADI MI EKSİK?</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Alt alan adları, alan adlarınızın alt bölümlerini oluşturmanıza olanak tanır.
            </p>
            <div className="space-y-3 pt-2">
              <button className="flex items-center gap-2 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors">
                <Wrench className="w-3.5 h-3.5" /> Alt alan adlarını yönetin
              </button>
              <button className="flex items-center gap-2 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors">
                <Wrench className="w-3.5 h-3.5" /> Takma Adları Yönet
              </button>
            </div>
          </div>

          {/* Need Help */}
          <div className="bg-[#1e293b] rounded-2xl border border-white/5 p-6 shadow-xl space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest">YARDIMA MI İHTİYACINIZ VAR?</h3>
            <button className="flex items-center gap-2 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors">
              <ExternalLink className="w-3.5 h-3.5" /> Bu Arayüz Hakkında
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
