import React from 'react';
import { Box, ExternalLink, RefreshCw, MoreVertical, Terminal } from 'lucide-react';
import { Project } from '../../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ProjectCardProps {
  project: Project;
  onClick?: () => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className={cn(
        "bg-[#1e293b] rounded-xl border border-white/5 p-5 hover:border-indigo-500/30 transition-all group shadow-lg",
        onClick && "cursor-pointer"
      )}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#0f172a] rounded-lg flex items-center justify-center border border-white/5 group-hover:border-indigo-500/50 transition-colors">
            <Box className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-200 tracking-tight">{project.name}</h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{project.dockerId}</p>
          </div>
        </div>
        <button className="p-1.5 text-slate-600 hover:text-slate-400 transition-colors">
          <MoreVertical className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={cn(
              "w-1.5 h-1.5 rounded-full",
              project.status === 'online' ? "bg-emerald-500" : project.status === 'offline' ? "bg-red-500" : "bg-amber-500 animate-pulse"
            )} />
            <span className={cn(
              "text-[10px] font-bold uppercase tracking-wider",
              project.status === 'online' ? "text-emerald-500" : project.status === 'offline' ? "text-red-500" : "text-amber-500"
            )}>
              {project.status}
            </span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">Uptime: 14d 2h 5m</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-3 py-2 bg-[#0f172a] hover:bg-[#161e2e] text-slate-400 hover:text-white border border-white/5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all"
          >
            <ExternalLink className="w-3 h-3" /> Visit Site
          </a>
          <button className="flex items-center justify-center gap-2 px-3 py-2 bg-[#0f172a] hover:bg-[#161e2e] text-slate-400 hover:text-white border border-white/5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all">
            <Terminal className="w-3 h-3" /> Console
          </button>
        </div>
      </div>
    </div>
  );
};
