import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

export const getGeminiResponse = async (prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");
  
  const ai = new GoogleGenAI({ apiKey });
  const model = "gemini-3.1-pro-preview";
  
  const response = await ai.models.generateContent({
    model,
    contents: [
      ...history,
      { role: 'user', parts: [{ text: prompt }] }
    ],
    config: {
      systemInstruction: "You are Seraiph OS AI, a senior DevOps and Security assistant. You help manage cloud infrastructure, Docker containers, and security logs. Keep responses concise, professional, and technical.",
    }
  });

  return response.text;
};

export const streamGeminiResponse = async function* (prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) {
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");

  const ai = new GoogleGenAI({ apiKey });
  const model = "gemini-3.1-pro-preview";

  const result = await ai.models.generateContentStream({
    model,
    contents: [
      ...history,
      { role: 'user', parts: [{ text: prompt }] }
    ],
    config: {
      systemInstruction: "You are Seraiph OS AI, a senior DevOps and Security assistant. You help manage cloud infrastructure, Docker containers, and security logs. Keep responses concise, professional, and technical.",
    }
  });

  for await (const chunk of result) {
    yield chunk.text;
  }
};
