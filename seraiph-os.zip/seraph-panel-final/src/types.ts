export interface ServerStats {
  cpu: number;
  ram: number;
  dbConnected: boolean;
  health: 'healthy' | 'warning' | 'critical';
}

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'info' | 'warning' | 'attack';
  message: string;
  sourceIp?: string;
}

export interface Project {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'deploying';
  url: string;
  dockerId: string;
  stack?: {
    frontend?: string;
    backends?: string[];
    database?: string;
    secondaryDb?: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
